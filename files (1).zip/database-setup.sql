-- ════════════════════════════════════════════════════════════════════
-- SUPABASE SQL MIGRATION — chạy trong SQL Editor của Supabase
-- Mở: https://supabase.com/dashboard → project → SQL Editor → New query
-- ════════════════════════════════════════════════════════════════════

-- ① Thêm 2 cột vào bảng profiles (streak)
ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS streak_count    int4    NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_study_date date;

-- ② Tạo bảng study_logs (1 row / user / ngày)
CREATE TABLE IF NOT EXISTS study_logs (
  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid        NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  study_date   date        NOT NULL DEFAULT CURRENT_DATE,
  cards_seen   int4        NOT NULL DEFAULT 0,
  quiz_score   int4        NOT NULL DEFAULT 0,
  words_saved  int4        NOT NULL DEFAULT 0,
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, study_date)
);

-- Index để query nhanh
CREATE INDEX IF NOT EXISTS idx_study_logs_user_date
  ON study_logs (user_id, study_date DESC);

-- ③ Row Level Security cho study_logs
ALTER TABLE study_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own logs"
  ON study_logs FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users insert own logs"
  ON study_logs FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users update own logs"
  ON study_logs FOR UPDATE
  USING (auth.uid() = user_id);

-- ④ Đảm bảo user_vocab có unique constraint và cột source
ALTER TABLE user_vocab
  ADD COLUMN IF NOT EXISTS source text NOT NULL DEFAULT 'manual';

ALTER TABLE user_vocab
  ADD CONSTRAINT IF NOT EXISTS user_vocab_user_word_unique
  UNIQUE (user_id, word);

-- ════════════════════════════════════════════════════════════════════
-- Sau khi chạy SQL xong, reload lại app — streak sẽ tự đồng bộ DB.
-- ════════════════════════════════════════════════════════════════════
