// ─── CONFIG ─────────────────────────────────────────────────────────
const SUPABASE_URL = 'https://yzmphcvszsirqweufytv.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl6bXBoY3ZzenNpcnF3ZXVmeXR2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzcyNjc0NDgsImV4cCI6MjA5Mjg0MzQ0OH0.3X5RipsKknzItre8_40-Opw3em3Fs8Yv5IKShbLDF24';
const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: false,      // Không lưu session — đóng tab là hết
    autoRefreshToken: false,    // Không tự refresh token
    detectSessionInUrl: true    // Vẫn bắt link xác nhận email / reset password
  }
});

// ─── NHẠC NỀN SÔI ĐỘNG (Web Audio API — tự tạo, không cần file mp3) ──
// Nhạc chỉ bật ở: trang chờ (home), đăng nhập/đăng ký/quên MK/đặt lại MK, dashboard học sinh.
// Nhạc TẮT ở: giáo viên, quản trị viên, và khi học sinh học/làm bài (flashcard), ôn từ vựng...
const BG_MUSIC_PAGES = ['home','login','signup','forgot','reset','student'];
let bgAudioCtx = null, bgMasterGain = null, bgSchedulerId = null, bgIsPlaying = false, bgUserMuted = false;
let bgNextNoteTime = 0, bgStep = 0;
const BG_BPM = 132;
const BG_STEP_DUR = 60 / BG_BPM / 2; // 8th notes
// Giai điệu vui tươi, sôi động (thang Đô trưởng ngũ cung), lặp vòng
const BG_LEAD = [523.25,0,659.25,783.99,0,659.25,880.00,783.99, 523.25,0,659.25,783.99,0,987.77,880.00,783.99];
const BG_BASS = [130.81,0,0,0,164.81,0,0,0, 174.61,0,0,0,196.00,0,0,0];

function bgEnsureCtx() {
  if (!bgAudioCtx) {
    bgAudioCtx = new (window.AudioContext || window.webkitAudioContext)();
    bgMasterGain = bgAudioCtx.createGain();
    bgMasterGain.gain.value = 0.16;
    bgMasterGain.connect(bgAudioCtx.destination);
  }
  if (bgAudioCtx.state === 'suspended') bgAudioCtx.resume();
}

function bgPlayTone(freq, time, dur, type, vol, gainNode) {
  if (!freq) return;
  const osc = bgAudioCtx.createOscillator();
  const g = bgAudioCtx.createGain();
  osc.type = type; osc.frequency.setValueAtTime(freq, time);
  g.gain.setValueAtTime(0.0001, time);
  g.gain.exponentialRampToValueAtTime(vol, time + 0.015);
  g.gain.exponentialRampToValueAtTime(0.0001, time + dur);
  osc.connect(g); g.connect(gainNode);
  osc.start(time); osc.stop(time + dur + 0.02);
}

function bgPlayHat(time, gainNode) {
  const bufSize = bgAudioCtx.sampleRate * 0.03;
  const buf = bgAudioCtx.createBuffer(1, bufSize, bgAudioCtx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < bufSize; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / bufSize);
  const src = bgAudioCtx.createBufferSource(); src.buffer = buf;
  const hp = bgAudioCtx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 6000;
  const g = bgAudioCtx.createGain(); g.gain.setValueAtTime(0.05, time);
  src.connect(hp); hp.connect(g); g.connect(gainNode);
  src.start(time);
}

function bgScheduler() {
  while (bgNextNoteTime < bgAudioCtx.currentTime + 0.12) {
    const i = bgStep % 16;
    bgPlayTone(BG_LEAD[i], bgNextNoteTime, BG_STEP_DUR * 0.9, 'square', 0.09, bgMasterGain);
    if (i % 4 === 0) bgPlayTone(BG_BASS[i], bgNextNoteTime, BG_STEP_DUR * 1.8, 'triangle', 0.16, bgMasterGain);
    if (i % 2 === 1) bgPlayHat(bgNextNoteTime, bgMasterGain);
    bgNextNoteTime += BG_STEP_DUR;
    bgStep++;
  }
  bgSchedulerId = setTimeout(bgScheduler, 60);
}

function startBgMusic() {
  if (bgUserMuted || bgIsPlaying) return;
  bgEnsureCtx();
  bgIsPlaying = true;
  bgNextNoteTime = bgAudioCtx.currentTime + 0.05;
  bgScheduler();
  const btn = document.getElementById('bg-music-toggle');
  if (btn) { btn.style.display = 'flex'; btn.textContent = '🔊'; }
}

function stopBgMusic() {
  bgIsPlaying = false;
  if (bgSchedulerId) { clearTimeout(bgSchedulerId); bgSchedulerId = null; }
  const btn = document.getElementById('bg-music-toggle');
  if (btn) btn.style.display = 'none';
}

function bgApplyForPage(name) {
  if (name === 'student') { bgRefreshStudentMusic(); return; }
  if (BG_MUSIC_PAGES.includes(name)) startBgMusic();
  else stopBgMusic();
}

// Trên trang Dashboard Học Sinh, nhạc phải TẮT khi học sinh đang thực sự
// "làm bài" (quiz, mini game, hoặc đang làm bài tập được giao trong modal),
// và chỉ BẬT khi đang duyệt/xem (flashcard, danh sách lớp, danh sách bài tập).
function bgRefreshStudentMusic() {
  const activePage = document.querySelector('.page.active');
  if (!activePage || activePage.id !== 'page-student') return;
  const modalOpen = document.getElementById('modal-ov')?.classList.contains('open');
  const quizVisible = document.getElementById('lt-quiz') && document.getElementById('lt-quiz').style.display !== 'none';
  const minigameVisible = document.getElementById('lt-minigame') && document.getElementById('lt-minigame').style.display !== 'none';
  const doingExercise = modalOpen || quizVisible || minigameVisible;
  if (doingExercise) stopBgMusic();
  else startBgMusic();
}

// Theo dõi việc mở/đóng modal (bài tập vocab/fill/nối từ, kết quả quiz...) để
// cập nhật nhạc ngay cả khi modal được mở bằng cách gán class trực tiếp.
(function bgWatchModal() {
  const modalEl = document.getElementById('modal-ov');
  if (!modalEl) return;
  new MutationObserver(() => bgRefreshStudentMusic())
    .observe(modalEl, { attributes: true, attributeFilter: ['class'] });
})();

function toggleBgMusic() {
  bgUserMuted = !bgUserMuted;
  const btn = document.getElementById('bg-music-toggle');
  if (bgUserMuted) {
    stopBgMusic();
    if (btn) { btn.style.display = 'flex'; btn.textContent = '🔇'; }
  } else {
    const activePage = document.querySelector('.page.active');
    const name = activePage ? activePage.id.replace('page-', '') : '';
    if (BG_MUSIC_PAGES.includes(name)) startBgMusic();
  }
}

// Nhiều trình duyệt chặn autoplay khi chưa có tương tác — mở nhạc ngay lần click/chạm đầu tiên
document.addEventListener('click', function bgFirstGesture() {
  bgEnsureCtx();
  const activePage = document.querySelector('.page.active');
  const name = activePage ? activePage.id.replace('page-', '') : '';
  if (!bgUserMuted && BG_MUSIC_PAGES.includes(name)) startBgMusic();
}, { once: true });

// ─── LESSON DATA ─────────────────────────────────────────────────────
const LESSONS = [
  // ── A1 ──────────────────────────────────────────────────────────────
  {id:'a1-greet',title:'Chào hỏi cơ bản',level:'A1',desc:'Các từ và cụm từ chào hỏi thông dụng',words:[
    {w:'Hello',p:'/həˈloʊ/',m:'Xin chào',e:'Hello, my name is Minh.'},
    {w:'Goodbye',p:'/ˌɡʊdˈbaɪ/',m:'Tạm biệt',e:'Goodbye! See you tomorrow.'},
    {w:'Thank you',p:'/ˈθæŋk juː/',m:'Cảm ơn',e:'Thank you for your help.'},
    {w:'Please',p:'/pliːz/',m:'Làm ơn',e:'Please sit down.'},
    {w:'Sorry',p:'/ˈsɒri/',m:'Xin lỗi',e:'Sorry, I am late.'},
    {w:'Good morning',p:'/ɡʊd ˈmɔːrnɪŋ/',m:'Chào buổi sáng',e:'Good morning, everyone!'},
    {w:'Good night',p:'/ɡʊd naɪt/',m:'Chúc ngủ ngon',e:'Good night, sweet dreams!'},
    {w:'How are you',p:'/haʊ ɑːr juː/',m:'Bạn có khỏe không?',e:'How are you today?'},
    {w:'Fine',p:'/faɪn/',m:'Ổn / Tốt',e:'I am fine, thank you.'},
    {w:'Nice to meet you',p:'/naɪs tə miːt juː/',m:'Rất vui được gặp bạn',e:'Nice to meet you, Anna.'},
    {w:'See you later',p:'/siː juː ˈleɪtər/',m:'Hẹn gặp lại sau',e:'See you later, take care!'},
    {w:'Welcome',p:'/ˈwɛlkəm/',m:'Chào mừng',e:'Welcome to our school!'}
  ]},
  {id:'a1-colors',title:'Màu sắc & Số đếm',level:'A1',desc:'Màu sắc cơ bản và số đếm từ 1-20',words:[
    {w:'Red',p:'/rɛd/',m:'Màu đỏ',e:'The rose is red.'},
    {w:'Blue',p:'/bluː/',m:'Màu xanh dương',e:'The sky is blue.'},
    {w:'Green',p:'/ɡriːn/',m:'Màu xanh lá',e:'Grass is green.'},
    {w:'Yellow',p:'/ˈjɛloʊ/',m:'Màu vàng',e:'The sun is yellow.'},
    {w:'White',p:'/waɪt/',m:'Màu trắng',e:'Snow is white.'},
    {w:'Black',p:'/blæk/',m:'Màu đen',e:'The night sky is black.'},
    {w:'Orange',p:'/ˈɒrɪndʒ/',m:'Màu cam',e:'She wore an orange dress.'},
    {w:'Purple',p:'/ˈpɜːrpl/',m:'Màu tím',e:'He loves purple flowers.'},
    {w:'One',p:'/wʌn/',m:'Một',e:'I have one book.'},
    {w:'Two',p:'/tuː/',m:'Hai',e:'There are two cats.'},
    {w:'Three',p:'/θriː/',m:'Ba',e:'I have three brothers.'},
    {w:'Ten',p:'/tɛn/',m:'Mười',e:'There are ten students.'},
    {w:'Twenty',p:'/ˈtwɛnti/',m:'Hai mươi',e:'She is twenty years old.'},
    {w:'Hundred',p:'/ˈhʌndrəd/',m:'Một trăm',e:'A hundred people came.'}
  ]},
  {id:'a1-family',title:'Gia đình',level:'A1',desc:'Từ vựng về các thành viên trong gia đình',words:[
    {w:'Mother',p:'/ˈmʌðər/',m:'Mẹ',e:'My mother is a teacher.'},
    {w:'Father',p:'/ˈfɑːðər/',m:'Bố',e:'My father goes to work early.'},
    {w:'Brother',p:'/ˈbrʌðər/',m:'Anh/Em trai',e:'My brother is very tall.'},
    {w:'Sister',p:'/ˈsɪstər/',m:'Chị/Em gái',e:'My sister loves music.'},
    {w:'Grandfather',p:'/ˈɡrændˌfɑːðər/',m:'Ông nội/ngoại',e:'My grandfather tells great stories.'},
    {w:'Grandmother',p:'/ˈɡrændˌmʌðər/',m:'Bà nội/ngoại',e:'My grandmother cooks well.'},
    {w:'Son',p:'/sʌn/',m:'Con trai',e:'They have one son.'},
    {w:'Daughter',p:'/ˈdɔːtər/',m:'Con gái',e:'Their daughter is smart.'},
    {w:'Uncle',p:'/ˈʌŋkəl/',m:'Chú/Bác',e:'My uncle lives in Hanoi.'},
    {w:'Aunt',p:'/ænt/',m:'Cô/Dì',e:'My aunt bakes great cakes.'},
    {w:'Cousin',p:'/ˈkʌzən/',m:'Anh/chị/em họ',e:'My cousin is my best friend.'},
    {w:'Husband',p:'/ˈhʌzbənd/',m:'Chồng',e:'Her husband is a doctor.'},
    {w:'Wife',p:'/waɪf/',m:'Vợ',e:'His wife is very kind.'}
  ]},
  {id:'a1-body',title:'Cơ thể người',level:'A1',desc:'Các bộ phận cơ thể người',words:[
    {w:'Head',p:'/hɛd/',m:'Đầu',e:'She nodded her head.'},
    {w:'Eye',p:'/aɪ/',m:'Mắt',e:'She has beautiful eyes.'},
    {w:'Nose',p:'/noʊz/',m:'Mũi',e:'My nose is cold.'},
    {w:'Mouth',p:'/maʊθ/',m:'Miệng',e:'Open your mouth wide.'},
    {w:'Ear',p:'/ɪər/',m:'Tai',e:'He has big ears.'},
    {w:'Hand',p:'/hænd/',m:'Bàn tay',e:'Wash your hands before eating.'},
    {w:'Foot',p:'/fʊt/',m:'Bàn chân',e:'My foot hurts today.'},
    {w:'Arm',p:'/ɑːrm/',m:'Cánh tay',e:'He broke his arm.'},
    {w:'Leg',p:'/lɛɡ/',m:'Chân',e:'She has long legs.'},
    {w:'Shoulder',p:'/ˈʃoʊldər/',m:'Vai',e:'He patted my shoulder.'},
    {w:'Back',p:'/bæk/',m:'Lưng',e:'My back hurts from sitting.'},
    {w:'Stomach',p:'/ˈstʌmək/',m:'Bụng',e:'I have a stomachache.'}
  ]},

  // ── A2 ──────────────────────────────────────────────────────────────
  {id:'a2-food',title:'Ẩm thực & Đồ uống',level:'A2',desc:'Từ vựng về thức ăn và đồ uống phổ biến',words:[
    {w:'Breakfast',p:'/ˈbrɛkfəst/',m:'Bữa sáng',e:'I eat breakfast at 7 AM.'},
    {w:'Lunch',p:'/lʌntʃ/',m:'Bữa trưa',e:"Let's have lunch together."},
    {w:'Dinner',p:'/ˈdɪnər/',m:'Bữa tối',e:'We had dinner at 6 PM.'},
    {w:'Delicious',p:'/dɪˈlɪʃəs/',m:'Ngon',e:'This soup is delicious!'},
    {w:'Hungry',p:'/ˈhʌŋɡri/',m:'Đói',e:'I am very hungry.'},
    {w:'Thirsty',p:'/ˈθɜːrsti/',m:'Khát',e:'I am thirsty, give me water.'},
    {w:'Rice',p:'/raɪs/',m:'Cơm / Gạo',e:'Vietnamese people eat rice every day.'},
    {w:'Noodles',p:'/ˈnuːdlz/',m:'Mì / Bún',e:'I love beef noodles.'},
    {w:'Vegetable',p:'/ˈvɛdʒtəbəl/',m:'Rau củ',e:'Eat more vegetables for health.'},
    {w:'Fruit',p:'/fruːt/',m:'Trái cây',e:'Fruit is good for your health.'},
    {w:'Chicken',p:'/ˈtʃɪkɪn/',m:'Gà',e:'I grilled the chicken.'},
    {w:'Seafood',p:'/ˈsiːfuːd/',m:'Hải sản',e:'Vietnam has great seafood.'},
    {w:'Coffee',p:'/ˈkɒfi/',m:'Cà phê',e:'I drink coffee every morning.'},
    {w:'Cake',p:'/keɪk/',m:'Bánh ngọt',e:'She baked a chocolate cake.'},
    {w:'Restaurant',p:'/ˈrɛstrɒnt/',m:'Nhà hàng',e:'Let\'s eat at a restaurant.'}
  ]},
  {id:'a2-school',title:'Trường học',level:'A2',desc:'Từ vựng về trường lớp và học tập',words:[
    {w:'Classroom',p:'/ˈklɑːsruːm/',m:'Phòng học',e:'The classroom is clean and bright.'},
    {w:'Teacher',p:'/ˈtiːtʃər/',m:'Giáo viên',e:'My teacher is very patient.'},
    {w:'Student',p:'/ˈstjuːdənt/',m:'Học sinh',e:'Each student has a notebook.'},
    {w:'Homework',p:'/ˈhoʊmwɜːrk/',m:'Bài tập về nhà',e:'Did you do your homework?'},
    {w:'Exam',p:'/ɪɡˈzæm/',m:'Kỳ thi',e:'The exam is next Monday.'},
    {w:'Pencil',p:'/ˈpɛnsəl/',m:'Bút chì',e:'Use a pencil for drawing.'},
    {w:'Notebook',p:'/ˈnoʊtbʊk/',m:'Vở ghi',e:'Write it in your notebook.'},
    {w:'Library',p:'/ˈlaɪbrəri/',m:'Thư viện',e:'I study in the library.'},
    {w:'Subject',p:'/ˈsʌbdʒɪkt/',m:'Môn học',e:'My favourite subject is English.'},
    {w:'Lesson',p:'/ˈlɛsən/',m:'Bài học',e:'Today\'s lesson is interesting.'},
    {w:'Question',p:'/ˈkwɛstʃən/',m:'Câu hỏi',e:'Do you have any questions?'},
    {w:'Answer',p:'/ˈɑːnsər/',m:'Câu trả lời',e:'What is the answer?'}
  ]},
  {id:'a2-weather',title:'Thời tiết & Thiên nhiên',level:'A2',desc:'Từ vựng mô tả thời tiết và thiên nhiên',words:[
    {w:'Sunny',p:'/ˈsʌni/',m:'Nắng',e:'It is sunny today.'},
    {w:'Rainy',p:'/ˈreɪni/',m:'Mưa',e:'Bring an umbrella, it is rainy.'},
    {w:'Cloudy',p:'/ˈklaʊdi/',m:'Nhiều mây',e:'The sky is cloudy.'},
    {w:'Windy',p:'/ˈwɪndi/',m:'Có gió',e:'It is very windy outside.'},
    {w:'Hot',p:'/hɒt/',m:'Nóng',e:'Summer is very hot here.'},
    {w:'Cold',p:'/koʊld/',m:'Lạnh',e:'It is cold in winter.'},
    {w:'Storm',p:'/stɔːrm/',m:'Bão',e:'A big storm is coming.'},
    {w:'Rainbow',p:'/ˈreɪnboʊ/',m:'Cầu vồng',e:'Look at that beautiful rainbow!'},
    {w:'Mountain',p:'/ˈmaʊntɪn/',m:'Núi',e:'Vietnam has many mountains.'},
    {w:'River',p:'/ˈrɪvər/',m:'Sông',e:'The Mekong River is very long.'},
    {w:'Ocean',p:'/ˈoʊʃən/',m:'Đại dương',e:'The ocean is deep and blue.'},
    {w:'Forest',p:'/ˈfɒrɪst/',m:'Rừng',e:'The forest is full of animals.'},
    {w:'Flower',p:'/ˈflaʊər/',m:'Hoa',e:'She gave me a red flower.'},
    {w:'Season',p:'/ˈsiːzən/',m:'Mùa',e:'My favourite season is autumn.'}
  ]},
  {id:'a2-transport',title:'Phương tiện di chuyển',level:'A2',desc:'Các loại phương tiện và từ liên quan',words:[
    {w:'Car',p:'/kɑːr/',m:'Ô tô',e:'He drives a red car.'},
    {w:'Bus',p:'/bʌs/',m:'Xe buýt',e:'Take the bus to school.'},
    {w:'Motorbike',p:'/ˈmoʊtərbaɪk/',m:'Xe máy',e:'Many people ride motorbikes in Vietnam.'},
    {w:'Bicycle',p:'/ˈbaɪsɪkəl/',m:'Xe đạp',e:'She rides her bicycle to work.'},
    {w:'Train',p:'/treɪn/',m:'Tàu hỏa',e:'The train to Hanoi is fast.'},
    {w:'Airplane',p:'/ˈɛrpleɪn/',m:'Máy bay',e:'We flew by airplane to Da Nang.'},
    {w:'Taxi',p:'/ˈtæksi/',m:'Taxi',e:'Call a taxi, please.'},
    {w:'Traffic',p:'/ˈtræfɪk/',m:'Giao thông',e:'Traffic is heavy at rush hour.'},
    {w:'Road',p:'/roʊd/',m:'Đường',e:'The road is very long.'},
    {w:'Station',p:'/ˈsteɪʃən/',m:'Nhà ga / Trạm',e:'Meet me at the station.'},
    {w:'Ticket',p:'/ˈtɪkɪt/',m:'Vé',e:'Buy a ticket before boarding.'},
    {w:'Driver',p:'/ˈdraɪvər/',m:'Tài xế',e:'The driver is very polite.'}
  ]},

  // ── B1 ──────────────────────────────────────────────────────────────
  {id:'b1-business',title:'Tiếng Anh công sở',level:'B1',desc:'Từ vựng trong môi trường làm việc',words:[
    {w:'Deadline',p:'/ˈdɛdlaɪn/',m:'Hạn chót',e:'The deadline is Friday.'},
    {w:'Meeting',p:'/ˈmiːtɪŋ/',m:'Cuộc họp',e:'We have a meeting at 9 AM.'},
    {w:'Colleague',p:'/ˈkɒliːɡ/',m:'Đồng nghiệp',e:'My colleague helped me a lot.'},
    {w:'Schedule',p:'/ˈʃɛdjuːl/',m:'Lịch trình',e:'Check the schedule today.'},
    {w:'Presentation',p:'/ˌprɛzənˈteɪʃən/',m:'Thuyết trình',e:'I gave a presentation.'},
    {w:'Report',p:'/rɪˈpɔːrt/',m:'Báo cáo',e:'Submit the report by noon.'},
    {w:'Manager',p:'/ˈmænɪdʒər/',m:'Quản lý',e:'The manager approved the plan.'},
    {w:'Budget',p:'/ˈbʌdʒɪt/',m:'Ngân sách',e:'We exceeded the budget.'},
    {w:'Client',p:'/ˈklaɪənt/',m:'Khách hàng',e:'The client is satisfied.'},
    {w:'Contract',p:'/ˈkɒntrækt/',m:'Hợp đồng',e:'Sign the contract today.'},
    {w:'Promotion',p:'/prəˈmoʊʃən/',m:'Thăng chức',e:'She got a promotion this year.'},
    {w:'Salary',p:'/ˈsæləri/',m:'Lương',e:'His salary increased last month.'},
    {w:'Interview',p:'/ˈɪntərvjuː/',m:'Phỏng vấn',e:'I have a job interview tomorrow.'},
    {w:'Resume',p:'/ˈrɛzjuːmeɪ/',m:'Hồ sơ xin việc',e:'Send your resume by email.'},
    {w:'Feedback',p:'/ˈfiːdbæk/',m:'Phản hồi',e:'Your feedback is very valuable.'}
  ]},
  {id:'b1-travel',title:'Du lịch & Di chuyển',level:'B1',desc:'Từ vựng khi đi du lịch nước ngoài',words:[
    {w:'Passport',p:'/ˈpæspɔːrt/',m:'Hộ chiếu',e:"Don't forget your passport!"},
    {w:'Boarding pass',p:'/ˈbɔːrdɪŋ pæs/',m:'Thẻ lên máy bay',e:'Show your boarding pass.'},
    {w:'Currency',p:'/ˈkʌrənsi/',m:'Tiền tệ',e:'What is the local currency?'},
    {w:'Accommodation',p:'/əˌkɒməˈdeɪʃən/',m:'Chỗ ở',e:'Book accommodation early.'},
    {w:'Itinerary',p:'/aɪˈtɪnərəri/',m:'Lịch trình chuyến đi',e:'Share your travel itinerary.'},
    {w:'Luggage',p:'/ˈlʌɡɪdʒ/',m:'Hành lý',e:'My luggage is too heavy.'},
    {w:'Check-in',p:'/ˈtʃɛkɪn/',m:'Làm thủ tục / Nhận phòng',e:'Check-in starts at 2 PM.'},
    {w:'Souvenir',p:'/ˌsuːvəˈnɪər/',m:'Đồ lưu niệm',e:'I bought souvenirs for my family.'},
    {w:'Destination',p:'/ˌdɛstɪˈneɪʃən/',m:'Điểm đến',e:'Our destination is Paris.'},
    {w:'Tour guide',p:'/tʊər ɡaɪd/',m:'Hướng dẫn viên',e:'The tour guide spoke fluent English.'},
    {w:'Visa',p:'/ˈviːzə/',m:'Thị thực',e:'Apply for a visa in advance.'},
    {w:'Delay',p:'/dɪˈleɪ/',m:'Trì hoãn',e:'The flight was delayed by an hour.'},
    {w:'Exchange rate',p:'/ɪksˈtʃeɪndʒ reɪt/',m:'Tỷ giá hối đoái',e:'Check the exchange rate first.'}
  ]},
  {id:'b1-health',title:'Sức khỏe & Y tế',level:'B1',desc:'Từ vựng về sức khỏe và bệnh viện',words:[
    {w:'Headache',p:'/ˈhɛdeɪk/',m:'Đau đầu',e:'I have a terrible headache.'},
    {w:'Fever',p:'/ˈfiːvər/',m:'Sốt',e:'She has a high fever.'},
    {w:'Medicine',p:'/ˈmɛdsɪn/',m:'Thuốc',e:'Take this medicine twice a day.'},
    {w:'Doctor',p:'/ˈdɒktər/',m:'Bác sĩ',e:'I need to see a doctor.'},
    {w:'Hospital',p:'/ˈhɒspɪtəl/',m:'Bệnh viện',e:'He was rushed to the hospital.'},
    {w:'Surgery',p:'/ˈsɜːrdʒəri/',m:'Phẫu thuật',e:'She needs surgery on her knee.'},
    {w:'Prescription',p:'/prɪˈskrɪpʃən/',m:'Đơn thuốc',e:'The doctor gave me a prescription.'},
    {w:'Allergy',p:'/ˈælərdʒi/',m:'Dị ứng',e:'I have an allergy to seafood.'},
    {w:'Symptom',p:'/ˈsɪmptəm/',m:'Triệu chứng',e:'What are your symptoms?'},
    {w:'Recovery',p:'/rɪˈkʌvəri/',m:'Sự hồi phục',e:'His recovery was quick.'},
    {w:'Exercise',p:'/ˈɛksərsaɪz/',m:'Tập thể dục',e:'Exercise keeps you healthy.'},
    {w:'Nutrition',p:'/njuːˈtrɪʃən/',m:'Dinh dưỡng',e:'Good nutrition is essential.'}
  ]},
  {id:'b1-technology',title:'Công nghệ & Internet',level:'B1',desc:'Từ vựng về công nghệ và mạng xã hội',words:[
    {w:'Software',p:'/ˈsɒftweər/',m:'Phần mềm',e:'Update your software regularly.'},
    {w:'Application',p:'/ˌæplɪˈkeɪʃən/',m:'Ứng dụng',e:'Download the application for free.'},
    {w:'Password',p:'/ˈpɑːswɜːrd/',m:'Mật khẩu',e:'Use a strong password.'},
    {w:'Website',p:'/ˈwɛbsaɪt/',m:'Trang web',e:'Visit our website for more info.'},
    {w:'Download',p:'/ˈdaʊnloʊd/',m:'Tải xuống',e:'Download the file here.'},
    {w:'Upload',p:'/ˈʌploʊd/',m:'Tải lên',e:'Upload your photo to the profile.'},
    {w:'Connection',p:'/kəˈnɛkʃən/',m:'Kết nối',e:'Check your internet connection.'},
    {w:'Virus',p:'/ˈvaɪrəs/',m:'Vi-rút máy tính',e:'A virus attacked the computer.'},
    {w:'Keyboard',p:'/ˈkiːbɔːrd/',m:'Bàn phím',e:'Type on the keyboard.'},
    {w:'Screen',p:'/skriːn/',m:'Màn hình',e:'The screen is cracked.'},
    {w:'Notification',p:'/ˌnoʊtɪfɪˈkeɪʃən/',m:'Thông báo',e:'Turn off notifications at night.'},
    {w:'Artificial intelligence',p:'/ˌɑːrtɪˈfɪʃəl ɪnˈtɛlɪdʒəns/',m:'Trí tuệ nhân tạo',e:'AI is changing the world.'}
  ]},

  // ── B2 ──────────────────────────────────────────────────────────────
  {id:'b2-academic',title:'Học thuật nâng cao',level:'B2',desc:'Từ vựng cho IELTS, TOEFL',words:[
    {w:'Phenomenon',p:'/fɪˈnɒmɪnɒn/',m:'Hiện tượng',e:'Climate change is a global phenomenon.'},
    {w:'Hypothesis',p:'/haɪˈpɒθɪsɪs/',m:'Giả thuyết',e:'Scientists test the hypothesis.'},
    {w:'Controversial',p:'/ˌkɒntrəˈvɜːrʃəl/',m:'Gây tranh cãi',e:'This is a controversial topic.'},
    {w:'Subsequently',p:'/ˈsʌbsɪkwəntli/',m:'Tiếp theo đó',e:'Subsequently, he resigned.'},
    {w:'Elaborate',p:'/ɪˈlæbərɪt/',m:'Chi tiết / Công phu',e:'She gave an elaborate explanation.'},
    {w:'Implication',p:'/ˌɪmplɪˈkeɪʃən/',m:'Hàm ý / Tác động',e:'Consider the implications carefully.'},
    {w:'Methodology',p:'/ˌmɛθəˈdɒlədʒi/',m:'Phương pháp luận',e:'Explain your research methodology.'},
    {w:'Perspective',p:'/pərˈspɛktɪv/',m:'Quan điểm',e:'From a different perspective.'},
    {w:'Significant',p:'/sɪɡˈnɪfɪkənt/',m:'Đáng kể / Quan trọng',e:'A significant improvement was noted.'},
    {w:'Framework',p:'/ˈfreɪmwɜːrk/',m:'Khung / Khuôn khổ',e:'A new theoretical framework.'},
    {w:'Evidence',p:'/ˈɛvɪdəns/',m:'Bằng chứng',e:'Provide strong evidence for your claim.'},
    {w:'Analysis',p:'/əˈnæləsɪs/',m:'Phân tích',e:'The analysis shows clear results.'}
  ]},
  {id:'b2-environment',title:'Môi trường & Xã hội',level:'B2',desc:'Từ vựng về môi trường và các vấn đề xã hội',words:[
    {w:'Sustainability',p:'/səˌsteɪnəˈbɪlɪti/',m:'Tính bền vững',e:'Sustainability is key to the future.'},
    {w:'Pollution',p:'/pəˈluːʃən/',m:'Ô nhiễm',e:'Air pollution is a serious problem.'},
    {w:'Renewable',p:'/rɪˈnjuːəbəl/',m:'Tái tạo được',e:'Solar is a renewable energy source.'},
    {w:'Carbon footprint',p:'/ˈkɑːrbən ˈfʊtprɪnt/',m:'Lượng khí thải carbon',e:'Reduce your carbon footprint.'},
    {w:'Deforestation',p:'/ˌdiːˌfɒrɪˈsteɪʃən/',m:'Phá rừng',e:'Deforestation threatens biodiversity.'},
    {w:'Greenhouse gas',p:'/ˈɡriːnhaʊs ɡæs/',m:'Khí nhà kính',e:'Greenhouse gases cause warming.'},
    {w:'Overpopulation',p:'/ˌoʊvərˌpɒpjʊˈleɪʃən/',m:'Quá tải dân số',e:'Overpopulation is a global concern.'},
    {w:'Inequality',p:'/ˌɪnɪˈkwɒlɪti/',m:'Bất bình đẳng',e:'Income inequality is growing.'},
    {w:'Discrimination',p:'/dɪˌskrɪmɪˈneɪʃən/',m:'Phân biệt đối xử',e:'Discrimination must be stopped.'},
    {w:'Biodiversity',p:'/ˌbaɪoʊdaɪˈvɜːrsɪti/',m:'Đa dạng sinh học',e:'Protect biodiversity at all costs.'},
    {w:'Recycling',p:'/ˌriːˈsaɪklɪŋ/',m:'Tái chế',e:'Recycling reduces waste greatly.'},
    {w:'Conservation',p:'/ˌkɒnsərˈveɪʃən/',m:'Bảo tồn',e:'Wildlife conservation is vital.'}
  ]},
  {id:'b2-emotions',title:'Cảm xúc & Tính cách',level:'B2',desc:'Diễn đạt cảm xúc và mô tả tính cách',words:[
    {w:'Enthusiastic',p:'/ɪnˌθjuːziˈæstɪk/',m:'Nhiệt tình',e:'She is enthusiastic about learning.'},
    {w:'Frustrated',p:'/ˈfrʌstreɪtɪd/',m:'Thất vọng / Bực bội',e:'He felt frustrated with the delay.'},
    {w:'Anxious',p:'/ˈæŋkʃəs/',m:'Lo lắng',e:'She felt anxious before the exam.'},
    {w:'Compassionate',p:'/kəmˈpæʃənɪt/',m:'Có lòng trắc ẩn',e:'A compassionate leader listens well.'},
    {w:'Optimistic',p:'/ˌɒptɪˈmɪstɪk/',m:'Lạc quan',e:'Stay optimistic even in hard times.'},
    {w:'Stubborn',p:'/ˈstʌbərn/',m:'Bướng bỉnh',e:'He is too stubborn to change.'},
    {w:'Generous',p:'/ˈdʒɛnərəs/',m:'Hào phóng',e:'She is very generous with her time.'},
    {w:'Ambitious',p:'/æmˈbɪʃəs/',m:'Tham vọng',e:'She is ambitious and hardworking.'},
    {w:'Overwhelmed',p:'/ˌoʊvərˈwɛlmd/',m:'Quá tải / Choáng ngợp',e:'I feel overwhelmed with work.'},
    {w:'Confident',p:'/ˈkɒnfɪdənt/',m:'Tự tin',e:'Be confident in your abilities.'},
    {w:'Empathy',p:'/ˈɛmpəθi/',m:'Sự đồng cảm',e:'Show empathy to those in need.'},
    {w:'Resilient',p:'/rɪˈzɪliənt/',m:'Kiên cường',e:'She is resilient in difficult times.'}
  ]},
  {id:'b2-idioms',title:'Thành ngữ thông dụng',level:'B2',desc:'Các idiom thường gặp trong giao tiếp',words:[
    {w:'Break the ice',p:'/breɪk ðə aɪs/',m:'Phá vỡ sự im lặng / Làm quen',e:'He told a joke to break the ice.'},
    {w:'Hit the nail on the head',p:'/hɪt ðə neɪl ɒn ðə hɛd/',m:'Nói đúng vấn đề',e:'You hit the nail on the head!'},
    {w:'Under the weather',p:'/ˈʌndər ðə ˈwɛðər/',m:'Cảm thấy không khỏe',e:'I am feeling under the weather today.'},
    {w:'Piece of cake',p:'/piːs əv keɪk/',m:'Chuyện dễ như ăn bánh',e:'The test was a piece of cake.'},
    {w:'Bite the bullet',p:'/baɪt ðə ˈbʊlɪt/',m:'Cắn răng chịu đựng',e:'Just bite the bullet and do it.'},
    {w:'Cost an arm and a leg',p:'/kɒst ən ɑːrm ənd ə lɛɡ/',m:'Rất đắt tiền',e:'That car costs an arm and a leg.'},
    {w:'Once in a blue moon',p:'/wʌns ɪn ə bluː muːn/',m:'Rất hiếm khi',e:'He visits once in a blue moon.'},
    {w:'Spill the beans',p:'/spɪl ðə biːnz/',m:'Tiết lộ bí mật',e:'Don\'t spill the beans about the party.'},
    {w:'Let the cat out of the bag',p:'/lɛt ðə kæt aʊt əv ðə bæɡ/',m:'Lỡ miệng tiết lộ',e:'He let the cat out of the bag.'},
    {w:'Hit the sack',p:'/hɪt ðə sæk/',m:'Đi ngủ',e:'I need to hit the sack early tonight.'},
    {w:'Bite off more than you can chew',p:'/baɪt ɒf mɔːr ðæn juː kæn tʃuː/',m:'Nhận việc quá sức',e:'Don\'t bite off more than you can chew.'},
    {w:'Kill two birds with one stone',p:'/kɪl tuː bɜːrdz wɪð wʌn stoʊn/',m:'Một công đôi việc',e:'Take the shortcut — kill two birds with one stone.'}
  ]},

  // ── IELTS / Advanced ─────────────────────────────────────────────────
  {id:'b2-ielts-vocab',title:'IELTS Writing & Speaking',level:'B2',desc:'Từ vựng band 7.0+ cho IELTS',words:[
    {w:'Mitigate',p:'/ˈmɪtɪɡeɪt/',m:'Giảm nhẹ / Xoa dịu',e:'Measures to mitigate climate change.'},
    {w:'Exacerbate',p:'/ɪɡˈzæsərbeɪt/',m:'Làm trầm trọng thêm',e:'Stress can exacerbate the illness.'},
    {w:'Proliferate',p:'/prəˈlɪfəreɪt/',m:'Phát triển nhanh chóng',e:'Technology has proliferated rapidly.'},
    {w:'Prevalent',p:'/ˈprɛvələnt/',m:'Phổ biến',e:'Smartphones are prevalent worldwide.'},
    {w:'Advocate',p:'/ˈædvəkeɪt/',m:'Ủng hộ / Người bảo vệ',e:'She advocates for equal rights.'},
    {w:'Detrimental',p:'/ˌdɛtrɪˈmɛntəl/',m:'Có hại',e:'Smoking is detrimental to health.'},
    {w:'Inevitable',p:'/ɪnˈɛvɪtəbəl/',m:'Không thể tránh khỏi',e:'Change is inevitable.'},
    {w:'Scrutinize',p:'/ˈskruːtɪnaɪz/',m:'Xem xét kỹ lưỡng',e:'The plan was scrutinized carefully.'},
    {w:'Pragmatic',p:'/præɡˈmætɪk/',m:'Thực dụng',e:'We need a pragmatic approach.'},
    {w:'Coherent',p:'/koʊˈhɪərənt/',m:'Mạch lạc / Nhất quán',e:'Give a coherent argument.'},
    {w:'Concede',p:'/kənˈsiːd/',m:'Nhượng bộ / Thừa nhận',e:'I concede that you have a point.'},
    {w:'Juxtapose',p:'/ˈdʒʌkstəpoʊz/',m:'Đặt cạnh nhau để so sánh',e:'The author juxtaposes joy and grief.'}
  ]},

  // ── A1-A2: Chủ đề mới ─────────────────────────────────────────────────
  {id:'a2-jobs',title:'Công việc & Nghề nghiệp',level:'A2',desc:'Từ vựng về các nghề nghiệp phổ biến',words:[
    {w:'Teacher',p:'/ˈtiːtʃər/',m:'Giáo viên',e:'My teacher is very kind.'},
    {w:'Doctor',p:'/ˈdɒktər/',m:'Bác sĩ',e:'The doctor checked my heart.'},
    {w:'Engineer',p:'/ˌɛndʒɪˈnɪər/',m:'Kỹ sư',e:'He works as an engineer.'},
    {w:'Nurse',p:'/nɜːrs/',m:'Y tá',e:'The nurse gave me medicine.'},
    {w:'Farmer',p:'/ˈfɑːrmər/',m:'Nông dân',e:'The farmer grows rice.'},
    {w:'Police officer',p:'/pəˈliːs ˈɒfɪsər/',m:'Cảnh sát',e:'The police officer helped us.'},
    {w:'Chef',p:'/ʃɛf/',m:'Đầu bếp',e:'The chef cooked a delicious meal.'},
    {w:'Driver',p:'/ˈdraɪvər/',m:'Tài xế',e:'The bus driver is friendly.'},
    {w:'Lawyer',p:'/ˈlɔɪər/',m:'Luật sư',e:'She hired a good lawyer.'},
    {w:'Salary',p:'/ˈsæləri/',m:'Tiền lương',e:'He gets a good salary.'},
    {w:'Office',p:'/ˈɒfɪs/',m:'Văn phòng',e:'I work in an office.'},
    {w:'Interview',p:'/ˈɪntərvjuː/',m:'Buổi phỏng vấn',e:'She has a job interview today.'}
  ]},
  {id:'a2-travel',title:'Du lịch & Giao thông',level:'A2',desc:'Từ vựng về phương tiện và chuyến đi',words:[
    {w:'Airport',p:'/ˈɛərpɔːrt/',m:'Sân bay',e:'We arrived at the airport early.'},
    {w:'Ticket',p:'/ˈtɪkɪt/',m:'Vé',e:'I bought a train ticket.'},
    {w:'Passport',p:'/ˈpæspɔːrt/',m:'Hộ chiếu',e:"Don't forget your passport."},
    {w:'Luggage',p:'/ˈlʌɡɪdʒ/',m:'Hành lý',e:'My luggage is very heavy.'},
    {w:'Train station',p:'/treɪn ˈsteɪʃən/',m:'Nhà ga',e:'The train station is crowded.'},
    {w:'Bus stop',p:'/bʌs stɒp/',m:'Trạm xe buýt',e:'Wait at the bus stop.'},
    {w:'Taxi',p:'/ˈtæksi/',m:'Taxi',e:'We took a taxi to the hotel.'},
    {w:'Map',p:'/mæp/',m:'Bản đồ',e:'Use the map to find your way.'},
    {w:'Hotel',p:'/hoʊˈtɛl/',m:'Khách sạn',e:'We stayed at a nice hotel.'},
    {w:'Journey',p:'/ˈdʒɜːrni/',m:'Chuyến đi',e:'It was a long journey.'},
    {w:'Departure',p:'/dɪˈpɑːrtʃər/',m:'Khởi hành',e:'The departure time is 9 AM.'},
    {w:'Arrival',p:'/əˈraɪvəl/',m:'Đến nơi',e:'Our arrival was delayed.'}
  ]},
  {id:'a2-seasons',title:'Thời tiết & Mùa',level:'A2',desc:'Từ vựng về thời tiết và các mùa trong năm',words:[
    {w:'Sunny',p:'/ˈsʌni/',m:'Nắng',e:'Today is sunny and warm.'},
    {w:'Rainy',p:'/ˈreɪni/',m:'Mưa',e:'It is rainy outside.'},
    {w:'Cloudy',p:'/ˈklaʊdi/',m:'Nhiều mây',e:'The sky is cloudy today.'},
    {w:'Windy',p:'/ˈwɪndi/',m:'Có gió',e:'It is very windy today.'},
    {w:'Snow',p:'/snoʊ/',m:'Tuyết',e:'It started to snow last night.'},
    {w:'Hot',p:'/hɒt/',m:'Nóng',e:'Summer is very hot here.'},
    {w:'Cold',p:'/koʊld/',m:'Lạnh',e:'Winter is cold and dry.'},
    {w:'Spring',p:'/sprɪŋ/',m:'Mùa xuân',e:'Flowers bloom in spring.'},
    {w:'Summer',p:'/ˈsʌmər/',m:'Mùa hè',e:'We go swimming in summer.'},
    {w:'Autumn',p:'/ˈɔːtəm/',m:'Mùa thu',e:'Leaves fall in autumn.'},
    {w:'Winter',p:'/ˈwɪntər/',m:'Mùa đông',e:'It snows in winter.'},
    {w:'Temperature',p:'/ˈtɛmprətʃər/',m:'Nhiệt độ',e:'The temperature dropped today.'}
  ]},
  {id:'a2-tech',title:'Công nghệ & Máy tính',level:'A2',desc:'Từ vựng cơ bản về công nghệ',words:[
    {w:'Computer',p:'/kəmˈpjuːtər/',m:'Máy tính',e:'I use a computer every day.'},
    {w:'Phone',p:'/foʊn/',m:'Điện thoại',e:'My phone battery is low.'},
    {w:'Internet',p:'/ˈɪntərnɛt/',m:'Internet',e:'The internet is very fast here.'},
    {w:'Password',p:'/ˈpæswɜːrd/',m:'Mật khẩu',e:'I forgot my password.'},
    {w:'Email',p:'/ˈiːmeɪl/',m:'Thư điện tử',e:'Please send me an email.'},
    {w:'Screen',p:'/skriːn/',m:'Màn hình',e:'The screen is too bright.'},
    {w:'Keyboard',p:'/ˈkiːbɔːrd/',m:'Bàn phím',e:'My keyboard is broken.'},
    {w:'Download',p:'/ˈdaʊnloʊd/',m:'Tải xuống',e:'I need to download this app.'},
    {w:'Upload',p:'/ˈʌploʊd/',m:'Tải lên',e:'Upload your photo here.'},
    {w:'Website',p:'/ˈwɛbsaɪt/',m:'Trang web',e:'Visit our website for more info.'},
    {w:'Wifi',p:'/ˈwaɪfaɪ/',m:'Mạng không dây',e:'The wifi is not working.'},
    {w:'Charger',p:'/ˈtʃɑːrdʒər/',m:'Bộ sạc',e:'Can I borrow your charger?'}
  ]},
  {id:'a2-shopping',title:'Mua sắm & Tiền bạc',level:'A2',desc:'Từ vựng về mua sắm và tiền bạc',words:[
    {w:'Money',p:'/ˈmʌni/',m:'Tiền',e:"I don't have much money."},
    {w:'Price',p:'/praɪs/',m:'Giá cả',e:'The price is too high.'},
    {w:'Cheap',p:'/tʃiːp/',m:'Rẻ',e:'This shirt is very cheap.'},
    {w:'Expensive',p:'/ɪkˈspɛnsɪv/',m:'Đắt',e:'That car is expensive.'},
    {w:'Discount',p:'/ˈdɪskaʊnt/',m:'Giảm giá',e:'I got a 20% discount.'},
    {w:'Receipt',p:'/rɪˈsiːt/',m:'Hóa đơn',e:'Keep your receipt, please.'},
    {w:'Cash',p:'/kæʃ/',m:'Tiền mặt',e:'I prefer to pay in cash.'},
    {w:'Credit card',p:'/ˈkrɛdɪt kɑːrd/',m:'Thẻ tín dụng',e:'I paid with my credit card.'},
    {w:'Shop',p:'/ʃɒp/',m:'Cửa hàng',e:'There is a shop near my house.'},
    {w:'Market',p:'/ˈmɑːrkɪt/',m:'Chợ',e:'We buy vegetables at the market.'},
    {w:'Sale',p:'/seɪl/',m:'Đợt giảm giá',e:'The store is having a big sale.'},
    {w:'Customer',p:'/ˈkʌstəmər/',m:'Khách hàng',e:'The customer was very happy.'}
  ]},
  {id:'a2-sports',title:'Thể thao & Sức khỏe',level:'A2',desc:'Từ vựng về thể thao và sức khỏe',words:[
    {w:'Football',p:'/ˈfʊtbɔːl/',m:'Bóng đá',e:'We play football every weekend.'},
    {w:'Swimming',p:'/ˈswɪmɪŋ/',m:'Bơi lội',e:'Swimming is good exercise.'},
    {w:'Running',p:'/ˈrʌnɪŋ/',m:'Chạy bộ',e:'I go running in the morning.'},
    {w:'Gym',p:'/dʒɪm/',m:'Phòng tập gym',e:'He goes to the gym every day.'},
    {w:'Healthy',p:'/ˈhɛlθi/',m:'Khỏe mạnh',e:'Eating fruit is healthy.'},
    {w:'Exercise',p:'/ˈɛksərsaɪz/',m:'Tập thể dục',e:'Exercise makes you stronger.'},
    {w:'Strong',p:'/strɒŋ/',m:'Khỏe / Mạnh',e:'He is very strong.'},
    {w:'Tired',p:'/ˈtaɪərd/',m:'Mệt mỏi',e:'I feel tired after running.'},
    {w:'Team',p:'/tiːm/',m:'Đội',e:'Our team won the match.'},
    {w:'Coach',p:'/koʊtʃ/',m:'Huấn luyện viên',e:'The coach trains us hard.'},
    {w:'Match',p:'/mætʃ/',m:'Trận đấu',e:'The match starts at 7 PM.'},
    {w:'Champion',p:'/ˈtʃæmpiən/',m:'Nhà vô địch',e:'She became the champion.'}
  ]}
];

const SENTENCES = [
  "The quick brown fox jumps over the lazy dog.",
  "Learning English opens many doors in life.",
  "Practice makes perfect every single day.",
  "Reading books is the best way to improve your English.",
  "Communication is the key to success in any field.",
  "Every journey begins with a single step forward.",
  "Hard work and dedication lead to great achievements.",
  "The weather today is sunny and beautiful outside.",
  "Technology has changed the way we communicate forever.",
  "Travelling abroad broadens your mind and perspective.",
  "A healthy diet and regular exercise improve your life.",
  "She studied hard and passed the IELTS exam with flying colours.",
  "The meeting was postponed due to bad weather conditions.",
  "Innovation is the driving force behind economic growth.",
  "Never give up on your dreams, no matter how hard it gets.",
  "Biodiversity is essential for a healthy planet and ecosystem.",
  "Social media has both positive and negative effects on society.",
  "He submitted the report before the deadline successfully.",
  "Climate change is one of the most serious challenges we face.",
  "Consistent practice is more effective than occasional cramming."
];

// ─── STATE ────────────────────────────────────────────────────────────
let currentUser = null, currentProfile = null;
let liRole = 'student';
let _suppressSignOutRedirect = false; // true khi signOut() được gọi chủ động từ trong doLogin (tài khoản khoá / sai vai trò) để không bị đá về trang chủ
let mySessionToken = null;   // mã phiên đăng nhập hiện tại của tab này
let sessionGuardInterval = null; // interval kiểm tra xem tài khoản có bị đăng nhập ở nơi khác không

let selectedRole = 'student';
function viErr(msg) {
  if (!msg) return 'Đã xảy ra lỗi.';
  const m = msg.toLowerCase();
  // Email không hợp lệ
  if (m.includes('invalid email') || m.includes('email address is invalid') || m.includes('unable to validate email')) return 'Địa chỉ email không hợp lệ. Vui lòng nhập đúng định dạng (vd: ten@gmail.com).';
  // Sai mật khẩu / credentials
  if (m.includes('invalid login') || m.includes('invalid credentials') || m.includes('wrong password') || (m.includes('invalid') && m.includes('password'))) return 'Email hoặc mật khẩu không đúng.';
  // Chưa xác nhận email
  if (m.includes('email not confirmed') || m.includes('confirm') || m.includes('verified')) return 'Vui lòng xác nhận email trước khi đăng nhập. Kiểm tra hộp thư (cả thư mục Spam).';
  // Rate limit
  if (m.includes('too many') || m.includes('rate limit') || m.includes('email rate')) return 'Quá nhiều yêu cầu. Vui lòng chờ vài phút rồi thử lại.';
  // Email đã tồn tại
  if (m.includes('already registered') || m.includes('user already') || (m.includes('unique') && m.includes('email'))) return 'Email này đã được đăng ký. Vui lòng đăng nhập hoặc dùng email khác.';
  // Mật khẩu yếu
  if (m.includes('password') && (m.includes('weak') || m.includes('short') || m.includes('least'))) return 'Mật khẩu quá yếu. Cần ít nhất 6 ký tự.';
  // Lỗi DB
  if (m.includes('duplicate') || m.includes('unique constraint')) return 'Dữ liệu bị trùng. Vui lòng thử lại.';
  if (m.includes('foreign key')) return 'Lỗi liên kết dữ liệu. Vui lòng đăng xuất và thử lại.';
  if (m.includes('violates row-level') || m.includes('rls')) return 'Không có quyền thực hiện thao tác này.';
  // Mạng
  if (m.includes('network') || m.includes('fetch') || m.includes('failed to fetch')) return 'Lỗi kết nối mạng. Kiểm tra internet và thử lại.';
  // Redirect
  if (m.includes('redirect') || m.includes('path is invalid')) return 'Lỗi cấu hình URL. Liên hệ quản trị viên.';
  return msg;
}
function showErr(id, msg) { const el = document.getElementById(id); el.textContent = msg; el.classList.add('show'); }
function hideErr(id) { document.getElementById(id).classList.remove('show'); }
function showOk(id, msg) { const el = document.getElementById(id); el.textContent = msg; el.className = 'alert alert-ok show'; }
function randCode(n=6) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let r = '';
  for (let i = 0; i < n; i++) r += chars[Math.floor(Math.random() * chars.length)];
  return r;
}
function genUniqueCode() {
  const ts = Date.now().toString(36).toUpperCase().slice(-4);
  const code = ts + randCode(4);
  const link = randCode(6) + ts + randCode(6);
  return { code, link };
}

// ─── MINI GAME 2: TINY CHEF BAKERY ──────────────────────────────
function showPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('page-' + name)?.classList.add('active');
  bgApplyForPage(name);
  if (name === 'leaderboard') loadLeaderboard();
  if (name === 'vocab') loadVocab();
  if (name === 'admin') loadAdmin();
  if (name === 'change-pw') {
    // Điền tên và email hiện tại
    const nameEl = document.getElementById('cn-name');
    if (nameEl && currentProfile?.full_name) nameEl.value = currentProfile.full_name;
    const emailEl = document.getElementById('acct-email-display');
    if (emailEl && currentUser?.email) emailEl.textContent = '📧 ' + currentUser.email;
    // Reset các field khác
    ['cn-err','cn-ok','cp-err','cp-ok'].forEach(id => {
      const el = document.getElementById(id); if (el) el.textContent = '';
    });
    ['cp-pw1','cp-pw2'].forEach(id => {
      const el = document.getElementById(id); if (el) el.value = '';
    });
    const bar2 = document.getElementById('pass-bar2');
    if (bar2) bar2.style.width = '0';
    const hint2 = document.getElementById('pass-hint2');
    if (hint2) hint2.textContent = '';
  }
}

function backToDash() {
  const role = currentProfile?.role || 'student';
  if (role === 'teacher') showPage('teacher');
  else if (role === 'admin') showPage('admin');
  else showPage('student');
}

// ─── NAV ─────────────────────────────────────────────────────────────
function updateNav() {
  const p = currentProfile;
  if (!p) {
    document.getElementById('nav-guest').style.display = 'flex';
    document.getElementById('nav-user').style.display = 'none';
    return;
  }
  document.getElementById('nav-guest').style.display = 'none';
  document.getElementById('nav-user').style.display = 'flex';
  document.getElementById('nav-name').textContent = p.full_name || p.email?.split('@')[0] || 'Người dùng';
  const badge = document.getElementById('nav-role-badge');
  const roleLabels = { student: '📚 Học sinh', teacher: '🎓 Giáo viên', admin: '⚙️ Admin' };
  badge.textContent = roleLabels[p.role] || 'Học sinh';
  badge.className = `badge-role badge-${p.role || 'student'}`;
  updateNotifBadge();
}

// ─── THÔNG BÁO (dành cho học sinh) ─────────────────────────────────────
function renderDesc(text) {
  if (!text) return '';
  return text
    .split('\n').join('<br>')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/_(.*?)_/g, '<em>$1</em>');
}

function escHtml(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function showModal(emoji, title, body, btnText, action) {
  document.getElementById('m-em').textContent = emoji;
  document.getElementById('m-title').textContent = title;
  document.getElementById('m-body').textContent = body;
  const btn = document.getElementById('m-btn');
  btn.textContent = btnText; btn.onclick = action;
  document.getElementById('modal-ov').classList.add('open');
}
function closeModal() {
  document.getElementById('modal-ov').classList.remove('open');
  const btn = document.getElementById('m-btn');
  if (btn) btn.style.display = '';  // hiện lại nút cho lần sau
  const body = document.getElementById('m-body');
  if (body) body.innerHTML = '';    // xoá HTML còn sót
}

// ─── MINI GAME: MAGIC WORD ISLAND ─────────────────────────────────
let mwiInited = false;
let bakeryInited = false;

