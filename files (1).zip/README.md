# EduEnglish — Ứng dụng học tiếng Anh cho học sinh

Ứng dụng web học tiếng Anh dành cho 3 vai trò: **Học sinh**, **Giáo viên**, **Quản trị viên**, xây dựng bằng HTML/CSS/JavaScript thuần (không cần build tool) và dùng [Supabase](https://supabase.com) làm backend (xác thực người dùng + database + lưu trữ ảnh).

## 📁 Cấu trúc thư mục

| File | Nội dung |
|---|---|
| `index.html` | Cấu trúc giao diện (HTML) của toàn bộ ứng dụng |
| `style.css` | Toàn bộ style/giao diện |
| `core.js` | Cấu hình Supabase, dữ liệu bài học, biến trạng thái dùng chung, các hàm tiện ích dùng chung (modal, điều hướng trang, nhạc nền...) |
| `auth.js` | Đăng ký / đăng nhập / đăng xuất / quên mật khẩu / đổi mật khẩu / bảo vệ phiên đăng nhập |
| `student.js` | Toàn bộ chức năng dành cho học sinh (flashcard, quiz, bài tập, từ điển, streak, thông báo lớp...) |
| `teacher.js` | Toàn bộ chức năng dành cho giáo viên (quản lý lớp, giao bài tập, duyệt học sinh, xem kết quả...) |
| `admin.js` | Toàn bộ chức năng dành cho quản trị viên (quản lý người dùng, lớp học, thống kê hệ thống) |
| `games.js` | 4 mini game trực quan (Đảo Từ Vựng, Nghe & Chọn, Lật Thẻ Nhớ, Tiệm Bánh) |
| `database-setup.sql` | Các câu lệnh SQL cần chạy trong Supabase SQL Editor để thiết lập database |

> **Lưu ý thứ tự tải file:** `index.html` tải các file JS theo đúng thứ tự `core.js → student.js → teacher.js → admin.js → games.js → auth.js`. Thứ tự này quan trọng vì `auth.js` chứa đoạn code khởi động ứng dụng (chạy cuối cùng, sau khi mọi hàm khác đã được định nghĩa).

## 🚀 Cách chạy thử

Vì đây là ứng dụng tĩnh (không cần server backend riêng), bạn chỉ cần:

1. Clone repo này về máy.
2. Mở file `index.html` trực tiếp bằng trình duyệt, **hoặc** dùng 1 local server đơn giản, ví dụ:
   ```bash
   npx serve .
   ```
3. Cấu hình project Supabase của riêng bạn (xem mục bên dưới).

## ⚙️ Thiết lập Supabase

1. Tạo project mới tại [supabase.com](https://supabase.com).
2. Vào **SQL Editor**, chạy toàn bộ nội dung file `database-setup.sql` để tạo các bảng/cột cần thiết.
3. Vào **Storage**, tạo bucket tên `assignments`, bật chế độ **Public**, và thêm policy cho phép đọc công khai:
   ```sql
   CREATE POLICY "Public read for assignments bucket"
   ON storage.objects FOR SELECT
   USING (bucket_id = 'assignments');
   ```
4. Vào **Project Settings → API**, lấy `Project URL` và `anon public key`, dán vào phần cấu hình Supabase ở đầu file `app.js` (tìm đoạn `SUPABASE_URL` / `SUPABASE_ANON_KEY`).

## ✨ Tính năng chính

- **Học sinh:** flashcard từ vựng, quiz trắc nghiệm, nối từ, mini game (Đảo Từ Vựng, Nghe & Chọn, Lật Thẻ Nhớ, Tiệm Bánh), làm bài tập được giao, xem thông báo lớp học, tham gia lớp học.
- **Giáo viên:** tạo/quản lý lớp học, giao bài tập (từ vựng, điền khuyết, nối từ, quiz, thông báo), duyệt học sinh tham gia lớp, xem kết quả & chi tiết đúng/sai từng học sinh.
- **Quản trị viên:** quản lý người dùng, quản lý lớp học, xem thống kê hệ thống.

## 🔒 Bảo mật

- Mỗi tài khoản chỉ được đăng nhập tại 1 nơi trong cùng 1 thời điểm (single-session).
- Kiểm tra vai trò khi đăng nhập, chặn tài khoản bị khoá.
