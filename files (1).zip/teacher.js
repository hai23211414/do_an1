async function loadTeacherDash() {
  const p = currentProfile;
  document.getElementById('tc-greet').textContent = `Chào ${p?.full_name || 'thầy/cô'}! 👋`;
  await loadTeacherClasses();
  await loadTeacherStats();
}

async function loadTeacherStats() {
  if (!currentUser) return;
  // Đếm yêu cầu pending
  const { data: myClasses } = await sb.from('classes').select('id').eq('teacher_id', currentUser.id);
  if (!myClasses || myClasses.length === 0) return;
  const classIds = myClasses.map(c => c.id);
  const { data: reqs } = await sb.from('class_members').select('id').in('class_id', classIds).eq('status', 'pending');
  const { data: members } = await sb.from('class_members').select('id').in('class_id', classIds).eq('status', 'approved');
  const reqCount = reqs?.length || 0;
  document.getElementById('tc-total-classes').textContent = myClasses.length;
  document.getElementById('tc-total-students').textContent = members?.length || 0;
  document.getElementById('tc-total-reqs').textContent = reqCount;
  document.getElementById('req-count').textContent = reqCount;
  const badge = document.getElementById('req-count-badge');
  badge.style.display = reqCount > 0 ? 'inline-flex' : 'none';
}

async function loadTeacherClasses() {
  if (!currentUser) return;
  const el = document.getElementById('tc-classes');
  const { data } = await sb.from('classes').select('*').eq('teacher_id', currentUser.id).order('created_at', { ascending: false });
  if (!data || data.length === 0) { el.innerHTML = '<div class="empty"><div class="empty-icon">🏫</div><p>Chưa có lớp nào.<br>Tạo lớp đầu tiên!</p></div>'; return; }
  // Load thêm số học sinh và pending cho mỗi lớp
  const classIds = data.map(c => c.id);
  const { data: allMembers } = await sb.from('class_members').select('class_id,status').in('class_id', classIds);
  const memberMap = {};
  const pendingMap = {};
  (allMembers || []).forEach(m => {
    if (m.status === 'approved') memberMap[m.class_id] = (memberMap[m.class_id] || 0) + 1;
    if (m.status === 'pending') pendingMap[m.class_id] = (pendingMap[m.class_id] || 0) + 1;
  });

  el.innerHTML = `<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px">` +
  data.map(c => {
    const students = memberMap[c.id] || 0;
    const pending = pendingMap[c.id] || 0;
    const safeDesc = (c.description||'').replace(/'/g,"\'");
    const safeCode = c.class_code || '';
    const safeLink = c.class_link || '';
    const safeName = c.name.replace(/'/g,"\'");
    return `
    <div class="ev-open-class" data-id="${c.id}" data-name="${safeName}" data-desc="${safeDesc}" data-code="${safeCode}" data-link="${safeLink}"
      style="background:#ffffff;border:1.5px solid #ffd966;border-radius:14px;cursor:pointer;
             transition:all .15s;overflow:hidden;display:flex;flex-direction:column"
      onmouseover="this.style.borderColor='var(--pur)';this.style.boxShadow='0 4px 20px rgba(0,0,0,.10)';this.style.transform='translateY(-2px)'"
      onmouseout="this.style.borderColor='#ffd966';this.style.boxShadow='none';this.style.transform='none'">

      <!-- Header màu -->
      <div style="background:linear-gradient(135deg,#f3e8ff,#e0e7ff);padding:16px 18px;display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <div style="font-size:16px;font-weight:700;color:#1a1814;margin-bottom:3px">${c.name}</div>
          <div style="font-size:12px;color:#666">${c.description || 'Nhấn để xem chi tiết lớp'}</div>
        </div>
        ${pending > 0
          ? `<span style="background:var(--gold);color:#fff;font-size:11px;font-weight:700;padding:3px 9px;border-radius:99px;white-space:nowrap;flex-shrink:0">🔔 ${pending}</span>`
          : `<span style="font-size:18px;color:var(--pur);opacity:.5">›</span>`}
      </div>

      <!-- Body -->
      <div style="padding:14px 18px;display:flex;align-items:center;justify-content:space-between;gap:10px">
        <div style="display:flex;align-items:center;gap:6px">
          <span style="font-size:16px;font-weight:700;font-family:monospace;color:var(--pur);
                       background:#f3e8ff;padding:5px 12px;border-radius:8px;letter-spacing:2px">${safeCode}</span>
        </div>
        <div style="display:flex;align-items:center;gap:12px">
          <div style="text-align:center">
            <div style="font-size:16px;font-weight:700;color:var(--acc)">${students}</div>
            <div style="font-size:10px;color:#aaa">Học sinh</div>
          </div>
          <div style="text-align:center">
            <div style="font-size:16px;font-weight:700;color:${pending > 0 ? 'var(--gold)' : '#9a948a'}">${pending}</div>
            <div style="font-size:10px;color:#aaa">Chờ duyệt</div>
          </div>
        </div>
      </div>
    </div>`;
  }).join('') + `</div>`;
}

function showCreateClass() { document.getElementById('create-class-form').style.display = ''; }
function hideCreateClass() { document.getElementById('create-class-form').style.display = 'none'; }

async function createClass() {
  const name = document.getElementById('cc-name').value.trim();
  const desc = document.getElementById('cc-desc').value.trim();
  if (!name) { showModal('⚠️', 'Thiếu thông tin', 'Vui lòng nhập tên lớp.', 'OK', closeModal); return; }
  const btn = document.getElementById('cc-btn');
  btn.textContent = 'Đang tạo...'; btn.disabled = true;
  try {
    // Đảm bảo profile giáo viên tồn tại
    const p = currentProfile;
    const { error: profileErr } = await sb.from('profiles').upsert({
      id: currentUser.id,
      email: currentUser.email,
      full_name: p?.full_name || currentUser.user_metadata?.full_name || currentUser.email.split('@')[0],
      role: p?.role || currentUser.user_metadata?.role || 'teacher',
      level: p?.level || null,
      quiz_score: p?.quiz_score || 0,
      words_learned: p?.words_learned || 0,
      best_wpm: p?.best_wpm || 0
    }, { onConflict: 'id' });
    if (profileErr) console.warn('Profile upsert warning:', profileErr.message);
    // Reload profile sau upsert
    await loadProfile();
    // Sinh mã không trùng
    const { code: classCode, link: classLink } = genUniqueCode();
    const { data: insertData, error } = await sb.from('classes').insert({
      teacher_id: currentUser.id, name,
      description: desc || null,
      class_code: classCode,
      class_link: classLink
    }).select();
    if (error) {
      console.error('Insert classes error:', JSON.stringify(error));
      throw new Error(error.message || error.details || error.hint || JSON.stringify(error));
    }
    document.getElementById('cc-name').value = '';
    document.getElementById('cc-desc').value = '';
    hideCreateClass();
    await loadTeacherClasses();
    showModal('✅', 'Tạo lớp thành công!', `Lớp "${name}" đã tạo.\nMã lớp: ${classCode}`, 'OK', closeModal);
  } catch(err) {
    console.error('createClass error:', err);
    const msg = err.message?.includes('duplicate') ? 'Mã lớp bị trùng, vui lòng thử lại.' :
                err.message?.includes('foreign key') ? 'Lỗi tài khoản giáo viên. Vui lòng đăng xuất và đăng nhập lại.' :
                err.message?.includes('violates row-level') ? 'Không có quyền tạo lớp. Kiểm tra vai trò tài khoản.' :
                (err.message || 'Lỗi không xác định. Vui lòng thử lại.');
    console.error('RAW error:', JSON.stringify(err));
    showModal('❌', 'Tạo lớp thất bại', msg + '\n\n[Debug: ' + (err.message || JSON.stringify(err)) + ']', 'OK', closeModal);
  } finally {
    btn.textContent = 'Tạo lớp'; btn.disabled = false;
  }
}

async function showPendingAll() {
  document.getElementById('m-em').textContent = '🔔';
  document.getElementById('m-title').textContent = 'Yêu cầu tham gia lớp';
  document.getElementById('m-body').innerHTML = '<div class="spinner"></div>';
  const mainBtn = document.getElementById('m-btn');
  if (mainBtn) mainBtn.style.display = 'none';
  document.getElementById('modal-ov').classList.add('open');
  await loadJoinRequests();
}

async function loadJoinRequests() {
  if (!currentUser) return;
  const el = document.getElementById('m-body');
  if (!el) return; // modal chưa mở thì bỏ qua, tránh lỗi khi hàm này được gọi lại từ handleRequest()
  const { data: myClasses } = await sb.from('classes').select('id').eq('teacher_id', currentUser.id);
  if (!myClasses || myClasses.length === 0) { el.innerHTML = '<div class="empty"><div class="empty-icon">✅</div><p>Không có yêu cầu</p></div>'; return; }
  const classIds = myClasses.map(c => c.id);
  const { data } = await sb.from('class_members')
    .select('*, profiles(full_name,email), classes(name)')
    .in('class_id', classIds).eq('status', 'pending')
    .order('created_at', { ascending: false });
  document.getElementById('req-count').textContent = data?.length || 0;
  if (!data || data.length === 0) { el.innerHTML = '<div class="empty"><div class="empty-icon">✅</div><p>Không có yêu cầu chờ duyệt</p></div>'; return; }
  el.innerHTML = '<div style="text-align:left;max-height:420px;overflow:auto">' + data.map(r => `
    <div class="join-req-row">
      <div>
        <div class="jr-name">${r.profiles?.full_name || r.profiles?.email}</div>
        <div class="jr-class">Muốn vào: ${r.classes?.name}</div>
      </div>
      <div class="jr-btns">
        <button class="btn-ok" onclick="handleRequest('${r.id}','approved',this)">✓ Duyệt</button>
        <button class="btn-no" onclick="handleRequest('${r.id}','rejected',this)">✕ Từ chối</button>
      </div>
    </div>`).join('') + '</div>';
}

async function handleRequest(id, status, btn) {
  const row = btn.closest('.join-req-row');
  if (row) row.style.opacity = '.4';
  btn.disabled = true;
  try {
    const { error } = await sb.from('class_members').update({ status }).eq('id', id);
    if (error) throw error;
    await loadJoinRequests();
    await loadTeacherStats();
  } catch(e) {
    console.error('handleRequest error:', e);
    showModal('❌','Lỗi','Không thể cập nhật: ' + (e.message || e),'Đóng', closeModal);
    if (row) row.style.opacity = '1';
    btn.disabled = false;
  }
}

async function loadTeacherAssignments() {
  if (!currentUser) return;
  const el = document.getElementById('tc-assignments');
  const { data: myClasses } = await sb.from('classes').select('id,name').eq('teacher_id', currentUser.id);
  if (!myClasses || myClasses.length === 0) { el.innerHTML = '<div class="empty"><div class="empty-icon">📝</div><p>Chưa có lớp nào để giao bài</p></div>'; return; }
  // Điền lớp vào select
  const sel = document.getElementById('ca-class');
  sel.innerHTML = '<option value="">-- Chọn lớp --</option>' + myClasses.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
  const { data } = await sb.from('assignments').select('*, classes(name)').eq('teacher_id', currentUser.id).order('created_at', { ascending: false });
  if (!data || data.length === 0) { el.innerHTML = '<div class="empty"><div class="empty-icon">📝</div><p>Chưa có bài tập nào</p></div>'; return; }
  const typeLabels = { vocab: '📚 Từ vựng', fill: '✏️ Điền chỗ trống', match2: '🔗 Nối từ', quiz: '🧠 Quiz', announce: '📢 Thông báo' };
  const typeClass = { vocab: 'type-vocab', fill: 'type-fill', match2: 'type-match2', quiz: 'type-quiz', announce: 'type-announce' };
  el.innerHTML = data.map(a => `
    <div class="assign-card ar-clickable"
         data-aid="${a.id}" data-cid="${a.class_id}" data-type="${a.type}"
         data-title="${(a.title||'').replace(/"/g,'&quot;')}"
         style="cursor:pointer">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;margin-bottom:4px">
        <h4 style="margin:0">${a.title}</h4>
        <span style="font-size:11px;background:#eff6ff;color:#1d4ed8;border-radius:99px;padding:3px 10px;font-weight:700;white-space:nowrap;flex-shrink:0;pointer-events:none">📊 Xem kết quả →</span>
      </div>
      <p>${a.description || ''}</p>
      <div class="assign-meta">
        <span class="assign-type ${typeClass[a.type]}">${typeLabels[a.type]}</span>
        <span style="font-size:12px;color:#aaa">Lớp: ${a.classes?.name}</span>
        ${a.due_date ? `<span style="font-size:12px;color:var(--gold)">⏰ ${new Date(a.due_date).toLocaleDateString('vi-VN')}</span>` : ''}
      </div>
    </div>`).join('');
  // Gắn event bằng JS để tránh lỗi quote trong onclick
  el.querySelectorAll('.ar-clickable').forEach(card => {
    card.addEventListener('click', function() {
      openAssignResult(this.dataset.aid, this.dataset.title, this.dataset.cid, this.dataset.type);
    });
  });
}

async function openAssignResult(assignId, title, classId, type) {
  const ov = document.createElement('div');
  ov.className = 'ar-modal-overlay';
  ov.id = 'ar-overlay';
  ov.onclick = (e) => { if (e.target === ov) closeAssignResult(); };
  const typeIcon = {vocab:'📚',fill:'✏️',match2:'🔗',quiz:'🧠',announce:'📢'};
  ov.innerHTML =
    '<div class="ar-modal">' +
      '<div class="ar-modal-hdr">' +
        '<button class="ar-modal-close" onclick="closeAssignResult()">✕</button>' +
        '<h2>' + (typeIcon[type]||'📊') + ' ' + title + '</h2>' +
        '<p id="ar-hdr-sub">Đang tải kết quả...</p>' +
      '</div>' +
      '<div class="ar-modal-body" id="ar-body"><div style="text-align:center;padding:40px;color:#bbb">⏳ Đang tải...</div></div>' +
    '</div>';
  document.body.appendChild(ov);

  try {
    // Bước 1: Lấy thông tin bài tập để có class_id chắc chắn
    const { data: assign, error: aErr } = await sb.from('assignments')
      .select('id, title, type, class_id, vocab_words, due_date')
      .eq('id', assignId)
      .single();
    if (aErr || !assign) throw new Error('Không tìm thấy bài tập: ' + (aErr?.message||''));

    // Dùng class_id từ DB thay vì tham số (tránh undefined)
    const realClassId = assign.class_id || classId;
    if (!realClassId) throw new Error('Bài tập này không có lớp học. Vui lòng kiểm tra lại.');

    // Bước 2: Fetch song song thành viên + kết quả
    const [membersRes, resultsRes] = await Promise.all([
      sb.from('class_members')
        .select('user_id')
        .eq('class_id', realClassId)
        .eq('status', 'approved'),
      sb.from('assignment_results')
        .select('user_id, score, completed_at, detail')
        .eq('assignment_id', assignId)
    ]);

    if (membersRes.error) throw membersRes.error;

    const memberIds = (membersRes.data || []).map(m => m.user_id);
    const results   = resultsRes.data || [];

    // Bước 3: Fetch profiles của từng thành viên
    let profileMap = {};
    if (memberIds.length > 0) {
      const { data: profs } = await sb.from('profiles')
        .select('id, full_name, email, avatar_url')
        .in('id', memberIds);
      (profs || []).forEach(p => {
        profileMap[p.id] = {
          ...p,
          // Tên hiển thị: ưu tiên full_name → phần trước @ email → "Học sinh"
          displayName: p.full_name || (p.email ? p.email.split('@')[0] : 'Học sinh')
        };
      });
    }

    // Ghép lại thành members array
    const members = memberIds.map(uid => ({
      user_id:  uid,
      profiles: profileMap[uid] || { full_name: 'Học sinh', email: '', displayName: 'Học sinh' }
    }));

    // Map kết quả theo user_id
    const resultMap = {};
    results.forEach(r => {
      resultMap[r.user_id] = {
        ...r,
        detail: (() => { try { return typeof r.detail === 'string' ? JSON.parse(r.detail) : r.detail; } catch(e) { return {}; } })()
      };
    });

    const doneCount    = members.filter(m => resultMap[m.user_id]).length;
    const pendingCount = members.length - doneCount;
    const totalScore   = results.reduce((s,r) => s + (r.score||0), 0);
    const avgScore     = doneCount > 0 ? Math.round(totalScore / doneCount) : 0;
    const maxScore     = results.length > 0 ? Math.max(...results.map(r => r.score||0)) : 0;

    document.getElementById('ar-hdr-sub').textContent = type === 'announce'
      ? (doneCount + '/' + members.length + ' học sinh đã đọc')
      : (doneCount + '/' + members.length + ' học sinh đã nộp · Điểm TB: ' + (doneCount > 0 ? avgScore : '—'));

    const body = document.getElementById('ar-body');
    let html = '';

    // ── Thống kê tổng quan ──
    const isAnnounce = type === 'announce';
    html += '<div class="ar-stat-row">';
    html += '<div class="ar-stat"><div class="ar-stat-num" style="color:#16a34a">' + doneCount + '</div><div class="ar-stat-lbl">' + (isAnnounce ? 'Đã đọc' : 'Đã làm') + '</div></div>';
    html += '<div class="ar-stat"><div class="ar-stat-num" style="color:#d97706">' + pendingCount + '</div><div class="ar-stat-lbl">' + (isAnnounce ? 'Chưa đọc' : 'Chưa làm') + '</div></div>';
    if (!isAnnounce) html += '<div class="ar-stat"><div class="ar-stat-num" style="color:#1d4ed8">' + (doneCount > 0 ? avgScore : '—') + '</div><div class="ar-stat-lbl">Điểm TB</div></div>';
    html += '</div>';

    // Thanh tiến độ lớp
    const pct = members.length > 0 ? Math.round(doneCount / members.length * 100) : 0;
    html += '<div style="margin-bottom:14px">';
    html += '<div style="display:flex;justify-content:space-between;font-size:11px;color:#9ca3af;margin-bottom:4px"><span>Tiến độ cả lớp</span><span>' + pct + '%</span></div>';
    html += '<div style="background:#e5e7eb;border-radius:99px;height:8px"><div style="background:#16a34a;border-radius:99px;height:8px;width:' + pct + '%;transition:width .5s"></div></div>';
    html += '</div>';

    if (members.length === 0) {
      html += '<div style="text-align:center;padding:30px;color:#bbb;font-size:13px">Lớp này chưa có học sinh nào</div>';
      body.innerHTML = html; return;
    }

    // ── Danh sách ĐÃ LÀM ──
    const doneMembers    = members.filter(m => resultMap[m.user_id]);
    const pendingMembers = members.filter(m => !resultMap[m.user_id]);

    if (doneMembers.length > 0) {
      html += '<div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:#9ca3af;margin-bottom:8px">✅ Đã hoàn thành (' + doneMembers.length + ')</div>';
      html += '<div style="background:#f0fdf4;border-radius:14px;padding:4px 14px;margin-bottom:16px">';
      // Sắp xếp theo điểm cao → thấp
      doneMembers.sort((a,b) => (resultMap[b.user_id].score||0) - (resultMap[a.user_id].score||0));
      doneMembers.forEach((m, i) => {
        const r    = resultMap[m.user_id];
        const det  = r.detail || {};
        const dt   = r.completed_at ? new Date(r.completed_at).toLocaleString('vi-VN', {day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}) : '';
        const sc   = r.score != null ? r.score : 0;
        const emojis = ['👦','👧','🧒','🧑','👨','👩'];
        const isTop = i === 0 && doneMembers.length > 1;

        // Chi tiết theo loại bài
        let detailHtml = '';
        const hasItems = Array.isArray(det.items) && det.items.length > 0;
        if (det.type === 'quiz' || type === 'quiz') {
          detailHtml = '<span style="font-size:10px;color:#6366f1;background:#eef2ff;border-radius:4px;padding:1px 6px">🧠 Quiz</span>';
        } else if (det.type === 'vocab' || type === 'vocab') {
          const words = det.words || (assign?.vocab_words?.length) || 0;
          detailHtml = '<span style="font-size:10px;color:#16a34a;background:#f0fdf4;border-radius:4px;padding:1px 6px">📚 ' + words + ' từ</span>';
        } else if (det.type === 'match' || det.type === 'match2') {
          detailHtml = '<span style="font-size:10px;color:#0369a1;background:#eff6ff;border-radius:4px;padding:1px 6px">🔗 ' + (det.done||0) + '/' + (det.total||0) + ' cặp</span>';
        } else if (det.type === 'fill' || type === 'fill') {
          detailHtml = '<span style="font-size:10px;color:#1565c0;background:#e3f2fd;border-radius:4px;padding:1px 6px">✏️ ' + (det.correct||0) + '/' + (det.total||0) + ' đúng</span>';
        } else if (det.type === 'announce' || type === 'announce') {
          detailHtml = '<span style="font-size:10px;color:#e65100;background:#fff3e0;border-radius:4px;padding:1px 6px">📢 Đã đọc</span>';
        }

        const rowId = 'ar-row-detail-' + m.user_id;
        html += '<div class="ar-student-row" style="flex-wrap:wrap">';
        html += '<div style="width:36px;height:36px;border-radius:50%;background:' + (isTop ? '#fef08a' : '#bbf7d0') + ';display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0">' + (isTop ? '🥇' : emojis[i%6]) + '</div>';
        html += '<div style="flex:1;min-width:0">';
        html += '<div style="font-size:13px;font-weight:700;color:#111;display:flex;align-items:center;gap:6px">' + (m.profiles?.displayName || m.profiles?.full_name || 'Học sinh') + (isTop ? ' <span style="font-size:10px;background:#fef08a;color:#713f12;border-radius:4px;padding:1px 5px">🏆 Cao nhất</span>' : '') + '</div>';
        html += '<div style="font-size:11px;color:#9ca3af;margin-top:2px;display:flex;gap:6px;flex-wrap:wrap">';
        if (dt) html += '<span>🕐 ' + dt + '</span>';
        if (detailHtml) html += detailHtml;
        html += '</div></div>';
        if (isAnnounce) {
          html += '<div style="text-align:right;flex-shrink:0"><div style="font-size:20px">✅</div></div>';
        } else {
          html += '<div style="text-align:right;flex-shrink:0">';
          html += '<div style="font-size:16px;font-weight:900;color:' + (sc >= 70 ? '#16a34a' : sc >= 50 ? '#d97706' : '#dc2626') + '">' + sc + '</div>';
          html += '<div style="font-size:10px;color:#9ca3af">điểm</div>';
          html += '</div>';
        }
        if (hasItems) {
          html += '<button onclick="arToggleDetail(\'' + rowId + '\', this)" style="width:100%;margin-top:6px;background:#f3f4f6;border:none;border-radius:8px;padding:5px 10px;font-size:11px;font-weight:700;color:#555;cursor:pointer;font-family:inherit">👁 Xem chi tiết đúng/sai</button>';
          html += '<div id="' + rowId + '" style="display:none;width:100%;margin-top:6px;background:#fff;border:1px solid #eee;border-radius:10px;padding:8px 10px">';
          det.items.forEach((it, ii) => {
            html += '<div style="display:flex;align-items:flex-start;gap:6px;padding:5px 0;' + (ii < det.items.length-1 ? 'border-bottom:1px solid #f3f4f6' : '') + '">';
            html += '<span style="font-size:14px;flex-shrink:0">' + (it.correct ? '✅' : '❌') + '</span>';
            html += '<div style="flex:1;min-width:0">';
            html += '<div style="font-size:12px;font-weight:700;color:#333">' + (ii+1) + '. ' + escHtml(it.label||'') + '</div>';
            if (!it.correct) {
              html += '<div style="font-size:11px;color:#e53935">Học sinh chọn: <b>' + escHtml(it.given||'—') + '</b> · Đáp án đúng: <b>' + escHtml(it.answer||'—') + '</b></div>';
            }
            html += '</div></div>';
          });
          html += '</div>';
        }
        html += '</div>';
      });
      html += '</div>';
    }

    // ── Danh sách CHƯA LÀM / CHƯA ĐỌC ──
    if (pendingMembers.length > 0) {
      html += '<div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:#9ca3af;margin-bottom:8px">⏳ ' + (isAnnounce ? 'Chưa đọc' : 'Chưa nộp bài') + ' (' + pendingMembers.length + ')</div>';
      html += '<div style="background:#fffbeb;border-radius:14px;padding:4px 14px">';
      pendingMembers.forEach((m, i) => {
        const emojis = ['👦','👧','🧒','🧑','👨','👩'];
        html += '<div class="ar-student-row">';
        html += '<div style="width:36px;height:36px;border-radius:50%;background:#fde68a;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0">' + emojis[i%6] + '</div>';
        html += '<div style="flex:1"><div style="font-size:13px;font-weight:700;color:#333">' + (m.profiles?.displayName || m.profiles?.full_name || 'Học sinh') + '</div>';
        html += '<div style="font-size:11px;color:#9ca3af">' + (isAnnounce ? 'Chưa đọc thông báo' : 'Chưa làm bài') + '</div></div>';
        html += '<span class="ar-badge-pending">⏳ ' + (isAnnounce ? 'Chưa đọc' : 'Chờ nộp') + '</span>';
        html += '</div>';
      });
      html += '</div>';
    }

    body.innerHTML = html;

  } catch(err) {
    const body = document.getElementById('ar-body');
    if (body) body.innerHTML =
      '<div style="text-align:center;padding:30px;color:#dc2626;font-size:13px">' +
      '❌ Lỗi: ' + (err.message||err) +
      '<br><br><small style="color:#666">Kiểm tra bảng <code>assignment_results</code> đã được tạo chưa và RLS policy có đúng không.</small></div>';
  }
}

function arToggleDetail(rowId, btn) {
  const panel = document.getElementById(rowId);
  if (!panel) return;
  const open = panel.style.display !== 'none';
  panel.style.display = open ? 'none' : 'block';
  if (btn) btn.textContent = open ? '👁 Xem chi tiết đúng/sai' : '🙈 Ẩn chi tiết';
}

function closeAssignResult() {
  const el = document.getElementById('ar-overlay');
  if (el) el.remove();
}

function showCreateAssign() { document.getElementById('create-assign-form').style.display = ''; }
function hideCreateAssign() { document.getElementById('create-assign-form').style.display = 'none'; }

async function createAssignment() {
  const classId = document.getElementById('ca-class').value;
  const title = document.getElementById('ca-title').value.trim();
  const type = document.getElementById('ca-type').value;
  const desc = document.getElementById('ca-desc').value.trim();
  const due = document.getElementById('ca-due').value;
  if (!classId || !title) { showModal('⚠️', 'Thiếu thông tin', 'Vui lòng chọn lớp và nhập tiêu đề.', 'OK', closeModal); return; }
  document.getElementById('ca-btn').textContent = 'Đang tạo...';
  const { error } = await sb.from('assignments').insert({
    teacher_id: currentUser.id, class_id: classId, title, type,
    description: desc, due_date: due || null
  });
  document.getElementById('ca-btn').textContent = 'Tạo bài tập';
  if (error) { showModal('❌', 'Lỗi', viErr(error.message), 'OK', closeModal); return; }
  document.getElementById('ca-title').value = '';
  document.getElementById('ca-desc').value = '';
  document.getElementById('ca-due').value = '';
  hideCreateAssign();
  await loadTeacherAssignments();
  showModal('✅', 'Tạo bài tập thành công!', `Bài tập "${title}" đã được giao cho học sinh.`, 'OK', closeModal);
}

// ─── CLASS DETAIL ─────────────────────────────────────────────────────
let currentClassId = null, currentClassCode = null, currentClassLink = null;

function cdTab(name, el) {
  document.querySelectorAll('#cd-tabs .tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  ['students','requests','assignments'].forEach(n =>
    document.getElementById('cd-tab-' + n).style.display = n === name ? '' : 'none'
  );
}

async function openClassDetail(id, name, desc, code, link) {
  currentClassId = id;
  currentClassCode = code;
  currentClassLink = link;
  document.getElementById('cd-name').textContent = name;
  document.getElementById('cd-desc').textContent = desc || '';
  document.getElementById('cd-code').textContent = code;
  document.getElementById('cd-link').textContent = window.location.origin + '?join=' + link;
  // Reset tab về học sinh
  cdTab('students', document.querySelector('#cd-tabs .tab'));
  showPage('class-detail');
  // Load song song
  await Promise.all([loadClassStudents(), loadClassRequests(), loadClassAssignments()]);
}

function showEditClass() {
  document.getElementById('edit-class-name').value = document.getElementById('cd-name').textContent;
  document.getElementById('edit-class-desc').value = document.getElementById('cd-desc').textContent;
  document.getElementById('edit-class-modal').classList.add('open');
}

function closeEditClass() {
  document.getElementById('edit-class-modal').classList.remove('open');
}

async function saveEditClass() {
  const name = document.getElementById('edit-class-name').value.trim();
  const desc = document.getElementById('edit-class-desc').value.trim();
  if (!name) { showModal('⚠️','Thiếu thông tin','Vui lòng nhập tên lớp.','OK',closeModal); return; }
  const btn = document.getElementById('edit-class-btn');
  btn.textContent = 'Đang lưu...'; btn.disabled = true;
  const { error } = await sb.from('classes')
    .update({ name, description: desc || null })
    .eq('id', currentClassId);
  btn.textContent = '💾 Lưu thay đổi'; btn.disabled = false;
  if (error) { showModal('❌','Lỗi',error.message,'OK',closeModal); return; }
  // Cập nhật UI ngay
  document.getElementById('cd-name').textContent = name;
  document.getElementById('cd-desc').textContent = desc;
  closeEditClass();
  // Reload danh sách lớp ở dashboard
  await loadTeacherClasses();
  showModal('✅','Đã cập nhật!',`Lớp "${name}" đã được chỉnh sửa thành công.`,'OK',closeModal);
}

function copyClassCode() {
  navigator.clipboard.writeText(currentClassCode);
  showModal('✅', 'Đã copy!', 'Mã lớp: ' + currentClassCode, 'OK', closeModal);
}
function copyClassLink() {
  const link = window.location.origin + '?join=' + currentClassLink;
  navigator.clipboard.writeText(link);
  showModal('✅', 'Đã copy link!', 'Link đã được copy vào clipboard.', 'OK', closeModal);
}

async function loadClassStudents() {
  const el = document.getElementById('cd-students');
  el.innerHTML = '<div class="spinner"></div>';
  const { data: members } = await sb.from('class_members')
    .select('id, user_id, created_at')
    .eq('class_id', currentClassId)
    .eq('status', 'approved')
    .order('created_at', { ascending: false });

  const count = members?.length || 0;
  document.getElementById('cd-student-count').textContent = count;

  if (!members || count === 0) {
    el.innerHTML = '<div class="empty"><div class="empty-icon">👥</div><p>Chưa có học sinh nào tham gia.<br>Chia sẻ mã lớp hoặc link để mời học sinh!</p></div>';
    return;
  }

  // Lấy profiles riêng
  const userIds = members.map(m => m.user_id);
  const { data: profiles } = await sb.from('profiles').select('id, full_name, email, level, quiz_score').in('id', userIds);
  const pm = {};
  (profiles || []).forEach(p => pm[p.id] = p);

  el.innerHTML = members.map(m => {
    const p = pm[m.user_id] || {};
    const name = p.full_name || p.email?.split('@')[0] || 'Học sinh';
    const initial = name[0].toUpperCase();
    const colors = ['#2d6a4f','#5b21b6','#b45309','#1d4ed8','#b91c1c'];
    const color = colors[name.charCodeAt(0) % colors.length];
    return `
    <div style="display:flex;align-items:center;justify-content:space-between;
                padding:12px 16px;background:#ffffff;border:1px solid #ffd966;
                border-radius:10px;margin-bottom:8px">
      <div style="display:flex;align-items:center;gap:12px">
        <div style="width:38px;height:38px;border-radius:50%;background:${color}20;
                    display:flex;align-items:center;justify-content:center;
                    font-weight:700;font-size:14px;color:${color};flex-shrink:0">${initial}</div>
        <div>
          <div style="font-size:14px;font-weight:600">${name}</div>
          <div style="font-size:12px;color:#aaa">${p.email || ''}</div>
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:16px">
        <div style="text-align:center">
          <div style="font-size:13px;font-weight:700;color:var(--acc)">${p.quiz_score || 0}</div>
          <div style="font-size:10px;color:#aaa">điểm</div>
        </div>
        <span style="background:#fff3c4;color:#666;font-size:11px;font-weight:600;
                     padding:3px 8px;border-radius:6px">${p.level || 'B1'}</span>
        <button class="ev-kick" data-mid="${m.id}" data-name="${name.replace(/"/g,'&quot;')}"
          style="background:none;border:none;color:#aaa;cursor:pointer;font-size:16px;
                 padding:4px;border-radius:4px" title="Xóa khỏi lớp">✕</button>
      </div>
    </div>`;
  }).join('');
}

async function kickStudent(memberId, name) {
  if (!confirm('Xóa "' + name + '" khỏi lớp?')) return;
  await sb.from('class_members').delete().eq('id', memberId);
  await Promise.all([loadClassStudents(), loadTeacherStats()]);
}

async function loadClassRequests() {
  const el = document.getElementById('cd-requests');
  el.innerHTML = '<div class="spinner"></div>';
  const { data: members } = await sb.from('class_members')
    .select('id, user_id, created_at')
    .eq('class_id', currentClassId)
    .eq('status', 'pending')
    .order('created_at', { ascending: false });

  const count = members?.length || 0;
  document.getElementById('cd-req-count').textContent = count;
  const badge = document.getElementById('cd-req-badge');
  if (badge) { badge.textContent = count; badge.style.display = count > 0 ? 'inline' : 'none'; }

  if (!members || count === 0) {
    el.innerHTML = '<div class="empty" style="padding:24px"><div class="empty-icon">✅</div><p>Không có yêu cầu chờ duyệt</p></div>';
    await loadTeacherStats();
    return;
  }

  const userIds = members.map(m => m.user_id);
  const { data: profiles } = await sb.from('profiles').select('id, full_name, email, level').in('id', userIds);
  const pm = {};
  (profiles || []).forEach(p => pm[p.id] = p);

  el.innerHTML = `
  <div style="background:#fffde7;border:1px solid #fcd34d;border-radius:10px;padding:12px 16px;margin-bottom:16px;font-size:13px;color:var(--gold)">
    🔔 Có ${count} học sinh đang chờ bạn duyệt để vào lớp
  </div>` +
  members.map(r => {
    const p = pm[r.user_id] || {};
    const name = p.full_name || p.email?.split('@')[0] || 'Học sinh';
    const initial = name[0].toUpperCase();
    const joined = new Date(r.created_at).toLocaleDateString('vi-VN');
    return `
    <div style="display:flex;align-items:center;justify-content:space-between;
                padding:14px 16px;background:#ffffff;border:1.5px solid #fcd34d;
                border-radius:10px;margin-bottom:8px">
      <div style="display:flex;align-items:center;gap:12px">
        <div style="width:38px;height:38px;border-radius:50%;background:#fffde7;
                    display:flex;align-items:center;justify-content:center;
                    font-weight:700;font-size:14px;color:var(--gold);flex-shrink:0">${initial}</div>
        <div>
          <div style="font-size:14px;font-weight:600">${name}</div>
          <div style="font-size:12px;color:#aaa">${p.email || ''} ${p.level ? '· ' + p.level : ''}</div>
          <div style="font-size:11px;color:#aaa;margin-top:2px">Gửi yêu cầu: ${joined}</div>
        </div>
      </div>
      <div style="display:flex;gap:8px;flex-shrink:0">
        <button class="btn-ok" style="padding:8px 16px;font-size:13px"
          onclick="handleClassRequest('${r.id}','approved',this)">✓ Duyệt</button>
        <button class="btn-no" style="padding:8px 14px;font-size:13px"
          onclick="handleClassRequest('${r.id}','rejected',this)">✕ Từ chối</button>
      </div>
    </div>`;
  }).join('');
}

async function handleClassRequest(id, status, btn) {
  const row = btn.closest('div[style*="border-radius:10px"]');
  if (row) row.style.opacity = '.4';
  btn.disabled = true;
  try {
    const { error } = await sb.from('class_members').update({ status }).eq('id', id);
    if (error) throw error;
    await Promise.all([loadClassStudents(), loadClassRequests(), loadTeacherStats()]);
  } catch(e) {
    console.error('handleClassRequest error:', e);
    showModal('❌','Lỗi duyệt học sinh',
      'Lỗi: ' + (e.message || e) + '<br><br>Hãy kiểm tra lại RLS policy bảng class_members trong Supabase.',
      'Đóng', closeModal);
    if (row) row.style.opacity = '1';
    btn.disabled = false;
  }
}

async function loadClassAssignments() {
  const el = document.getElementById('cd-assignments');
  el.innerHTML = '<div class="spinner"></div>';
  const { data } = await sb.from('assignments')
    .select('*').eq('class_id', currentClassId)
    .order('created_at', { ascending: false });
  if (!data || data.length === 0) {
    el.innerHTML = '<div class="empty"><div class="empty-icon">📝</div><p>Chưa có bài tập nào.<br>Bấm "+ Giao bài tập" để tạo!</p></div>';
    return;
  }
  const typeLabels = { vocab: '📚 Từ vựng', fill: '✏️ Điền chỗ trống', match2: '🔗 Nối từ', quiz: '🧠 Quiz', announce: '📢 Thông báo' };
  const typeClass  = { vocab: 'type-vocab', fill: 'type-fill', match2: 'type-match2', quiz: 'type-quiz', announce: 'type-announce' };
  el.innerHTML = data.map(a => {
    const imgs = a.images || [];
    const vocab = a.vocab_words || [];
    const quizQs = a.type === 'quiz' ? (a.fill_data || []) : [];
    const desc = renderDesc(a.description || '');
    const borderColor = a.type === 'vocab' ? 'var(--green)' : a.type === 'fill' ? '#1565c0' : a.type === 'match2' ? '#c2185b' : a.type === 'quiz' ? '#6366f1' : a.type === 'announce' ? '#e65100' : 'var(--acc)';
    return `
    <div class="assign-card ar-cd-card" data-aid="${a.id}" data-cid="${currentClassId}" data-type="${a.type}"
         data-title="${(a.title||'').replace(/"/g,'&quot;')}"
         style="border:1px solid #ffd966;border-left:4px solid ${borderColor};margin-bottom:12px">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;margin-bottom:10px">
        <div style="flex:1">
          <h4 style="font-size:15px;margin-bottom:4px">${a.title}</h4>
          <div class="assign-meta">
            <span class="assign-type ${typeClass[a.type]}">${typeLabels[a.type]}</span>
            ${vocab.length ? `<span class="pill pill-pur">${vocab.length} từ</span>` : ''}
            ${quizQs.length ? `<span class="pill pill-pur">${quizQs.length} câu hỏi</span>` : ''}
            ${a.due_date ? `<span style="font-size:12px;color:var(--gold)">⏰ ${new Date(a.due_date).toLocaleDateString('vi-VN')}</span>` : ''}
          </div>
        </div>
        <div style="display:flex;gap:6px;align-items:center;flex-shrink:0">
          <button class="ar-result-btn" style="background:#eff6ff;border:none;border-radius:8px;padding:5px 10px;font-size:12px;font-weight:700;color:#1d4ed8;cursor:pointer;font-family:inherit">📊 Kết quả</button>
          <button onclick="deleteAssignment('${a.id}')" style="background:none;border:none;cursor:pointer;color:#aaa;font-size:15px">✕</button>
        </div>
      </div>

      ${desc ? `<div style="font-size:13px;color:#666;line-height:1.7;margin-bottom:10px;padding:10px;background:#fff3c4;border-radius:6px">${desc}</div>` : ''}

      ${vocab.length ? `
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;margin-bottom:8px">
          ${vocab.map(v => `
            <div style="background:#fff3c4;border-radius:8px;padding:10px;border:1px solid #ffd966">
              ${v.image_url ? `<img src="${v.image_url}" style="width:100%;height:70px;object-fit:cover;border-radius:6px;margin-bottom:6px;cursor:pointer" onclick="window.open('${v.image_url}','_blank')">` : ''}
              <div style="font-weight:700;font-size:14px;color:#1a1814">${v.word}</div>
              ${v.phonetic ? `<div style="font-size:11px;color:#aaa;font-family:monospace">${v.phonetic}</div>` : ''}
              <div style="font-size:13px;color:var(--acc);margin-top:3px">${v.meaning}</div>
              ${v.example ? `<div style="font-size:11px;color:#aaa;margin-top:4px;font-style:italic">"${v.example}"</div>` : ''}
            </div>`).join('')}
        </div>` : ''}

      ${imgs.length ? `
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(80px,1fr));gap:6px">
          ${imgs.map(url => `
            <div style="aspect-ratio:1;border-radius:8px;overflow:hidden;border:1px solid #ffd966;cursor:pointer" onclick="window.open('${url}','_blank')">
              <img src="${url}" style="width:100%;height:100%;object-fit:cover">
            </div>`).join('')}
        </div>` : ''}
    </div>`;
  }).join('');

  // Gắn event cho nút Kết quả trong chi tiết lớp
  el.querySelectorAll('.ar-result-btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      const card = this.closest('.ar-cd-card');
      openAssignResult(card.dataset.aid, card.dataset.title, card.dataset.cid, card.dataset.type);
    });
  });
}

// ─── VOCAB BUILDER ──────────────────────────────────────────────────
let vocabCards = []; // [{word,phonetic,meaning,image_url,image_path}]
let currentVocabImgIdx = null;

const CD_TYPE_LABELS = { vocab:'📚 Từ vựng', fill:'✏️ Điền vào chỗ trống', match2:'🔗 Nối từ', quiz:'🧠 Quiz', announce:'📢 Thông báo' };

function toggleTypeDropdown(e) {
  if (e) e.stopPropagation();
  const dd = document.getElementById('cd-type-dropdown');
  if (!dd) return;
  dd.style.display = dd.style.display === 'none' ? 'block' : 'none';
}

function selectAssignType(value) {
  const input = document.getElementById('cd-type');
  const label = document.getElementById('cd-type-label');
  const dd = document.getElementById('cd-type-dropdown');
  if (input) input.value = value;
  if (label) label.textContent = CD_TYPE_LABELS[value] || value;
  if (dd) dd.style.display = 'none';
  onAssignTypeChange(value);
}

// Đóng dropdown khi bấm ra ngoài
document.addEventListener('click', function(e) {
  const btn = document.getElementById('cd-type-btn');
  const dd = document.getElementById('cd-type-dropdown');
  if (dd && dd.style.display === 'block' && btn && !btn.contains(e.target) && !dd.contains(e.target)) {
    dd.style.display = 'none';
  }
});

function onAssignTypeChange(type) {
  document.getElementById('section-general').style.display = type === 'announce' ? '' : 'none';
  document.getElementById('section-vocab').style.display   = type === 'vocab'  ? '' : 'none';
  document.getElementById('section-fill').style.display    = type === 'fill'   ? '' : 'none';
  document.getElementById('section-match2').style.display  = type === 'match2' ? '' : 'none';
  document.getElementById('section-quiz').style.display    = type === 'quiz'   ? '' : 'none';
  const dueFg = document.getElementById('cd-due-fg');
  if (dueFg) dueFg.style.display = type === 'announce' ? 'none' : '';
  const abtn = document.getElementById('cd-abtn');
  if (abtn) abtn.textContent = type === 'announce' ? '📢 Gửi thông báo cho cả lớp' : '✓ Giao bài cho học sinh';
  if (type === 'vocab'  && vocabCards.length === 0) addVocabCard();
  if (type === 'fill'   && document.getElementById('fill-list').children.length   === 0) addFillRow();
  if (type === 'match2' && document.getElementById('match2-list').children.length === 0) { addMatch2Row(); addMatch2Row(); }
  if (type === 'quiz'   && document.getElementById('quiz-list').children.length   === 0) addQuizRow();
}

function addVocabCard() {
  vocabCards.push({ word:'', phonetic:'', meaning:'', image_url:'', image_path:'' });
  renderVocabCards();
  // Scroll xuống cuối
  setTimeout(() => {
    const list = document.getElementById('vocab-list-builder');
    list.lastElementChild?.scrollIntoView({ behavior:'smooth', block:'nearest' });
  }, 50);
}

function removeVocabCard(idx) {
  vocabCards.splice(idx, 1);
  renderVocabCards();
}

function renderVocabCards() {
  const el = document.getElementById('vocab-list-builder');
  document.getElementById('vocab-count-badge').textContent = vocabCards.length + ' từ';
  if (vocabCards.length === 0) { el.innerHTML = ''; return; }
  el.innerHTML = vocabCards.map((v, i) => `
    <div class="vocab-card">
      <div class="vocab-card-hdr">
        <span class="vocab-card-num">Từ ${i+1}</span>
        <button class="vocab-card-del" onclick="removeVocabCard(${i})">✕</button>
      </div>
      <div class="vocab-fields">
        <div class="fg">
          <label>Từ tiếng Anh *</label>
          <input type="text" value="${v.word}" placeholder="vd: Beautiful"
            oninput="vocabCards[${i}].word=this.value">
        </div>
        <div class="fg">
          <label>Phát âm (IPA)</label>
          <input type="text" value="${v.phonetic}" placeholder="vd: /ˈbjuːtɪfl/"
            oninput="vocabCards[${i}].phonetic=this.value"
            style="font-family:monospace">
        </div>
        <div class="fg">
          <label>Nghĩa tiếng Việt *</label>
          <input type="text" value="${v.meaning}" placeholder="vd: Xinh đẹp"
            oninput="vocabCards[${i}].meaning=this.value">
        </div>
        <div class="fg">
          <label>Hình ảnh minh họa</label>
          ${v.image_url
            ? `<div style="position:relative">
                <img src="${v.image_url}" class="vocab-img-preview" onclick="openVocabImg(${i})"
                     onerror="this.style.display='none';this.nextElementSibling.nextElementSibling.style.display='block'">
                <button onclick="removeVocabImg(${i})"
                  style="position:absolute;top:6px;right:6px;background:rgba(0,0,0,.6);color:#fff;
                         border:none;border-radius:50%;width:22px;height:22px;cursor:pointer;font-size:12px">✕</button>
                <div style="display:none;background:#ffebee;border:1.5px dashed #ef9a9a;border-radius:12px;padding:12px;font-size:11px;color:#c62828;text-align:center;margin-top:6px">
                  ⚠️ Không tải được ảnh. Kiểm tra bucket Storage <b>"assignments"</b> trong Supabase đã bật <b>Public</b> chưa.
                </div>
               </div>`
            : `<button class="vocab-img-btn" onclick="openVocabImg(${i})">
                 🖼️ Chọn ảnh minh họa
               </button>`
          }
        </div>
      </div>
      <div class="fg" style="margin-top:8px;margin-bottom:0">
        <label>Ví dụ (tùy chọn)</label>
        <input type="text" value="${v.example||''}" placeholder="vd: She is a beautiful girl."
          oninput="vocabCards[${i}].example=this.value">
      </div>
    </div>`).join('');
}

function openVocabImg(idx) {
  currentVocabImgIdx = idx;
  document.getElementById('vocab-img-input').click();
}

async function handleVocabImg(e) {
  const file = e.target.files[0];
  if (!file || currentVocabImgIdx === null) return;
  e.target.value = '';
  if (file.size > 5 * 1024 * 1024) { showModal('⚠️','File quá lớn','Ảnh phải nhỏ hơn 5MB.','OK',closeModal); return; }
  const ext = file.name.split('.').pop();
  const path = `vocab/${currentUser.id}/${Date.now()}.${ext}`;
  const spinner = document.getElementById('upload-spinner');
  if (spinner) spinner.style.display = 'block';
  const { error } = await sb.storage.from('assignments').upload(path, file, { upsert:true });
  if (spinner) spinner.style.display = 'none';
  if (error) { showModal('❌','Lỗi upload',error.message,'OK',closeModal); return; }
  const { data } = sb.storage.from('assignments').getPublicUrl(path);
  vocabCards[currentVocabImgIdx].image_url  = data.publicUrl;
  vocabCards[currentVocabImgIdx].image_path = path;
  currentVocabImgIdx = null;
  renderVocabCards();
}

async function removeVocabImg(idx) {
  const path = vocabCards[idx].image_path;
  if (path) await sb.storage.from('assignments').remove([path]);
  vocabCards[idx].image_url  = '';
  vocabCards[idx].image_path = '';
  renderVocabCards();
}

// ─── IMAGE UPLOAD ──────────────────────────────────────────────────
let uploadedImages = []; // [{url, path}]

function triggerImgUpload() { document.getElementById('img-file-input').click(); }

async function handleImgSelect(e) { await uploadImages(Array.from(e.target.files)); e.target.value=''; }
async function handleImgDrop(e) {
  e.preventDefault();
  document.getElementById('img-drop-zone').classList.remove('drag');
  await uploadImages(Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/')));
}

async function uploadImages(files) {
  if (!files.length) return;
  const spinner = document.getElementById('upload-spinner');
  spinner.style.display = 'block';
  for (const file of files) {
    if (file.size > 5 * 1024 * 1024) { showModal('⚠️','File quá lớn',`${file.name} vượt quá 5MB.`,'OK',closeModal); continue; }
    const ext = file.name.split('.').pop();
    const path = `${currentUser.id}/${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`;
    const { data, error } = await sb.storage.from('assignments').upload(path, file, { upsert: true });
    if (error) { showModal('❌','Lỗi upload',error.message,'OK',closeModal); continue; }
    const { data: urlData } = sb.storage.from('assignments').getPublicUrl(path);
    uploadedImages.push({ url: urlData.publicUrl, path });
    renderImgPreviews();
  }
  spinner.style.display = 'none';
}

function renderImgPreviews() {
  const grid = document.getElementById('img-preview-grid');
  grid.innerHTML = uploadedImages.map((img, i) => `
    <div class="img-preview-item">
      <img src="${img.url}" alt="Ảnh ${i+1}">
      <button class="img-preview-del" onclick="removeImg(${i})">✕</button>
    </div>`).join('');
}

async function removeImg(idx) {
  const img = uploadedImages[idx];
  await sb.storage.from('assignments').remove([img.path]);
  uploadedImages.splice(idx, 1);
  renderImgPreviews();
}

function insertText(before, after, placeholder) {
  const ta = document.getElementById('cd-adesc');
  const start = ta.selectionStart, end = ta.selectionEnd;
  const selected = ta.value.substring(start, end) || placeholder;
  const newText = before + selected + after;
  ta.value = ta.value.substring(0, start) + newText + ta.value.substring(end);
  ta.focus();
  ta.selectionStart = start + before.length;
  ta.selectionEnd = start + before.length + selected.length;
}

// ─── FILL-IN-BLANK BUILDER (giáo viên) ──────────────────────────
let fillRows = [];
function addFillRow() {
  const id = Date.now();
  fillRows.push(id);
  const list = document.getElementById('fill-list');
  const div = document.createElement('div');
  div.className = 'fill-row';
  div.id = 'fillrow-' + id;
  div.style.cssText = 'background:#f0f7ff;border:1.5px solid #90caf9;border-radius:12px;padding:12px 14px;margin-bottom:10px';
  div.innerHTML =
    '<div style="display:flex;gap:8px;align-items:flex-end">' +
      '<div style="flex:1">' +
        '<label style="font-size:11px;font-weight:700;color:#1565c0;display:block;margin-bottom:4px">TỪ ĐẦY ĐỦ</label>' +
        '<input type="text" id="fill-word-'+id+'" placeholder="VD: CAT, APPLE..." maxlength="20"' +
          ' oninput="renderFillPreview('+id+')"' +
          ' style="width:100%;padding:8px 12px;border:1.5px solid #90caf9;border-radius:8px;font-size:18px;font-weight:900;letter-spacing:6px;font-family:monospace;text-transform:uppercase">' +
      '</div>' +
      '<div>' +
        '<label style="font-size:11px;font-weight:700;color:#1565c0;display:block;margin-bottom:4px">CHỮ CẦN ĐIỀN</label>' +
        '<input type="text" id="fill-ans-'+id+'" placeholder="VD: A" maxlength="1"' +
          ' oninput="renderFillPreview('+id+')"' +
          ' style="width:58px;padding:8px 10px;border:1.5px solid #90caf9;border-radius:8px;font-size:18px;font-weight:900;font-family:monospace;text-align:center;text-transform:uppercase">' +
      '</div>' +
      '<button onclick="deleteFillRow('+id+')" style="background:#fce4ec;color:#c2185b;border:none;border-radius:8px;padding:9px 11px;cursor:pointer;font-size:14px;flex-shrink:0;margin-bottom:1px">✕</button>' +
    '</div>' +
    '<div id="fill-prev-'+id+'" style="margin-top:8px;min-height:22px"></div>';
  list.appendChild(div);
  updateFillCount();
}

function renderFillPreview(id) {
  const wordEl = document.getElementById('fill-word-' + id);
  const ansEl  = document.getElementById('fill-ans-'  + id);
  const prevEl = document.getElementById('fill-prev-' + id);
  if (!wordEl || !ansEl || !prevEl) return;
  const word = wordEl.value.toUpperCase().replace(/[^A-Z]/g,'');
  const ans  = ansEl.value.toUpperCase().replace(/[^A-Z]/g,'');
  wordEl.value = word;
  ansEl.value  = ans;
  if (!word || !ans) { prevEl.innerHTML = ''; return; }
  if (!word.includes(ans)) {
    prevEl.innerHTML = '<span style="color:#e53935;font-size:12px">⚠️ Chữ <b>' + ans + '</b> không có trong từ <b>' + word + '</b></span>';
    return;
  }
  // Ẩn lần xuất hiện đầu tiên của chữ cần điền
  const idx    = word.indexOf(ans);
  const hidden = word.slice(0, idx) + '_' + word.slice(idx + 1);
  prevEl.innerHTML =
    '<span style="font-size:12px;color:#555">Học sinh thấy: </span>' +
    '<strong style="font-size:18px;letter-spacing:6px;font-family:monospace;color:#1565c0">' + hidden + '</strong>' +
    '&nbsp;&nbsp;<span style="font-size:12px;color:#43a047;font-weight:700">→ điền: <b>' + ans + '</b></span>';
}

function updateFillCount() {
  const n   = document.getElementById('fill-list').querySelectorAll('.fill-row').length;
  const lbl = document.getElementById('fill-count');
  if (lbl) lbl.textContent = n + ' từ';
}

function deleteFillRow(id) {
  const el = document.getElementById('fillrow-' + id);
  if (el) el.remove();
  fillRows = fillRows.filter(r => r !== id);
}

function getFillData() {
  return Array.from(document.getElementById('fill-list').querySelectorAll('.fill-row')).map(row => {
    const wordInp = row.querySelector('input[id^="fill-word-"]');
    const ansInp  = row.querySelector('input[id^="fill-ans-"]');
    if (!wordInp || !ansInp) return null;
    const word   = wordInp.value.toUpperCase().replace(/[^A-Z]/g,'');
    const answer = ansInp.value.toUpperCase().replace(/[^A-Z]/g,'');
    if (!word || !answer || !word.includes(answer)) return null;
    const idx     = word.indexOf(answer);
    const display = word.slice(0, idx) + '_' + word.slice(idx + 1);
    return { word, answer, display };
  }).filter(Boolean);
}

// ─── MATCH2 BUILDER (giáo viên) ──────────────────────────────────
let match2Rows = [];
function addMatch2Row() {
  if (match2Rows.length >= 10) return;
  const id = Date.now();
  match2Rows.push(id);
  const list = document.getElementById('match2-list');
  const div = document.createElement('div');
  div.className = 'match2-row';
  div.id = 'match2row-' + id;
  div.innerHTML =
    '<input type="text" placeholder="Từ tiếng Anh (VD: Dog)" id="m2w-'+id+'">' +
    '<input type="text" placeholder="Nghĩa (VD: Con chó)" id="m2m-'+id+'">' +
    '<button onclick="deleteMatch2Row('+id+')" style="background:#fce4ec;color:#c2185b;border:none;border-radius:8px;padding:6px 8px;cursor:pointer;font-size:13px">✕</button>';
  list.appendChild(div);
  updateMatch2Count();
}

function deleteMatch2Row(id) {
  const el = document.getElementById('match2row-' + id);
  if (el) el.remove();
  match2Rows = match2Rows.filter(r => r !== id);
  updateMatch2Count();
}

function updateMatch2Count() {
  const cnt = document.getElementById('match2-list');
  const btn = document.getElementById('match2-add-btn');
  const lbl = document.getElementById('match2-count');
  if (!cnt) return;
  const n = cnt.querySelectorAll('.match2-row').length;
  if (lbl) lbl.textContent = n + '/10 cặp';
  if (btn) btn.style.display = n >= 10 ? 'none' : '';
}

function getMatch2Data() {
  return Array.from(document.getElementById('match2-list').querySelectorAll('.match2-row')).map(row => {
    const inputs = row.querySelectorAll('input');
    return { word: inputs[0].value.trim(), meaning: inputs[1].value.trim() };
  }).filter(r => r.word || r.meaning);
}

// ─── QUIZ BUILDER (giáo viên) ────────────────────────────────────
let quizRows = [];
function addQuizRow() {
  const id = Date.now();
  quizRows.push(id);
  const list = document.getElementById('quiz-list');
  const div = document.createElement('div');
  div.className = 'quiz-row';
  div.id = 'quizrow-' + id;
  div.style.cssText = 'background:#f5f6ff;border:1.5px solid #c7d2fe;border-radius:12px;padding:12px 14px;margin-bottom:10px';
  div.innerHTML =
    '<div style="display:flex;gap:8px;align-items:flex-start;margin-bottom:10px">' +
      '<input type="text" id="quiz-q-'+id+'" placeholder="Nhập câu hỏi..." ' +
        'style="flex:1;padding:8px 12px;border:1.5px solid #c7d2fe;border-radius:8px;font-size:14px;font-family:inherit">' +
      '<button onclick="deleteQuizRow('+id+')" style="background:#fce4ec;color:#c2185b;border:none;border-radius:8px;padding:8px 11px;cursor:pointer;font-size:14px;flex-shrink:0">✕</button>' +
    '</div>' +
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">' +
      [0,1,2,3].map(i => (
        '<label style="display:flex;align-items:center;gap:6px;background:#fff;border:1.5px solid #e0e0e0;border-radius:8px;padding:6px 10px">' +
          '<input type="radio" name="quiz-correct-'+id+'" value="'+i+'"'+(i===0?' checked':'')+' style="flex-shrink:0">' +
          '<input type="text" id="quiz-opt-'+id+'-'+i+'" placeholder="Đáp án '+(i+1)+'" ' +
            'style="flex:1;border:none;outline:none;font-size:13px;font-family:inherit">' +
        '</label>'
      )).join('') +
    '</div>';
  list.appendChild(div);
  updateQuizCount();
}

function deleteQuizRow(id) {
  const el = document.getElementById('quizrow-' + id);
  if (el) el.remove();
  quizRows = quizRows.filter(r => r !== id);
  updateQuizCount();
}

function updateQuizCount() {
  const n = document.getElementById('quiz-list').querySelectorAll('.quiz-row').length;
  const lbl = document.getElementById('quiz-count');
  if (lbl) lbl.textContent = n + ' câu hỏi';
}

function getQuizData() {
  return Array.from(document.getElementById('quiz-list').querySelectorAll('.quiz-row')).map(row => {
    const qInp = row.querySelector('input[id^="quiz-q-"]');
    const question = qInp ? qInp.value.trim() : '';
    const optInputs = Array.from(row.querySelectorAll('input[id^="quiz-opt-"]'));
    const options = optInputs.map(i => i.value.trim());
    const checked = row.querySelector('input[type="radio"]:checked');
    const correct = checked ? parseInt(checked.value, 10) : 0;
    if (!question || options.some(o => !o)) return null;
    return { question, options, correct };
  }).filter(Boolean);
}

// ─── HIỂN THỊ BÀI TẬP CHO HỌC SINH ─────────────────────────────

// Fill-in-blank student view (điền 1 ký tự)
function showCreateAssignInClass() {
  cdTab('assignments', document.querySelectorAll('#cd-tabs .tab')[2]);
  document.getElementById('cd-assign-form').style.display = '';
  document.getElementById('cd-title').focus();
}
function hideCreateAssignInClass() {
  document.getElementById('cd-assign-form').style.display = 'none';
  uploadedImages = []; vocabCards = [];
  document.getElementById("fill-list").innerHTML = "";
  document.getElementById("match2-list").innerHTML = "";
  updateMatch2Count();
  document.getElementById("quiz-list").innerHTML = "";
  quizRows = [];
  updateQuizCount();
  document.getElementById('img-preview-grid').innerHTML = '';
  document.getElementById('vocab-list-builder').innerHTML = '';
  document.getElementById('cd-type').value = 'vocab';
  selectAssignType('vocab');
}

async function createAssignmentInClass() {
  const title = document.getElementById('cd-title').value.trim();
  const type  = document.getElementById('cd-type').value;
  const desc  = document.getElementById('cd-adesc').value.trim();
  const due   = document.getElementById('cd-due').value;
  if (!title) { showModal('⚠️','Thiếu tiêu đề','Vui lòng nhập tiêu đề bài tập.','OK',closeModal); return; }

  // Validate vocab
  if (type === 'vocab') {
    if (vocabCards.length === 0) { showModal('⚠️','Chưa có từ vựng','Vui lòng thêm ít nhất 1 từ vựng.','OK',closeModal); return; }
    const invalid = vocabCards.find(v => !v.word.trim() || !v.meaning.trim());
    if (invalid) { showModal('⚠️','Thiếu thông tin','Mỗi từ cần có từ tiếng Anh và nghĩa tiếng Việt.','OK',closeModal); return; }
  }
  // Validate fill-in-blank
  if (type === 'fill') {
    const rows = getFillData();
    if (rows.length === 0) { showModal('⚠️','Chưa có từ','Vui lòng thêm ít nhất 1 từ.','OK',closeModal); return; }
  }
  // Validate match2
  if (type === 'match2') {
    const pairs = getMatch2Data();
    if (pairs.length < 2) { showModal('⚠️','Chưa đủ cặp từ','Vui lòng thêm ít nhất 2 cặp từ.','OK',closeModal); return; }
    const bad = pairs.find(p => !p.word.trim() || !p.meaning.trim());
    if (bad) { showModal('⚠️','Thiếu thông tin','Mỗi cặp cần có từ tiếng Anh và nghĩa.','OK',closeModal); return; }
  }
  // Validate quiz
  if (type === 'quiz') {
    const questions = getQuizData();
    if (questions.length === 0) { showModal('⚠️','Chưa có câu hỏi','Vui lòng thêm ít nhất 1 câu hỏi và điền đủ 4 đáp án.','OK',closeModal); return; }
  }
  // Validate thông báo
  if (type === 'announce' && !desc) {
    showModal('⚠️','Thiếu nội dung','Vui lòng nhập nội dung thông báo.','OK',closeModal); return;
  }

  const btn = document.getElementById('cd-abtn');
  btn.textContent = type === 'announce' ? 'Đang gửi...' : 'Đang tạo...'; btn.disabled = true;

  const imageUrls = uploadedImages.map(i => i.url);
  const vocabData  = type === 'vocab'  ? vocabCards.map(v => ({ word:v.word.trim(), phonetic:v.phonetic.trim(), meaning:v.meaning.trim(), example:(v.example||'').trim(), image_url:v.image_url||null })) : null;
  // Lưu ý: câu hỏi Quiz được lưu tạm vào cột fill_data (cột này không dùng đến khi type khác 'fill')
  const fillData   = type === 'fill' ? getFillData() : (type === 'quiz' ? getQuizData() : null);
  const match2Data = type === 'match2' ? getMatch2Data() : null;

  const { error } = await sb.from('assignments').insert({
    teacher_id: currentUser.id, class_id: currentClassId,
    title, type,
    description: type === 'announce' ? (desc||null) : null,
    images: imageUrls.length ? imageUrls : null,
    vocab_words: vocabData,
    fill_data: fillData,
    match2_data: match2Data,
    due_date: type === 'announce' ? null : (due || null)
  });

  btn.textContent = type === 'announce' ? '📢 Gửi thông báo cho cả lớp' : '✓ Giao bài cho học sinh'; btn.disabled = false;
  if (error) { showModal('❌','Lỗi',error.message,'OK',closeModal); return; }

  // Reset form
  document.getElementById('cd-title').value = '';
  document.getElementById('cd-adesc').value = '';
  document.getElementById('cd-due').value = '';
  document.getElementById('cd-type').value = 'vocab';
  selectAssignType('vocab');
  uploadedImages = []; vocabCards = [];
  document.getElementById("fill-list").innerHTML = "";
  document.getElementById("match2-list").innerHTML = "";
  updateMatch2Count();
  document.getElementById("quiz-list").innerHTML = "";
  quizRows = [];
  updateQuizCount();
  renderImgPreviews();
  hideCreateAssignInClass();
  await loadClassAssignments();
  const wordCount = vocabData ? ` (${vocabData.length} từ vựng)` : '';
  if (type === 'announce') {
    showModal('✅','Đã gửi thông báo!',`Thông báo "${title}" đã được gửi đến cả lớp.`,'OK',closeModal);
  } else {
    showModal('✅','Đã giao bài!',`Bài tập "${title}"${wordCount} đã giao cho học sinh.`,'OK',closeModal);
  }
}

async function deleteAssignment(id) {
  if (!confirm('Xóa bài tập này?')) return;
  await sb.from('assignments').delete().eq('id', id);
  await loadClassAssignments();
}

// ─── ADMIN ────────────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
// ── ADMIN — đầy đủ 4 tab ──────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
let _admAllUsers = [];

