function initBakeryGame() {
  const root = document.getElementById('bakery-root');
  if (bakeryInited || !root) return;
  bakeryInited = true;

  root.innerHTML = `
<style>
#bk *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
#bk{width:100%;min-height:580px;background:#FFE8D6;border-radius:18px;overflow:hidden;position:relative;font-family:'Nunito',sans-serif}
#bk .sky{background:#FFE8D6;padding:14px;min-height:580px;display:flex;flex-direction:column;align-items:center}
#bk .bk-screen{display:none;flex-direction:column;align-items:center;padding:14px;width:100%}
#bk .bk-screen.active{display:flex}
#bk .bk-title{font-size:22px;font-weight:900;color:#7A4419;text-align:center;margin:8px 0}
#bk .bk-sub{font-size:13px;color:#A6713E;text-align:center;margin-bottom:10px}
#bk .bk-pet{font-size:60px;text-align:center;animation:bkbob 1.8s ease-in-out infinite alternate}
@keyframes bkbob{0%{transform:translateY(0)}100%{transform:translateY(-7px)}}
#bk .bk-btn{background:#E8584D;border:none;border-radius:99px;padding:12px 28px;color:#fff;font-size:15px;font-weight:800;cursor:pointer;margin:6px;font-family:inherit;transition:transform .1s}
#bk .bk-btn:active{transform:scale(.95)}
#bk .bk-btn.green{background:#5DAA5D}
#bk .bk-btn.blue{background:#5B8FD4}
#bk .back-btn{background:#fff;border:none;border-radius:99px;padding:5px 14px;font-size:12px;cursor:pointer;color:#A6713E;font-family:inherit;align-self:flex-start;margin-bottom:6px}
#bk .order-bubble{background:#fff;border-radius:18px;padding:14px 18px;margin:10px 0;text-align:center;box-shadow:0 2px 0 #f0d4b8;width:100%;position:relative}
#bk .order-bubble::after{content:'';position:absolute;bottom:-10px;left:50%;transform:translateX(-50%);border-width:10px 8px 0;border-style:solid;border-color:#fff transparent transparent}
#bk .customer{font-size:64px;text-align:center;cursor:pointer;animation:bkbob 2s ease-in-out infinite alternate}
#bk .order-text{display:none}
#bk .listen-btn{background:#FFD166;border:none;border-radius:99px;padding:6px 16px;font-size:12px;font-weight:700;color:#7A4419;cursor:pointer;font-family:inherit;margin-top:6px}
#bk .choice-row{display:flex;gap:14px;justify-content:center;flex-wrap:wrap;margin:14px 0}
#bk .choice-card{background:#fff;border:3px solid #f0d4b8;border-radius:16px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:6px;cursor:pointer;transition:all .15s;min-width:90px}
#bk .choice-card:hover{border-color:#FFD166}
#bk .choice-card.selected{border-color:#5DAA5D;background:#EAF3DE}
#bk .choice-card .cic{font-size:38px}
#bk .choice-card .cilbl{font-size:12px;font-weight:700;color:#7A4419}
#bk .step-area{width:100%;background:#fff;border-radius:18px;padding:20px;text-align:center;margin:10px 0}
#bk .mix-zone{width:140px;height:140px;border-radius:50%;background:#F5E6CC;border:4px dashed #D4A968;margin:14px auto;display:flex;align-items:center;justify-content:center;font-size:54px;cursor:pointer;position:relative;transition:background .2s,transform .1s}
#bk .mix-zone:active{transform:scale(.92)}
#bk .mix-zone.active{background:#E8D4A8}
#bk .progress-ring{position:absolute;inset:-4px;border-radius:50%}
#bk .pour-zone{width:120px;height:160px;margin:14px auto;position:relative;display:flex;align-items:flex-end;justify-content:center}
#bk .milk-carton{font-size:48px;cursor:pointer;transition:transform .3s}
#bk .milk-carton.tilted{transform:rotate(-50deg) translate(-10px,-10px)}
#bk .bake-zone{width:160px;height:120px;background:#5A4632;border-radius:16px;margin:14px auto;display:flex;align-items:center;justify-content:center;font-size:44px;position:relative;cursor:pointer}
#bk .bake-timer{position:absolute;top:-26px;left:50%;transform:translateX(-50%);font-size:20px;font-weight:900;color:#E8584D}
#bk .deco-tray{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin:14px 0;background:#fff;border-radius:16px;padding:14px}
#bk .candy{font-size:30px;cursor:grab;transition:transform .15s;touch-action:none}
#bk .candy:active{transform:scale(1.3)}
#bk .cake-canvas{width:160px;height:140px;background:#F5DEB3;border-radius:50% 50% 20px 20px / 60% 60% 20px 20px;margin:10px auto;position:relative;border:3px solid #D4A968;display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:4px;padding:10px}
#bk .feedback{font-size:18px;font-weight:800;text-align:center;min-height:28px;margin:6px 0}
#bk .feedback.ok{color:#27500A}#bk .feedback.wrong{color:#A32D2D}
#bk .stat-row{display:flex;gap:8px;justify-content:center;margin:8px 0}
#bk .stat-pill{background:#fff;border-radius:99px;padding:6px 16px;font-size:12px;font-weight:700;color:#7A4419}
#bk .ingredient-shelf{display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin:10px 0}
#bk .ing-item{background:#fff;border:2px solid #f0d4b8;border-radius:12px;padding:8px 12px;display:flex;align-items:center;gap:6px;font-size:13px;font-weight:700;color:#7A4419}
#bk .recipe-book{display:flex;flex-wrap:wrap;gap:10px;background:#fff;border-radius:16px;padding:14px;min-height:70px;justify-content:center;width:100%;margin:8px 0}
#bk .recipe-item{font-size:34px;cursor:pointer;transition:transform .15s;position:relative}
#bk .recipe-item.locked{opacity:.3;filter:grayscale(1)}
#bk .badge-new{position:absolute;top:-6px;right:-6px;font-size:11px;background:#E8584D;color:#fff;border-radius:99px;padding:1px 5px}
</style>

<div id="bk">

<div id="bk-home" class="bk-screen active sky" style="min-height:580px;justify-content:center">
  <div class="bk-pet" id="bk-home-pet">🧑‍🍳</div>
  <div class="bk-title">🧁 Tiny Chef Bakery</div>
  <div class="bk-sub">Tiệm Bánh Tiếng Anh</div>
  <div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin:14px 0">
    <button class="bk-btn" onclick="bkStartDay()">▶ Mở tiệm bánh</button>
    <button class="bk-btn blue" onclick="bkOpenRecipes()">📖 Sổ công thức</button>
  </div>
  <div class="stat-row">
    <div class="stat-pill">⭐ <span id="bk-score">0</span> điểm</div>
    <div class="stat-pill">🍰 <span id="bk-cakes">0</span> bánh đã làm</div>
  </div>
</div>

<div id="bk-order" class="bk-screen sky" style="min-height:580px;justify-content:flex-start">
  <button class="back-btn" onclick="bkGoHome()">← Quay lại</button>
  <div class="bk-sub" id="bk-order-counter">Khách 1/5</div>
  <div class="customer" id="bk-customer" onclick="bkReplayOrder()">🐰</div>
  <div class="order-bubble">
    <div style="font-size:11px;font-weight:800;color:#C77B00;text-transform:uppercase;letter-spacing:.04em;margin-bottom:4px">🔊 Nghe yêu cầu của khách</div>
    <div class="order-text" id="bk-order-text">"I want a cake, please!"</div>
    <button class="listen-btn" onclick="bkReplayOrder()">🔊 Nghe lại</button>
  </div>
  <div class="bk-sub" style="margin-top:10px">Chọn đúng kích thước</div>
  <div class="choice-row" id="bk-size-choices"></div>
  <div class="bk-sub">Chọn đúng vị</div>
  <div class="choice-row" id="bk-flavor-choices"></div>
  <div class="feedback" id="bk-order-fb"></div>
</div>

<div id="bk-cook" class="bk-screen sky" style="min-height:580px;justify-content:flex-start">
  <button class="back-btn" onclick="bkQuitOrder()">← Bỏ giữa chừng</button>
  <div class="bk-sub" id="bk-cook-step">Bước 1/3</div>
  <div class="step-area" id="bk-cook-area"></div>
  <div class="feedback" id="bk-cook-fb"></div>
</div>

<div id="bk-deco" class="bk-screen sky" style="min-height:580px;justify-content:flex-start">
  <button class="back-btn" onclick="bkQuitOrder()">← Bỏ giữa chừng</button>
  <div class="order-bubble" style="margin-bottom:10px">
    <div style="font-size:11px;font-weight:800;color:#C77B00;text-transform:uppercase;letter-spacing:.04em;margin-bottom:4px">🔊 Nghe yêu cầu</div>
    <div class="order-text" style="margin-bottom:8px">"Decorate the cake!"</div>
    <button class="listen-btn" onclick="bkSpeak('Decorate the cake')">🔊 Nghe lại</button>
  </div>
  <div class="bk-sub">Trang trí chiếc bánh của bé!</div>
  <div class="cake-canvas" id="bk-cake-canvas"></div>
  <div class="deco-tray" id="bk-candy-tray"></div>
  <div class="feedback" id="bk-deco-fb"></div>
  <button class="bk-btn green" onclick="bkFinishDeco()">✅ Hoàn thành bánh!</button>
</div>

<div id="bk-result" class="bk-screen sky" style="min-height:580px;justify-content:center">
  <div class="bk-pet" id="bk-result-pet">🐰</div>
  <div class="bk-title" id="bk-result-title">Yum yum!</div>
  <div class="order-bubble" id="bk-result-msg">Thank you!</div>
  <div class="stat-row">
    <div class="stat-pill">⭐ +<span id="bk-result-score">10</span> điểm</div>
  </div>
  <button class="bk-btn green" onclick="bkNextCustomer()" id="bk-next-btn">Khách tiếp theo →</button>
</div>

<div id="bk-day-complete" class="bk-screen sky" style="min-height:580px;justify-content:center">
  <div class="bk-pet">🎉</div>
  <div class="bk-title">Hết ngày làm việc!</div>
  <div class="bk-sub">Tiệm bánh của bé hôm nay thật tuyệt vời</div>
  <div class="stat-row">
    <div class="stat-pill">🍰 <span id="bk-day-cakes">0</span> bánh đã làm</div>
    <div class="stat-pill">⭐ +<span id="bk-day-score">0</span> điểm hôm nay</div>
  </div>
  <button class="bk-btn green" onclick="bkGoHome()">🏠 Về trang chủ</button>
</div>

<div id="bk-recipes" class="bk-screen sky" style="min-height:580px;justify-content:flex-start">
  <button class="back-btn" onclick="bkGoHome()">← Quay lại</button>
  <div class="bk-title" style="font-size:18px">📖 Sổ Công Thức</div>
  <div class="recipe-book" id="bk-recipe-book"></div>
  <div class="bk-sub" style="margin-top:8px">Hoàn thành đơn hàng để mở khóa nguyên liệu mới!</div>
</div>

</div>
`;

  // ── Data ──
  const BK_CUSTOMERS = [
    {emoji:'🐰',name:'Rabbit'}, {emoji:'🐻',name:'Bear'}, {emoji:'🐱',name:'Cat'},
    {emoji:'🐶',name:'Dog'}, {emoji:'🐼',name:'Panda'}, {emoji:'🦊',name:'Fox'}
  ];
  const BK_SIZES   = [{w:'small',emoji:'🧁',label:'Small'},{w:'big',emoji:'🎂',label:'Big'}];
  const BK_FLAVORS = [
    {w:'strawberry',emoji:'🍓',label:'Strawberry'},{w:'chocolate',emoji:'🍫',label:'Chocolate'},
    {w:'vanilla',emoji:'🍦',label:'Vanilla'},{w:'blueberry',emoji:'🫐',label:'Blueberry',locked:true}
  ];
  const BK_CANDIES = [
    {emoji:'🍬',name:'red candy',unlocked:true},{emoji:'⭐',name:'star chocolate',unlocked:true},
    {emoji:'🍭',name:'swirl candy',unlocked:true},{emoji:'💚',name:'green candy',unlocked:true},
    {emoji:'🔵',name:'blue candy',unlocked:false},{emoji:'🟡',name:'yellow star',unlocked:false}
  ];

  let bs = {score:0, cakes:0, unlockedFlavors:['strawberry','chocolate','vanilla'], unlockedCandies:['🍬','⭐','🍭','💚']};
  try { const d = localStorage.getItem('bakery1'); if(d) Object.assign(bs, JSON.parse(d)); } catch(e){}
  function bkSave(){ try{ localStorage.setItem('bakery1', JSON.stringify(bs)); }catch(e){} }

  let order = {customerIdx:0, size:null, flavor:null, chosenSize:null, chosenFlavor:null};
  let dayCustomers = [];
  let dayIdx = 0;
  let cookStep = 0;
  let cakeDecorations = [];
  let daySales = {cakes:0, score:0};
  let dayStreakLogged = false;

  window.bkQuitOrder = function(){
    bkGoHome();
  };

  function bkShow(id){
    document.querySelectorAll('#bk .bk-screen').forEach(s=>s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
  }

  function bkSpeak(text){
    if(!window.speechSynthesis) return;
    const u = new SpeechSynthesisUtterance(text);
    u.lang='en-US'; u.rate=0.82; u.pitch=1.15;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  }

  function bkUpdateHome(){
    document.getElementById('bk-score').textContent = bs.score;
    document.getElementById('bk-cakes').textContent = bs.cakes;
  }

  window.bkGoHome = function(){ bkUpdateHome(); bkShow('bk-home'); };

  window.bkStartDay = function(){
    dayCustomers = [...BK_CUSTOMERS].sort(()=>Math.random()-.5).slice(0,5);
    dayIdx = 0;
    daySales = {cakes:0, score:0};
    dayStreakLogged = false;
    bkShow('bk-order');
    bkNextOrder();
  };

  function bkNextOrder(){
    if(dayIdx >= dayCustomers.length){ bkGoHome(); return; }
    const cust = dayCustomers[dayIdx];
    const availFlavors = BK_FLAVORS.filter(f => bs.unlockedFlavors.includes(f.w));
    order.size   = BK_SIZES[Math.floor(Math.random()*BK_SIZES.length)];
    order.flavor = availFlavors[Math.floor(Math.random()*availFlavors.length)];
    order.chosenSize = null; order.chosenFlavor = null;

    document.getElementById('bk-order-counter').textContent = 'Khách ' + (dayIdx+1) + '/' + dayCustomers.length;
    document.getElementById('bk-customer').textContent = cust.emoji;
    document.getElementById('bk-order-text').textContent =
      '"I want a ' + order.size.w + ' ' + order.flavor.w + ' cake, please!"';
    document.getElementById('bk-order-fb').textContent = '';

    const sizeRow = document.getElementById('bk-size-choices');
    sizeRow.innerHTML = '';
    BK_SIZES.forEach(s => {
      const c = document.createElement('div');
      c.className = 'choice-card';
      c.innerHTML = '<span class="cic">'+s.emoji+'</span><span class="cilbl">'+s.label+'</span>';
      c.onclick = () => bkPickSize(s, c);
      sizeRow.appendChild(c);
    });

    const flavorRow = document.getElementById('bk-flavor-choices');
    flavorRow.innerHTML = '';
    availFlavors.forEach(f => {
      const c = document.createElement('div');
      c.className = 'choice-card';
      c.innerHTML = '<span class="cic">'+f.emoji+'</span><span class="cilbl">'+f.label+'</span>';
      c.onclick = () => bkPickFlavor(f, c);
      flavorRow.appendChild(c);
    });

    setTimeout(() => bkSpeak('I want a ' + order.size.w + ' ' + order.flavor.w + ' cake, please'), 400);
  }

  window.bkReplayOrder = function(){
    bkSpeak('I want a ' + order.size.w + ' ' + order.flavor.w + ' cake, please');
  };

  function bkPickSize(s, el){
    document.querySelectorAll('#bk-size-choices .choice-card').forEach(c=>c.classList.remove('selected'));
    el.classList.add('selected');
    order.chosenSize = s;
    bkSpeak(s.w);
    bkCheckOrder();
  }
  function bkPickFlavor(f, el){
    document.querySelectorAll('#bk-flavor-choices .choice-card').forEach(c=>c.classList.remove('selected'));
    el.classList.add('selected');
    order.chosenFlavor = f;
    bkSpeak(f.w);
    bkCheckOrder();
  }

  function bkCheckOrder(){
    if(!order.chosenSize || !order.chosenFlavor) return;
    const fb = document.getElementById('bk-order-fb');
    if(order.chosenSize.w === order.size.w && order.chosenFlavor.w === order.flavor.w){
      fb.textContent = '🌟 Correct order!'; fb.className = 'feedback ok';
      setTimeout(() => { cookStep = 0; currentCookSteps = bkBuildCookSteps(); bkShow('bk-cook'); bkRenderCookStep(); }, 900);
    } else {
      fb.textContent = '❌ Try again!'; fb.className = 'feedback wrong';
      setTimeout(() => {
        order.chosenSize = null; order.chosenFlavor = null;
        document.querySelectorAll('#bk .choice-card').forEach(c=>c.classList.remove('selected'));
        fb.textContent = '';
      }, 1000);
    }
  }

  // ── Cooking steps ──
  const COOK_TEMPLATES = [
    {verb:'pour', icon:'🥛', template:'Pour the {L}!',
      options:[{label:'milk',vn:'sữa',emoji:'🥛'},{label:'water',vn:'nước',emoji:'💧'},{label:'juice',vn:'nước ép',emoji:'🧃'}]},
    {verb:'mix',  icon:'🌾', template:'Mix the {L}!',
      options:[{label:'flour',vn:'bột mì',emoji:'🌾'},{label:'sugar',vn:'đường',emoji:'🍬'},{label:'salt',vn:'muối',emoji:'🧂'}]},
    {verb:'bake', icon:'🎂', template:'Set the oven to {L}!',
      options:[{label:'hot',vn:'nóng',emoji:'🔥'},{label:'warm',vn:'ấm',emoji:'🌤️'},{label:'cold',vn:'lạnh',emoji:'🧊'}]}
  ];

  // Mỗi lượt làm bánh sẽ random lại đáp án đúng của cả 3 bước, để học sinh
  // luôn phải nghe kỹ chứ không thể học thuộc lòng 1 đáp án cố định.
  function bkBuildCookSteps(){
    return COOK_TEMPLATES.map(t => {
      const correct = t.options[Math.floor(Math.random() * t.options.length)];
      return {
        verb: t.verb,
        icon: t.icon,
        word: t.template.replace('{L}', correct.label),
        options: t.options,
        correctLabel: correct.label
      };
    });
  }
  let currentCookSteps = bkBuildCookSteps();

  function bkRenderCookStep(){
    const step = currentCookSteps[cookStep];
    document.getElementById('bk-cook-step').textContent = 'Bước ' + (cookStep+1) + '/3: ' + step.word;
    document.getElementById('bk-cook-fb').textContent = '';
    bkRenderCookChoice(step);
  }

  // Giai đoạn 1: Nghe & chọn đúng từ tiếng Anh (chỉ cần bấm 1 lần, dễ thao tác)
  function bkRenderCookChoice(step){
    const area = document.getElementById('bk-cook-area');
    const opts = [...step.options].sort(()=>Math.random()-.5);
    area.innerHTML =
      '<div class="order-bubble" style="margin-bottom:14px">' +
        '<div style="font-size:11px;font-weight:800;color:#C77B00;text-transform:uppercase;letter-spacing:.04em;margin-bottom:4px">🔊 Nghe yêu cầu</div>' +
        '<div class="order-text" style="margin-bottom:8px">"' + step.word + '"</div>' +
        '<button class="listen-btn" id="bk-choice-speak">🔊 Nghe lại</button>' +
      '</div>' +
      '<div style="font-size:13px;color:#A6713E;margin-bottom:10px">Bấm vào nguyên liệu đúng!</div>' +
      '<div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap" id="bk-choice-row"></div>';
    document.getElementById('bk-choice-speak').onclick = () => bkSpeak(step.word);
    setTimeout(() => bkSpeak(step.word), 300);
    const row = document.getElementById('bk-choice-row');
    opts.forEach(opt => {
      const b = document.createElement('button');
      b.style.cssText = 'background:#fff;border:2.5px solid #f0c78a;border-radius:14px;padding:12px 16px;cursor:pointer;font-family:inherit;display:flex;flex-direction:column;align-items:center;gap:4px;min-width:84px';
      b.innerHTML = '<span style="font-size:34px">'+opt.emoji+'</span><span style="font-size:12px;font-weight:800;color:#7A4419">'+opt.label+'</span><span style="font-size:10px;color:#A6713E">('+opt.vn+')</span>';
      b.onclick = () => {
        if(opt.label === step.correctLabel){
          row.querySelectorAll('button').forEach(x=>x.style.pointerEvents='none');
          b.style.borderColor = '#43a047'; b.style.background = '#e8f5e9';
          bkSpeak(opt.label);
          const fb = document.getElementById('bk-cook-fb');
          fb.textContent = '✅ Đúng rồi!'; fb.className = 'feedback ok';
          setTimeout(() => bkRenderCookAction(step), 700);
        } else {
          b.style.borderColor = '#e53935'; b.style.background = '#ffebee';
          b.style.animation = 'qshake .3s ease';
          bkSpeak(opt.label);
          const fb = document.getElementById('bk-cook-fb');
          fb.textContent = '❌ Không phải "' + opt.label + '", thử lại nhé!'; fb.className = 'feedback wrong';
          setTimeout(() => { b.style.borderColor = '#f0c78a'; b.style.background = '#fff'; b.style.animation = ''; }, 500);
        }
      };
      row.appendChild(b);
    });
  }

  // Giai đoạn 2: Thao tác đơn giản (chỉ cần bấm, không cần giữ hay xoay tròn)
  function bkReqBubble(step){
    return '<div class="order-bubble" style="margin-bottom:12px">' +
        '<div style="font-size:11px;font-weight:800;color:#C77B00;text-transform:uppercase;letter-spacing:.04em;margin-bottom:4px">🔊 Nghe yêu cầu</div>' +
        '<div class="order-text" style="margin-bottom:8px">"' + step.word + '"</div>' +
        '<button class="listen-btn" onclick="bkSpeak(\'' + step.word.replace(/[!'"]/g,'') + '\')">🔊 Nghe lại</button>' +
      '</div>';
  }

  function bkRenderCookAction(step){
    const area = document.getElementById('bk-cook-area');
    document.getElementById('bk-cook-fb').textContent = '';

    if(step.verb === 'pour'){
      area.innerHTML = bkReqBubble(step) +
        '<div style="font-size:15px;font-weight:700;color:#7A4419;margin-bottom:6px">🥛 Bấm vào hộp sữa để rót!</div>' +
        '<div class="pour-zone"><span class="milk-carton" id="bk-milk">🥛</span></div>' +
        '<div style="font-size:13px;color:#A6713E">Chỉ cần bấm 1 lần</div>';
      const milk = document.getElementById('bk-milk');
      milk.onclick = () => {
        milk.onclick = null;
        milk.classList.add('tilted');
        bkSpeak(step.word.replace(/!$/, ''));
        setTimeout(() => bkCookStepDone(), 1400);
      };
    }
    else if(step.verb === 'mix'){
      area.innerHTML = bkReqBubble(step) +
        '<div style="font-size:15px;font-weight:700;color:#7A4419;margin-bottom:6px">🌾 Bấm vào bát bột để trộn!</div>' +
        '<div class="mix-zone" id="bk-mixzone">🥣</div>' +
        '<div style="font-size:13px;color:#A6713E">Bấm <span id="bk-mix-count">0</span>/5 lần</div>';
      const zone = document.getElementById('bk-mixzone');
      let mixCount = 0;
      zone.onclick = () => {
        mixCount++;
        document.getElementById('bk-mix-count').textContent = Math.min(mixCount,5);
        zone.classList.add('active');
        setTimeout(()=>zone.classList.remove('active'),150);
        if(mixCount === 1) bkSpeak(step.word.replace(/!$/, ''));
        if(mixCount >= 5){ zone.onclick = null; bkCookStepDone(); }
      };
    }
    else if(step.verb === 'bake'){
      area.innerHTML = bkReqBubble(step) +
        '<div style="font-size:15px;font-weight:700;color:#7A4419;margin-bottom:6px">🔥 Bấm vào lò nướng để nướng bánh!</div>' +
        '<div class="bake-zone" id="bk-bakezone"><span class="bake-timer" id="bk-bake-timer"></span>🍰</div>';
      const oven = document.getElementById('bk-bakezone');
      oven.onclick = function(){
        oven.onclick = null;
        bkSpeak(step.word.replace(/!$/, ''));
        let count = 3;
        const timerEl = document.getElementById('bk-bake-timer');
        timerEl.textContent = count;
        const iv = setInterval(() => {
          count--;
          if(count > 0){ timerEl.textContent = count; bkSpeak(String(count)); }
          else {
            clearInterval(iv);
            timerEl.textContent = '✅';
            bkSpeak('Done');
            setTimeout(() => bkCookStepDone(), 600);
          }
        }, 800);
      };
    }
  }

  function bkCookStepDone(){
    const fb = document.getElementById('bk-cook-fb');
    fb.textContent = '🌟 Great job!'; fb.className = 'feedback ok';
    cookStep++;
    setTimeout(() => {
      if(cookStep >= currentCookSteps.length){
        bkStartDeco();
      } else {
        bkRenderCookStep();
      }
    }, 1000);
  }

  // ── Decoration ──
  function bkStartDeco(){
    cakeDecorations = [];
    bkShow('bk-deco');
    setTimeout(() => bkSpeak('Decorate the cake'), 300);
    const canvas = document.getElementById('bk-cake-canvas');
    canvas.innerHTML = '';
    const fb = document.getElementById('bk-deco-fb');
    if (fb) { fb.textContent = ''; fb.className = 'feedback'; }
    const tray = document.getElementById('bk-candy-tray');
    tray.innerHTML = '';
    BK_CANDIES.forEach(c => {
      if(!bs.unlockedCandies.includes(c.emoji)) return;
      const el = document.createElement('span');
      el.className = 'candy';
      el.textContent = c.emoji;
      el.onclick = () => {
        bkSpeak(c.name);
        const piece = document.createElement('span');
        piece.style.fontSize = '22px';
        piece.textContent = c.emoji;
        canvas.appendChild(piece);
        cakeDecorations.push(c.emoji);
        const fb2 = document.getElementById('bk-deco-fb');
        if (fb2) fb2.textContent = '';
      };
      tray.appendChild(el);
    });
  }

  window.bkFinishDeco = function(){
    if (cakeDecorations.length === 0) {
      const fb = document.getElementById('bk-deco-fb');
      fb.textContent = '🍬 Hãy thêm ít nhất 1 topping cho bánh nhé!';
      fb.className = 'feedback wrong';
      return;
    }
    const bonus = Math.min(cakeDecorations.length, 5) * 2; // tối đa +10 điểm cho trang trí
    const earned = 20 + bonus;
    bs.score += earned; bs.cakes++;
    daySales.cakes++; daySales.score += earned;
    bkSave();
    const cust = dayCustomers[dayIdx];
    document.getElementById('bk-result-pet').textContent = cust.emoji;
    document.getElementById('bk-result-title').textContent = 'Yum yum! 🎉';
    document.getElementById('bk-result-msg').textContent = '"Thank you! This cake is delicious!"';
    document.getElementById('bk-result-score').textContent = earned;
    bkSpeak('Yum yum, thank you!');

    // Mở khóa nguyên liệu mới mỗi 3 bánh
    if(bs.cakes % 3 === 0){
      const lockedFlavor = BK_FLAVORS.find(f => !bs.unlockedFlavors.includes(f.w));
      const lockedCandy  = BK_CANDIES.find(c => !bs.unlockedCandies.includes(c.emoji));
      if(lockedFlavor){ bs.unlockedFlavors.push(lockedFlavor.w); bkSave();
        document.getElementById('bk-result-msg').innerHTML += '<br><br>🎁 Mở khóa: <b>'+lockedFlavor.label+'</b>!';
      } else if(lockedCandy){ bs.unlockedCandies.push(lockedCandy.emoji); bkSave();
        document.getElementById('bk-result-msg').innerHTML += '<br><br>🎁 Mở khóa: <b>'+lockedCandy.emoji+'</b>!';
      }
    }

    const nextBtn = document.getElementById('bk-next-btn');
    nextBtn.textContent = (dayIdx+1 >= dayCustomers.length) ? 'Xem tổng kết ngày →' : 'Khách tiếp theo →';
    bkShow('bk-result');
  };

  window.bkNextCustomer = function(){
    dayIdx++;
    if(dayIdx >= dayCustomers.length){
      if (!dayStreakLogged && typeof markStudiedToday === 'function') { markStudiedToday('quiz'); dayStreakLogged = true; }
      document.getElementById('bk-day-cakes').textContent = daySales.cakes;
      document.getElementById('bk-day-score').textContent = daySales.score;
      bkShow('bk-day-complete');
      return;
    }
    bkShow('bk-order');
    bkNextOrder();
  };

  // ── Recipe book ──
  window.bkOpenRecipes = function(){
    bkShow('bk-recipes');
    const book = document.getElementById('bk-recipe-book');
    book.innerHTML = '';
    BK_FLAVORS.forEach(f => {
      const unlocked = bs.unlockedFlavors.includes(f.w);
      const el = document.createElement('div');
      el.className = 'recipe-item' + (unlocked ? '' : ' locked');
      el.textContent = f.emoji;
      el.title = f.label;
      book.appendChild(el);
    });
    BK_CANDIES.forEach(c => {
      const unlocked = bs.unlockedCandies.includes(c.emoji);
      const el = document.createElement('div');
      el.className = 'recipe-item' + (unlocked ? '' : ' locked');
      el.textContent = c.emoji;
      el.title = c.name;
      book.appendChild(el);
    });
  };

  bkUpdateHome();
}

// ─── EVENT DELEGATION (thay thế tất cả onclick inline có biến) ─────
document.addEventListener('click', function(e) {
  const t = e.target;

  // 1. Học sinh bấm vào lớp học
  const sClass = t.closest('.ev-student-class');
  if (sClass) { openStudentClassView(sClass.dataset.id, sClass.dataset.name); return; }

  // 2. Học sinh làm bài
  const doAssign = t.closest('.ev-do-assign');
  if (doAssign) { doAssignment(doAssign.dataset.atype, doAssign.dataset.aid); return; }

  // 3. Quiz chọn đáp án
  const qOpt = t.closest('.ev-quiz-opt');
  if (qOpt) { pickOpt(qOpt, qOpt.dataset.opt, qOpt.dataset.ans); return; }

  // 4. Giáo viên bấm vào lớp học
  const tcClass = t.closest('.ev-open-class');
  if (tcClass) {
    const d = tcClass.dataset;
    openClassDetail(d.id, d.name, d.desc, d.code, d.link);
    return;
  }

  // 5. Kick học sinh
  const kick = t.closest('.ev-kick');
  if (kick) { kickStudent(kick.dataset.mid, kick.dataset.name); return; }


});

// ─── QUÊN MẬT KHẨU ────────────────────────────────────────────────
function setGameMode(mode) {
  document.getElementById('gmode-mwi').classList.toggle('active', mode === 'mwi');
  document.getElementById('gmode-listen').classList.toggle('active', mode === 'listen');
  document.getElementById('gmode-memory').classList.toggle('active', mode === 'memory');
  document.getElementById('gmode-bakery').classList.toggle('active', mode === 'bakery');
  document.getElementById('mwi-root').style.display = mode === 'mwi' ? '' : 'none';
  document.getElementById('listen-root').style.display = mode === 'listen' ? '' : 'none';
  document.getElementById('memory-root').style.display = mode === 'memory' ? '' : 'none';
  document.getElementById('bakery-root').style.display = mode === 'bakery' ? '' : 'none';
  if (mode === 'mwi') initMiniGame();
  if (mode === 'listen') initListenGame();
  if (mode === 'memory') initMemoryGame();
  if (mode === 'bakery') initBakeryGame();
  bgRefreshStudentMusic();
}

// ── Dữ liệu từ vựng dùng chung cho các mini game (Đảo Từ Vựng + Nghe & Chọn) ──
  const MWI_TOPICS = [
    {id:'animals',label:'Động vật',icon:'🐾',words:[
      {w:'CAT',emoji:'🐱',blank:1},{w:'DOG',emoji:'🐶',blank:1},
      {w:'FISH',emoji:'🐟',blank:2},{w:'BIRD',emoji:'🐦',blank:1},
      {w:'COW',emoji:'🐄',blank:1},{w:'PIG',emoji:'🐷',blank:1},
      {w:'HEN',emoji:'🐔',blank:1},{w:'FROG',emoji:'🐸',blank:2},
      {w:'DUCK',emoji:'🦆',blank:2},{w:'BEAR',emoji:'🐻',blank:2},
      {w:'LION',emoji:'🦁',blank:2},{w:'WOLF',emoji:'🐺',blank:2},
      {w:'DEER',emoji:'🦌',blank:2},{w:'CRAB',emoji:'🦀',blank:2},
      {w:'GOAT',emoji:'🐐',blank:2},{w:'HORSE',emoji:'🐴',blank:3},
      {w:'TIGER',emoji:'🐯',blank:3},{w:'SHEEP',emoji:'🐑',blank:3},
      {w:'WHALE',emoji:'🐳',blank:3},{w:'SNAKE',emoji:'🐍',blank:3}
    ]},
    {id:'colors',label:'Màu sắc',icon:'🌈',words:[
      {w:'RED',emoji:'🔴',blank:1},{w:'BLUE',emoji:'🔵',blank:2},
      {w:'GREEN',emoji:'🟢',blank:3},{w:'PINK',emoji:'🌸',blank:2},
      {w:'GOLD',emoji:'⭐',blank:2},{w:'GRAY',emoji:'🩶',blank:2},
      {w:'CYAN',emoji:'🩵',blank:2},{w:'WHITE',emoji:'⬜',blank:3},
      {w:'BLACK',emoji:'⬛',blank:3},{w:'BROWN',emoji:'🟫',blank:3},
      {w:'ORANGE',emoji:'🟠',blank:3},{w:'PURPLE',emoji:'🟣',blank:4},
      {w:'YELLOW',emoji:'🟡',blank:3},{w:'VIOLET',emoji:'💜',blank:4},
      {w:'INDIGO',emoji:'🔮',blank:4}
    ]},
    {id:'food',label:'Đồ ăn',icon:'🍎',words:[
      {w:'APPLE',emoji:'🍎',blank:3},{w:'CAKE',emoji:'🎂',blank:1},
      {w:'MILK',emoji:'🥛',blank:2},{w:'EGG',emoji:'🥚',blank:1},
      {w:'RICE',emoji:'🍚',blank:2},{w:'BREAD',emoji:'🍞',blank:3},
      {w:'SOUP',emoji:'🍜',blank:2},{w:'MEAT',emoji:'🥩',blank:2},
      {w:'CORN',emoji:'🌽',blank:2},{w:'PEAR',emoji:'🍐',blank:2},
      {w:'PLUM',emoji:'🫐',blank:2},{w:'LIME',emoji:'🍋',blank:2},
      {w:'GRAPE',emoji:'🍇',blank:3},{w:'PIZZA',emoji:'🍕',blank:3},
      {w:'JUICE',emoji:'🧃',blank:3},{w:'CANDY',emoji:'🍬',blank:3},
      {w:'BANANA',emoji:'🍌',blank:4},{w:'COOKIE',emoji:'🍪',blank:4},
      {w:'DONUT',emoji:'🍩',blank:3},{w:'SALAD',emoji:'🥗',blank:3}
    ]},
    {id:'family',label:'Gia đình',icon:'👨‍👩‍👧',words:[
      {w:'MOM',emoji:'👩',blank:1},{w:'DAD',emoji:'👨',blank:1},
      {w:'BABY',emoji:'👶',blank:2},{w:'AUNT',emoji:'👩‍🦱',blank:2},
      {w:'SON',emoji:'👦',blank:1},{w:'SIS',emoji:'👧',blank:1},
      {w:'BRO',emoji:'👱',blank:1},{w:'UNCLE',emoji:'👨‍🦳',blank:3},
      {w:'GIRL',emoji:'👧',blank:2},{w:'BOY',emoji:'👦',blank:1},
      {w:'WIFE',emoji:'💑',blank:2},{w:'TWIN',emoji:'👯',blank:2},
      {w:'PAPA',emoji:'👴',blank:2},{w:'NANA',emoji:'👵',blank:2},
      {w:'NIECE',emoji:'🧒',blank:3},{w:'CHILD',emoji:'🧒',blank:3}
    ]},
    {id:'shapes',label:'Hình khối',icon:'🔷',words:[
      {w:'STAR',emoji:'⭐',blank:2},{w:'OVAL',emoji:'🥚',blank:2},
      {w:'CUBE',emoji:'📦',blank:2},{w:'RING',emoji:'💍',blank:2},
      {w:'CONE',emoji:'🍦',blank:2},{w:'LINE',emoji:'➖',blank:2},
      {w:'ARC',emoji:'🌈',blank:1},{w:'DOT',emoji:'🔵',blank:1},
      {w:'CROSS',emoji:'✝️',blank:3},{w:'ARROW',emoji:'➡️',blank:3},
      {w:'HEART',emoji:'❤️',blank:3},{w:'DIAMOND',emoji:'💎',blank:5},
      {w:'CIRCLE',emoji:'⭕',blank:4},{w:'SQUARE',emoji:'🟥',blank:4},
      {w:'TRIANGLE',emoji:'🔺',blank:5}
    ]},
    {id:'school',label:'Trường học',icon:'🏫',words:[
      {w:'PEN',emoji:'🖊️',blank:1},{w:'BAG',emoji:'🎒',blank:1},
      {w:'BOOK',emoji:'📚',blank:2},{w:'DESK',emoji:'🪑',blank:2},
      {w:'BELL',emoji:'🔔',blank:2},{w:'GLUE',emoji:'🧴',blank:2},
      {w:'RULER',emoji:'📏',blank:3},{w:'CLASS',emoji:'🏫',blank:3},
      {w:'PAINT',emoji:'🎨',blank:3},{w:'CHALK',emoji:'✏️',blank:3},
      {w:'PENCIL',emoji:'✏️',blank:4},{w:'ERASER',emoji:'🧹',blank:4},
      {w:'PAPER',emoji:'📄',blank:3},{w:'GLOBE',emoji:'🌍',blank:3},
      {w:'CLOCK',emoji:'🕐',blank:3},{w:'BOARD',emoji:'📋',blank:3}
    ]},
    {id:'body',label:'Cơ thể',icon:'🧒',words:[
      {w:'EAR',emoji:'👂',blank:1},{w:'EYE',emoji:'👁️',blank:1},
      {w:'LEG',emoji:'🦵',blank:1},{w:'ARM',emoji:'💪',blank:1},
      {w:'HAND',emoji:'✋',blank:2},{w:'FOOT',emoji:'🦶',blank:2},
      {w:'NOSE',emoji:'👃',blank:2},{w:'HAIR',emoji:'💇',blank:2},
      {w:'KNEE',emoji:'🦵',blank:2},{w:'BACK',emoji:'🔙',blank:2},
      {w:'MOUTH',emoji:'👄',blank:3},{w:'TOOTH',emoji:'🦷',blank:3},
      {w:'ELBOW',emoji:'💪',blank:3},{w:'CHEEK',emoji:'😊',blank:3},
      {w:'THUMB',emoji:'👍',blank:3},{w:'FINGER',emoji:'☝️',blank:4}
    ]},
    {id:'nature',label:'Thiên nhiên',icon:'🌿',words:[
      {w:'SUN',emoji:'☀️',blank:1},{w:'SKY',emoji:'🌤️',blank:1},
      {w:'SEA',emoji:'🌊',blank:1},{w:'RAIN',emoji:'🌧️',blank:2},
      {w:'WIND',emoji:'🌬️',blank:2},{w:'SNOW',emoji:'❄️',blank:2},
      {w:'TREE',emoji:'🌳',blank:2},{w:'LEAF',emoji:'🍃',blank:2},
      {w:'ROCK',emoji:'🪨',blank:2},{w:'FIRE',emoji:'🔥',blank:2},
      {w:'CLOUD',emoji:'☁️',blank:3},{w:'STORM',emoji:'⛈️',blank:3},
      {w:'RIVER',emoji:'🏞️',blank:3},{w:'BEACH',emoji:'🏖️',blank:3},
      {w:'FLOWER',emoji:'🌸',blank:4},{w:'JUNGLE',emoji:'🌴',blank:4}
    ]}
  ];
  const MWI_STICKERS = ['🌟','🏆','🎉','🦋','🌺','🎈','🐠','🍭','🦊','🌈','🎸','🚀','🐬','🌸','🎪'];
  const MWI_PETS = ['🐣','🐥','🐔','🦅','🦚'];

let lgInited = false;
function initListenGame() {
  const root = document.getElementById('listen-root');
  if (lgInited || !root) return;
  lgInited = true;

  root.innerHTML = `
<style>
#lg *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
#lg{width:100%;min-height:580px;background:#DCEEFF;border-radius:18px;overflow:hidden;position:relative;font-family:'Nunito',sans-serif}
#lg .sky{background:#DCEEFF;padding:14px;min-height:580px;display:flex;flex-direction:column;align-items:center}
#lg .lg-screen{display:none;flex-direction:column;align-items:center;padding:14px;width:100%}
#lg .lg-screen.active{display:flex}
#lg .lg-title{font-size:22px;font-weight:900;color:#0D47A1;text-align:center;margin:8px 0}
#lg .lg-sub{font-size:13px;color:#1565C0;text-align:center;margin-bottom:10px}
#lg .lg-pet{font-size:60px;text-align:center;animation:lgbob 1.8s ease-in-out infinite alternate}
@keyframes lgbob{0%{transform:translateY(0)}100%{transform:translateY(-7px)}}
#lg .topic-btn{background:#fff;border:2.5px solid #90CAF9;border-radius:14px;padding:12px;display:flex;flex-direction:column;align-items:center;gap:5px;cursor:pointer;font-family:inherit;transition:border-color .15s,background .15s;min-width:88px}
#lg .topic-btn:hover{border-color:#1E88E5;background:#E3F2FD}
#lg .topic-btn .ticon{font-size:32px}
#lg .topic-btn .tlabel{font-size:12px;font-weight:700;color:#0D47A1}
#lg .btn-main{background:#1E88E5;border:none;border-radius:99px;padding:12px 30px;color:#fff;font-size:16px;font-weight:800;cursor:pointer;margin:6px;font-family:inherit;transition:transform .1s}
#lg .btn-main:active{transform:scale(.95)}
#lg .btn-green{background:#43A047}
#lg .back-btn{background:#fff;border:none;border-radius:99px;padding:5px 14px;font-size:12px;cursor:pointer;color:#1565C0;font-family:inherit;align-self:flex-start;margin-bottom:6px}
#lg .progress{background:#BBDEFB;border-radius:99px;height:9px;width:100%;margin:6px 0}
#lg .progress-fill{background:#1565C0;border-radius:99px;height:100%;transition:width .4s}
#lg .hp-bar{display:flex;gap:6px;margin:6px 0;justify-content:center}
#lg .hp-heart{font-size:26px;transition:transform .2s,opacity .3s;display:inline-block}
#lg .hp-heart.lost{opacity:.25;transform:scale(.8)}
@keyframes lgheartlost{0%{transform:scale(1.3)}50%{transform:scale(.7) rotate(-15deg)}100%{transform:scale(.8)}}
@keyframes lgshake{0%{transform:translateX(0)}20%{transform:translateX(-6px)}40%{transform:translateX(6px)}60%{transform:translateX(-4px)}80%{transform:translateX(4px)}100%{transform:translateX(0)}}
#lg .balloon{width:82px;height:100px;border-radius:50% 50% 50% 50%/60% 60% 40% 40%;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;border:none;font-size:32px;transition:transform .12s;position:relative;font-family:inherit}
#lg .balloon:active{transform:scale(.9)}
#lg .balloon::after{content:'';width:2px;height:16px;background:#888;display:block;position:absolute;bottom:-16px;left:50%;transform:translateX(-50%)}
#lg .balloons-row{display:flex;gap:16px;justify-content:center;margin:14px 0;flex-wrap:wrap}
#lg .feedback{font-size:20px;font-weight:800;text-align:center;min-height:32px;margin:4px 0}
#lg .feedback.ok{color:#27500A}#lg .feedback.wrong{color:#A32D2D}
#lg .result-box{background:#fff;border-radius:14px;padding:14px;text-align:center;margin:8px 0;width:100%}
#lg .lg-gameover{position:absolute;inset:0;background:rgba(10,20,40,.82);display:flex;flex-direction:column;align-items:center;justify-content:center;border-radius:18px;z-index:50}
#lg .lg-gameover h2{font-size:32px;font-weight:900;color:#fff;margin-bottom:6px}
#lg .lg-gameover p{font-size:15px;color:#bbdefb;margin-bottom:20px}
#lg .badge{display:inline-block;background:#FAC775;border-radius:99px;padding:3px 12px;font-size:12px;font-weight:700;color:#412402;margin:3px}
</style>

<div id="lg">

<div id="lg-home" class="lg-screen active sky" style="min-height:580px;justify-content:center">
  <div class="lg-pet" id="lg-home-pet">🎈</div>
  <div class="lg-title">🎈 Nghe & Chọn</div>
  <div class="lg-sub">Nghe từ tiếng Anh và chọn đúng hình!</div>
  <div style="display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin:10px 0" id="lg-topic-grid"></div>
  <div style="margin-top:6px;font-size:12px;color:#1565C0">Chọn chủ đề để bắt đầu!</div>
  <div style="margin-top:10px;font-size:12px;color:#0D47A1">Điểm: <span id="lg-total-score">0</span> ⭐ &nbsp; Streak: <span id="lg-streak-count">0</span> 🔥</div>
</div>

<div id="lg-challenge" class="lg-screen sky" style="min-height:580px;justify-content:flex-start">
  <button class="back-btn" onclick="lgGoHome()">← Quay lại</button>
  <div style="width:100%;display:flex;align-items:center;gap:8px;margin-bottom:6px">
    <div class="progress" style="flex:1"><div class="progress-fill" id="lg-progress" style="width:0%"></div></div>
    <div style="font-size:12px;color:#0D47A1;font-weight:700" id="lg-counter">1/8</div>
  </div>
  <div class="hp-bar" id="lg-hp-bar"></div>
  <div id="lg-ch-area" style="width:100%;display:flex;flex-direction:column;align-items:center;position:relative"></div>
</div>

<div id="lg-result" class="lg-screen sky" style="min-height:580px;justify-content:center">
  <div class="lg-pet" id="lg-res-pet">🎉</div>
  <div class="lg-title" id="lg-res-title">Xuất sắc!</div>
  <div class="result-box">
    <div style="font-size:13px;color:#1565C0;margin-bottom:6px">Kết quả lượt chơi này</div>
    <div style="font-size:32px;font-weight:900;color:#0D47A1" id="lg-res-score">0</div>
    <div style="font-size:13px;color:#888780">điểm</div>
    <div id="lg-res-badges" style="margin-top:8px"></div>
  </div>
  <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap;justify-content:center">
    <button class="btn-main btn-green" onclick="lgPlayAgain()">Chơi lại</button>
    <button class="btn-main" onclick="lgGoHome()">Về trang chủ</button>
  </div>
</div>

</div>
`;

  // ── State ──
  let ls = {score:0, streak:0, topic:null, words:[], idx:0, hp:3};
  let lgRoundScore = 0;
  try { const d = localStorage.getItem('listenGame1'); if(d) Object.assign(ls, JSON.parse(d)); } catch(e){}
  function lgSave(){ try{ localStorage.setItem('listenGame1', JSON.stringify(ls)); }catch(e){} }

  function lgShow(id){
    document.querySelectorAll('#lg .lg-screen').forEach(s=>s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
  }

  function lgUpdateHome(){
    document.getElementById('lg-total-score').textContent = ls.score;
    document.getElementById('lg-streak-count').textContent = ls.streak;
  }

  function lgGoHome(){ lgUpdateHome(); lgShow('lg-home'); }
  window.lgGoHome = lgGoHome;

  function lgBuildTopics(){
    const g = document.getElementById('lg-topic-grid');
    g.innerHTML = '';
    MWI_TOPICS.forEach(t => {
      const b = document.createElement('button');
      b.className = 'topic-btn';
      b.innerHTML = `<span class="ticon">${t.icon}</span><span class="tlabel">${t.label}</span>`;
      b.onclick = () => lgStartTopic(t);
      g.appendChild(b);
    });
  }

  function lgStartTopic(topic){
    ls.topic = topic;
    const shuffled = [...topic.words].sort(()=>Math.random()-.5);
    ls.words = shuffled.slice(0, Math.min(8, shuffled.length));
    ls.idx = 0; ls.hp = 3;
    lgRoundScore = 0;
    lgShow('lg-challenge');
    lgRenderHp();
    lgUpdateProgress();
    lgRenderChallenge();
  }
  window.lgStartTopic = lgStartTopic;

  function lgRenderHp(){
    const bar = document.getElementById('lg-hp-bar');
    if (!bar) return;
    bar.innerHTML = '';
    for(let i = 0; i < 3; i++){
      const h = document.createElement('span');
      h.className = 'hp-heart' + (i >= ls.hp ? ' lost' : '');
      h.textContent = '❤️';
      h.id = 'lg-heart-' + i;
      bar.appendChild(h);
    }
  }

  function lgLoseHp(){
    if(ls.hp <= 0) return;
    ls.hp--;
    const h = document.getElementById('lg-heart-' + ls.hp);
    if(h){
      h.style.animation = 'lgheartlost .4s ease forwards';
      setTimeout(() => { h.classList.add('lost'); h.style.animation = ''; }, 400);
    }
    const ch = document.getElementById('lg-challenge');
    if(ch){ ch.style.animation = 'lgshake .35s ease'; setTimeout(()=>ch.style.animation='',400); }
    if(ls.hp <= 0) setTimeout(lgGameOver, 500);
  }

  function lgGameOver(){
    const area = document.getElementById('lg-ch-area');
    if(!area) return;
    const ov = document.createElement('div');
    ov.className = 'lg-gameover';
    ov.innerHTML =
      '<div style="font-size:64px;margin-bottom:8px">💔</div>' +
      '<h2>Hết máu rồi!</h2>' +
      '<p>Điểm lần này: <strong style="color:#fff">' + lgRoundScore + '</strong> ⭐</p>' +
      '<div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center">' +
        '<button onclick="lgStartTopic(ls.topic)" style="background:#E53935;border:none;border-radius:99px;padding:11px 24px;color:#fff;font-size:15px;font-weight:800;cursor:pointer;font-family:inherit">🔄 Thử lại</button>' +
        '<button onclick="lgGoHome()" style="background:#fff;border:none;border-radius:99px;padding:11px 24px;color:#333;font-size:15px;font-weight:800;cursor:pointer;font-family:inherit">🏠 Trang chủ</button>' +
      '</div>';
    area.style.position = 'relative';
    area.appendChild(ov);
    ls.streak = 0;
    lgSave();
  }
  window.lgStartTopic = lgStartTopic;

  function lgUpdateProgress(){
    const pct = Math.round(ls.idx / ls.words.length * 100);
    document.getElementById('lg-progress').style.width = pct + '%';
    document.getElementById('lg-counter').textContent = (ls.idx+1) + '/' + ls.words.length;
  }

  function lgRenderChallenge(){
    const area = document.getElementById('lg-ch-area');
    area.innerHTML = '';
    const word = ls.words[ls.idx];
    const others = ls.topic.words.filter(w=>w.w!==word.w).sort(()=>Math.random()-.5).slice(0,3);
    const opts = [...others, word].sort(()=>Math.random()-.5);
    const colors = ['#FFB347','#87CEEB','#98FB98','#DDA0DD'];
    area.innerHTML = `
      <div style="font-size:14px;font-weight:700;color:#0D47A1;margin:8px 0;text-align:center">Nghe từ: <span style="color:#1565C0">"${word.w}"</span> — hình nào đúng?</div>
      <button onclick="lgSpeak('${word.w}')" style="background:#64B5F6;border:none;border-radius:99px;padding:7px 18px;color:#0D47A1;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit;margin-bottom:10px">🔊 Nghe lại</button>
      <div class="balloons-row" id="lg-balloons"></div>
      <div class="feedback" id="lg-fb"></div>`;
    const row = document.getElementById('lg-balloons');
    const allBalloons = [];
    opts.forEach((opt,i) => {
      const b = document.createElement('button');
      b.className = 'balloon';
      b.style.background = colors[i % colors.length];
      b.innerHTML = `<span style="font-size:32px">${opt.emoji}</span>`;
      b.dataset.correct = opt.w === word.w ? '1' : '0';
      row.appendChild(b);
      allBalloons.push(b);
    });
    allBalloons.forEach(b => {
      b.onclick = () => lgPickBalloon(b.dataset.correct === '1', b, word.w, allBalloons);
    });
    setTimeout(() => lgSpeak(word.w), 400);
  }

  function lgPickBalloon(correct, btn, word, allBtns){
    const fb = document.getElementById('lg-fb');
    if(correct){
      allBtns.forEach(b => b.style.pointerEvents = 'none');
      btn.style.transform = 'scale(1.3)'; btn.innerHTML = '💥';
      fb.textContent = '🌟 Xuất sắc!'; fb.className = 'feedback ok';
      ls.score += 10; lgRoundScore += 10; ls.streak++;
      lgSpawnStars(); lgSave();
      setTimeout(() => lgNextWord(), 1200);
    } else {
      const origBg = btn.style.background;
      btn.style.background = '#F09595';
      btn.style.animation = 'lgshake 0.4s ease';
      fb.textContent = '💔 Sai rồi! -1 máu'; fb.className = 'feedback wrong';
      lgSpeak(word);
      lgLoseHp();
      setTimeout(() => {
        btn.style.background = origBg;
        btn.style.animation = '';
        if(fb && fb.className === 'feedback wrong') fb.textContent = '';
      }, 1500);
    }
  }

  function lgNextWord(){
    ls.idx++;
    if(ls.idx >= ls.words.length) lgFinish();
    else { lgUpdateProgress(); lgRenderChallenge(); }
  }

  function lgFinish(){
    if (typeof markStudiedToday === 'function') markStudiedToday('quiz');
    document.getElementById('lg-res-score').textContent = lgRoundScore;
    const pct = Math.round(lgRoundScore / (ls.words.length * 10) * 100);
    document.getElementById('lg-res-title').textContent = pct>=80 ? 'Xuất sắc! 🌟' : pct>=50 ? 'Giỏi lắm! 👍' : 'Cố gắng hơn nhé!';
    const badges = document.getElementById('lg-res-badges');
    badges.innerHTML = '';
    if(ls.streak >= 5) badges.innerHTML += `<span class="badge">🔥 Streak x${ls.streak}</span>`;
    if(pct >= 80) badges.innerHTML += `<span class="badge">🏆 Hoàn hảo</span>`;
    lgShow('lg-result');
  }

  window.lgPlayAgain = function(){ lgStartTopic(ls.topic); };

  // ── TTS ──
  window.lgSpeak = function(word){
    if(!window.speechSynthesis) return;
    const u = new SpeechSynthesisUtterance(word);
    u.lang='en-US'; u.rate=0.85; u.pitch=1.1;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  };

  // ── Stars ──
  function lgSpawnStars(){
    const area = document.getElementById('lg-ch-area');
    for(let i=0;i<5;i++){
      const s = document.createElement('div');
      s.textContent = '⭐';
      s.style.cssText = `position:absolute;font-size:${16+Math.random()*12}px;left:${15+Math.random()*70}%;top:${10+Math.random()*40}%;pointer-events:none;animation:lgstar .9s ease-out forwards;z-index:99`;
      area.appendChild(s);
      setTimeout(()=>s.remove(), 900);
    }
  }
  if(!document.getElementById('lg-kf')){
    const st = document.createElement('style');
    st.id='lg-kf';
    st.textContent='@keyframes lgstar{0%{transform:translateY(0) scale(1);opacity:1}100%{transform:translateY(-55px) scale(0);opacity:0}}';
    document.head.appendChild(st);
  }

  // ── Init ──
  lgBuildTopics();
  lgUpdateHome();
}

let mgInited = false;
function initMemoryGame() {
  const root = document.getElementById('memory-root');
  if (mgInited || !root) return;
  mgInited = true;

  root.innerHTML = `
<style>
#mg *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
#mg{width:100%;min-height:580px;background:#F3E5F5;border-radius:18px;overflow:hidden;position:relative;font-family:'Nunito',sans-serif}
#mg .sky{background:#F3E5F5;padding:14px;min-height:580px;display:flex;flex-direction:column;align-items:center}
#mg .mg-screen{display:none;flex-direction:column;align-items:center;padding:14px;width:100%}
#mg .mg-screen.active{display:flex}
#mg .mg-title{font-size:22px;font-weight:900;color:#4A148C;text-align:center;margin:8px 0}
#mg .mg-sub{font-size:13px;color:#7B1FA2;text-align:center;margin-bottom:10px}
#mg .mg-pet{font-size:60px;text-align:center;animation:mgbob 1.8s ease-in-out infinite alternate}
@keyframes mgbob{0%{transform:translateY(0)}100%{transform:translateY(-7px)}}
#mg .topic-btn{background:#fff;border:2.5px solid #ce93d8;border-radius:14px;padding:12px;display:flex;flex-direction:column;align-items:center;gap:5px;cursor:pointer;font-family:inherit;transition:border-color .15s,background .15s;min-width:88px}
#mg .topic-btn:hover{border-color:#8e24aa;background:#f3e5f5}
#mg .topic-btn .ticon{font-size:32px}
#mg .topic-btn .tlabel{font-size:12px;font-weight:700;color:#4A148C}
#mg .btn-main{background:#8e24aa;border:none;border-radius:99px;padding:12px 30px;color:#fff;font-size:16px;font-weight:800;cursor:pointer;margin:6px;font-family:inherit;transition:transform .1s}
#mg .btn-main:active{transform:scale(.95)}
#mg .btn-green{background:#43A047}
#mg .back-btn{background:#fff;border:none;border-radius:99px;padding:5px 14px;font-size:12px;cursor:pointer;color:#7B1FA2;font-family:inherit;align-self:flex-start;margin-bottom:6px}
#mg .mg-stat-row{display:flex;gap:16px;justify-content:center;margin-bottom:10px;font-size:13px;color:#4A148C;font-weight:700}
#mg .mg-grid{display:grid;gap:8px;width:100%;max-width:420px;margin:0 auto}
#mg .mg-card{aspect-ratio:1;border-radius:12px;background:#8e24aa;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:#fff;cursor:pointer;user-select:none;transition:transform .25s,background .2s;position:relative;text-align:center;padding:4px;overflow:hidden}
#mg .mg-card.flipped{background:#fff;color:#4A148C;border:2px solid #ce93d8;transform:scale(1.03)}
#mg .mg-card.matched{background:#e8f5e9;color:#2e7d32;border:2px solid #a5d6a7;cursor:default;opacity:.85}
#mg .mg-card.wrong{animation:mgshake .35s ease}
@keyframes mgshake{0%{transform:translateX(0)}20%{transform:translateX(-6px)}40%{transform:translateX(6px)}60%{transform:translateX(-4px)}80%{transform:translateX(4px)}100%{transform:translateX(0)}}
#mg .result-box{background:#fff;border-radius:14px;padding:14px;text-align:center;margin:8px 0;width:100%}
#mg .badge{display:inline-block;background:#FAC775;border-radius:99px;padding:3px 12px;font-size:12px;font-weight:700;color:#412402;margin:3px}
</style>

<div id="mg">

<div id="mg-home" class="mg-screen active sky" style="min-height:580px;justify-content:center">
  <div class="mg-pet" id="mg-home-pet">🧩</div>
  <div class="mg-title">🧩 Lật Thẻ Nhớ</div>
  <div class="mg-sub">Lật 2 thẻ để tìm từ và hình ảnh khớp nhau!</div>
  <div style="display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin:10px 0" id="mg-topic-grid"></div>
  <div style="margin-top:6px;font-size:12px;color:#7B1FA2">Chọn chủ đề để bắt đầu!</div>
  <div style="margin-top:10px;font-size:12px;color:#4A148C">Điểm: <span id="mg-total-score">0</span> ⭐ &nbsp; Ván thắng: <span id="mg-win-count">0</span> 🏆</div>
</div>

<div id="mg-game" class="mg-screen sky" style="min-height:580px;justify-content:flex-start">
  <button class="back-btn" onclick="mgGoHome()">← Quay lại</button>
  <div class="mg-stat-row">
    <span>🔄 Lượt lật: <span id="mg-flip-count">0</span></span>
    <span>✅ Đã ghép: <span id="mg-match-count">0</span>/<span id="mg-pair-total">6</span></span>
  </div>
  <div class="mg-grid" id="mg-grid-area"></div>
</div>

<div id="mg-result" class="mg-screen sky" style="min-height:580px;justify-content:center">
  <div class="mg-pet" id="mg-res-pet">🎉</div>
  <div class="mg-title" id="mg-res-title">Xuất sắc!</div>
  <div class="result-box">
    <div style="font-size:13px;color:#7B1FA2;margin-bottom:6px">Kết quả lượt chơi này</div>
    <div style="font-size:32px;font-weight:900;color:#4A148C" id="mg-res-score">0</div>
    <div style="font-size:13px;color:#888780">điểm · <span id="mg-res-flips">0</span> lượt lật</div>
    <div id="mg-res-badges" style="margin-top:8px"></div>
  </div>
  <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap;justify-content:center">
    <button class="btn-main btn-green" onclick="mgPlayAgain()">Chơi lại</button>
    <button class="btn-main" onclick="mgGoHome()">Về trang chủ</button>
  </div>
</div>

</div>
`;

  // ── State ──
  let gs = {score:0, wins:0, topic:null};
  try { const d = localStorage.getItem('memoryGame1'); if(d) Object.assign(gs, JSON.parse(d)); } catch(e){}
  function mgSave(){ try{ localStorage.setItem('memoryGame1', JSON.stringify(gs)); }catch(e){} }

  let cards = [];       // {id, kind:'word'|'emoji', pairId, word, emoji}
  let flipped = [];     // các index đang lật (tối đa 2)
  let matchedCount = 0;
  let flipCount = 0;
  let locked = false;   // khoá thao tác trong lúc kiểm tra cặp

  function mgShow(id){
    document.querySelectorAll('#mg .mg-screen').forEach(s=>s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
  }

  function mgUpdateHome(){
    document.getElementById('mg-total-score').textContent = gs.score;
    document.getElementById('mg-win-count').textContent = gs.wins;
  }

  function mgGoHome(){ mgUpdateHome(); mgShow('mg-home'); }
  window.mgGoHome = mgGoHome;

  function mgBuildTopics(){
    const g = document.getElementById('mg-topic-grid');
    g.innerHTML = '';
    MWI_TOPICS.forEach(t => {
      const b = document.createElement('button');
      b.className = 'topic-btn';
      b.innerHTML = `<span class="ticon">${t.icon}</span><span class="tlabel">${t.label}</span>`;
      b.onclick = () => mgStartTopic(t);
      g.appendChild(b);
    });
  }

  function mgStartTopic(topic){
    gs.topic = topic;
    const pairCount = Math.min(6, topic.words.length);
    const chosen = [...topic.words].sort(()=>Math.random()-.5).slice(0, pairCount);

    cards = [];
    chosen.forEach((w, i) => {
      cards.push({ pairId: i, kind: 'word',  word: w.w, emoji: w.emoji });
      cards.push({ pairId: i, kind: 'emoji', word: w.w, emoji: w.emoji });
    });
    cards.sort(()=>Math.random()-.5);

    flipped = []; matchedCount = 0; flipCount = 0; locked = false;

    document.getElementById('mg-pair-total').textContent = pairCount;
    document.getElementById('mg-match-count').textContent = '0';
    document.getElementById('mg-flip-count').textContent = '0';

    const cols = pairCount <= 6 ? 4 : 4;
    const gridArea = document.getElementById('mg-grid-area');
    gridArea.style.gridTemplateColumns = 'repeat(' + cols + ', 1fr)';
    gridArea.innerHTML = '';
    cards.forEach((c, idx) => {
      const el = document.createElement('div');
      el.className = 'mg-card';
      el.id = 'mg-card-' + idx;
      el.textContent = '❓';
      el.onclick = () => mgFlip(idx);
      gridArea.appendChild(el);
    });

    mgShow('mg-game');
  }
  window.mgStartTopic = mgStartTopic;

  function mgFlip(idx){
    if(locked) return;
    if(flipped.includes(idx)) return;
    const el = document.getElementById('mg-card-' + idx);
    if(!el || el.classList.contains('matched')) return;

    const c = cards[idx];
    el.classList.add('flipped');
    el.textContent = c.kind === 'emoji' ? c.emoji : c.word;
    flipped.push(idx);

    if(c.kind === 'word') mgSpeak(c.word);

    if(flipped.length === 2){
      flipCount++;
      document.getElementById('mg-flip-count').textContent = flipCount;
      locked = true;
      const [i1, i2] = flipped;
      const c1 = cards[i1], c2 = cards[i2];
      const isMatch = c1.pairId === c2.pairId && c1.kind !== c2.kind;
      setTimeout(() => {
        const el1 = document.getElementById('mg-card-' + i1);
        const el2 = document.getElementById('mg-card-' + i2);
        if(isMatch){
          el1.classList.add('matched'); el2.classList.add('matched');
          el1.classList.remove('flipped'); el2.classList.remove('flipped');
          matchedCount++;
          document.getElementById('mg-match-count').textContent = matchedCount;
          mgSpeak(c1.word);
          if(matchedCount >= cards.length/2) setTimeout(() => mgFinish(), 500);
        } else {
          el1.classList.add('wrong'); el2.classList.add('wrong');
          setTimeout(() => {
            el1.classList.remove('flipped','wrong'); el2.classList.remove('flipped','wrong');
            el1.textContent = '❓'; el2.textContent = '❓';
          }, 500);
        }
        flipped = [];
        locked = false;
      }, 700);
    }
  }

  function mgFinish(){
    const pairTotal = cards.length / 2;
    // Điểm: càng ít lượt lật thừa càng cao, tối thiểu 30đ, tối đa 100đ
    const perfect = pairTotal; // số lượt lật tối thiểu có thể (mỗi cặp lật đúng 1 lần)
    const extra = Math.max(0, flipCount - perfect);
    const score = Math.max(30, 100 - extra * 8);

    gs.score += score; gs.wins++; mgSave();
    if (typeof markStudiedToday === 'function') markStudiedToday('quiz');

    document.getElementById('mg-res-score').textContent = score;
    document.getElementById('mg-res-flips').textContent = flipCount;
    document.getElementById('mg-res-title').textContent = score>=80 ? 'Xuất sắc! 🌟' : score>=50 ? 'Giỏi lắm! 👍' : 'Hoàn thành!';
    const badges = document.getElementById('mg-res-badges');
    badges.innerHTML = '';
    if(flipCount === perfect) badges.innerHTML += `<span class="badge">🏆 Hoàn hảo - Không sai lượt nào!</span>`;
    else if(score >= 80) badges.innerHTML += `<span class="badge">🌟 Trí nhớ tốt</span>`;
    mgShow('mg-result');
  }

  window.mgPlayAgain = function(){ mgStartTopic(gs.topic); };

  // ── TTS ──
  window.mgSpeak = function(word){
    if(!window.speechSynthesis) return;
    const u = new SpeechSynthesisUtterance(word);
    u.lang='en-US'; u.rate=0.85; u.pitch=1.1;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  };

  // ── Init ──
  mgBuildTopics();
  mgUpdateHome();
}

function initMiniGame() {
  const root = document.getElementById('mwi-root');
  if (mwiInited || !root) return;
  mwiInited = true;

  root.innerHTML = `
<style>
#mwi *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
#mwi{width:100%;min-height:580px;background:#B0E2FF;border-radius:18px;overflow:hidden;position:relative;font-family:'Nunito',sans-serif}
#mwi .sky{background:#B0E2FF;padding:14px;min-height:580px;display:flex;flex-direction:column;align-items:center}
#mwi .cloud{background:#fff;border-radius:50px;padding:8px 18px;font-size:12px;color:#5F5E5A;position:absolute;top:12px}
#mwi .cloud.l{left:10px}#mwi .cloud.r{right:10px}
#mwi .island-title{font-size:22px;font-weight:900;color:#26215C;text-align:center;margin:8px 0}
#mwi .sub{font-size:13px;color:#534AB7;text-align:center;margin-bottom:10px}
#mwi .pet{font-size:60px;text-align:center;animation:mwibob 1.8s ease-in-out infinite alternate}
@keyframes mwibob{0%{transform:translateY(0)}100%{transform:translateY(-7px)}}
#mwi .topic-btn{background:#fff;border:2.5px solid #AFA9EC;border-radius:14px;padding:12px;display:flex;flex-direction:column;align-items:center;gap:5px;cursor:pointer;font-family:inherit;transition:border-color .15s,background .15s;min-width:88px}
#mwi .topic-btn:hover{border-color:#7F77DD;background:#EEEDFE}
#mwi .topic-btn .ticon{font-size:32px}
#mwi .topic-btn .tlabel{font-size:12px;font-weight:700;color:#3C3489}
#mwi .btn-main{background:#7F77DD;border:none;border-radius:99px;padding:12px 30px;color:#EEEDFE;font-size:16px;font-weight:800;cursor:pointer;margin:6px;font-family:inherit;transition:transform .1s}
#mwi .btn-main:active{transform:scale(.95)}
#mwi .btn-green{background:#1D9E75;color:#E1F5EE}
#mwi .mwi-screen{display:none;flex-direction:column;align-items:center;padding:14px;width:100%}
#mwi .mwi-screen.active{display:flex}
#mwi .progress{background:#9FE1CB;border-radius:99px;height:9px;width:100%;margin:6px 0}
#mwi .progress-fill{background:#0F6E56;border-radius:99px;height:100%;transition:width .4s}
#mwi .tab-row{display:flex;gap:6px;margin:8px 0;flex-wrap:wrap;justify-content:center}
#mwi .tab-btn{background:#E1F5EE;border:none;border-radius:99px;padding:7px 15px;font-size:12px;font-weight:700;color:#085041;cursor:pointer;font-family:inherit}
#mwi .tab-btn.active{background:#1D9E75;color:#E1F5EE}
#mwi .word-display{background:#fff;border-radius:14px;padding:10px 24px;font-size:28px;font-weight:900;color:#3C3489;letter-spacing:5px;text-align:center;margin:8px 0}
#mwi .balloon{width:82px;height:100px;border-radius:50% 50% 50% 50%/60% 60% 40% 40%;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;border:none;font-size:32px;transition:transform .12s;position:relative;font-family:inherit}
#mwi .balloon:active{transform:scale(.9)}
#mwi .balloon::after{content:'';width:2px;height:16px;background:#888;display:block;position:absolute;bottom:-16px;left:50%;transform:translateX(-50%)}
#mwi .balloons-row{display:flex;gap:16px;justify-content:center;margin:14px 0;flex-wrap:wrap}
#mwi .feedback{font-size:20px;font-weight:800;text-align:center;min-height:32px;margin:4px 0}
#mwi .feedback.ok{color:#27500A}#mwi .feedback.wrong{color:#A32D2D}
#mwi .drop-zone{width:56px;height:56px;border:3px dashed #7F77DD;border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:24px;font-weight:900;color:#7F77DD;vertical-align:middle;margin:0 3px;background:#EEEDFE}
#mwi .drop-zone.filled{border-color:#1D9E75;background:#E1F5EE;color:#27500A}
#mwi .letter-piece{background:#AFA9EC;border-radius:10px;width:56px;height:56px;display:inline-flex;align-items:center;justify-content:center;font-size:24px;font-weight:900;color:#26215C;cursor:pointer;border:none;font-family:inherit;transition:transform .1s}
#mwi .letter-piece:active{transform:scale(1.1)}
#mwi .word-pic{font-size:72px;text-align:center;animation:mwibob 2s ease-in-out infinite alternate}
#mwi .mic-btn{background:#D4537E;border:none;border-radius:50%;width:66px;height:66px;font-size:28px;cursor:pointer;color:#fff;transition:transform .15s,background .2s;font-family:inherit}
#mwi .mic-btn:active{transform:scale(.92)}
#mwi .mic-btn.recording{background:#993556;animation:mwipulse 0.6s ease-in-out infinite alternate}
@keyframes mwipulse{0%{transform:scale(1)}100%{transform:scale(1.12)}}
@keyframes mwishake{0%{transform:translateX(0)}20%{transform:translateX(-6px)}40%{transform:translateX(6px)}60%{transform:translateX(-4px)}80%{transform:translateX(4px)}100%{transform:translateX(0)}}
#mwi .sticker-book{display:flex;flex-wrap:wrap;gap:8px;background:#EEEDFE;border-radius:14px;padding:12px;min-height:70px;justify-content:center;width:100%;margin:8px 0}
#mwi .result-box{background:#fff;border-radius:14px;padding:14px;text-align:center;margin:8px 0;width:100%}
#mwi .hp-bar{display:flex;gap:6px;margin:6px 0;justify-content:center}
#mwi .hp-heart{font-size:26px;transition:transform .2s,opacity .3s;display:inline-block}
#mwi .hp-heart.lost{opacity:.25;transform:scale(.8)}
@keyframes mwiheartlost{0%{transform:scale(1.3)}50%{transform:scale(.7) rotate(-15deg)}100%{transform:scale(.8)}}
#mwi .mwi-gameover{position:absolute;inset:0;background:rgba(30,10,10,.82);display:flex;flex-direction:column;align-items:center;justify-content:center;border-radius:18px;z-index:50;animation:cfadein .25s ease}
#mwi .mwi-gameover h2{font-size:32px;font-weight:900;color:#fff;margin-bottom:6px}
#mwi .mwi-gameover p{font-size:15px;color:#ffb3b3;margin-bottom:20px}
#mwi .badge{display:inline-block;background:#FAC775;border-radius:99px;padding:3px 12px;font-size:12px;font-weight:700;color:#412402;margin:3px}
#mwi .back-btn{background:#fff;border:none;border-radius:99px;padding:5px 14px;font-size:12px;cursor:pointer;color:#534AB7;font-family:inherit;align-self:flex-start;margin-bottom:6px}
</style>

<div id="mwi">

<!-- HOME -->
<div id="mwi-home" class="mwi-screen active sky" style="min-height:580px;justify-content:center">
  <div class="cloud l">2 thử thách</div>
  <div class="cloud r">5 chủ đề</div>
  <div style="margin-top:36px" class="pet" id="mwi-home-pet">🐣</div>
  <div class="island-title">🏝️ Magic Word Island</div>
  <div class="sub">Đảo Từ Vựng Kỳ Diệu</div>
  <div style="display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin:10px 0" id="mwi-topic-grid"></div>
  <div style="margin-top:6px;font-size:12px;color:#534AB7">Chọn chủ đề để bắt đầu!</div>
  <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;justify-content:center">
    <button class="btn-main" style="font-size:13px;padding:9px 20px" onclick="mwiOpenStickers()">📔 Sổ sticker</button>
    <button class="btn-main" style="font-size:13px;padding:9px 20px;background:#D85A30;color:#FAECE7" onclick="mwiOpenParent()">🔒 Phụ huynh</button>
  </div>
  <div style="margin-top:10px;font-size:12px;color:#085041">Điểm: <span id="mwi-total-score">0</span> ⭐ &nbsp; Streak: <span id="mwi-streak-count">0</span> 🔥</div>
</div>

<!-- CHALLENGE -->
<div id="mwi-challenge" class="mwi-screen sky" style="min-height:580px;justify-content:flex-start">
  <button class="back-btn" onclick="mwiGoHome()">← Quay lại</button>
  <div style="width:100%;display:flex;align-items:center;gap:8px;margin-bottom:6px">
    <div class="progress" style="flex:1"><div class="progress-fill" id="mwi-ch-progress" style="width:0%"></div></div>
    <div style="font-size:12px;color:#26215C;font-weight:700" id="mwi-ch-counter">1/5</div>
  </div>
  <div class="hp-bar" id="mwi-hp-bar"></div>
  <div class="tab-row" id="mwi-ch-tabs">
    <button class="tab-btn active" id="mwi-tab0" onclick="mwiSwitchTab(0)">1. Ghép chữ</button>
    <button class="tab-btn" id="mwi-tab1" onclick="mwiSwitchTab(1)">2. Nói cùng thú</button>
  </div>
  <div id="mwi-ch-area" style="width:100%;display:flex;flex-direction:column;align-items:center;position:relative"></div>
</div>

<!-- RESULT -->
<div id="mwi-result" class="mwi-screen sky" style="min-height:580px;justify-content:center">
  <div class="pet" id="mwi-res-pet">🐣</div>
  <div class="island-title" id="mwi-res-title">Xuất sắc!</div>
  <div class="result-box">
    <div style="font-size:13px;color:#534AB7;margin-bottom:6px">Kết quả hôm nay</div>
    <div style="font-size:32px;font-weight:900;color:#26215C" id="mwi-res-score">0</div>
    <div style="font-size:13px;color:#888780">điểm</div>
    <div id="mwi-res-badges" style="margin-top:8px"></div>
  </div>
  <div style="font-size:13px;color:#27500A;margin:6px 0">Sticker mới nhận:</div>
  <div style="font-size:44px" id="mwi-res-sticker"></div>
  <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap;justify-content:center">
    <button class="btn-main btn-green" onclick="mwiPlayAgain()">Chơi lại</button>
    <button class="btn-main" onclick="mwiGoHome()">Về trang chủ</button>
  </div>
</div>

<!-- STICKERS -->
<div id="mwi-stickers" class="mwi-screen sky" style="min-height:580px;justify-content:flex-start">
  <button class="back-btn" onclick="mwiGoHome()">← Quay lại</button>
  <div class="island-title">📔 Sổ Sticker Của Bé</div>
  <div class="sticker-book" id="mwi-sticker-book"></div>
  <div style="font-size:12px;color:#534AB7;margin-top:6px">Nhấn sticker để phóng to!</div>
  <div style="font-size:56px;text-align:center;margin-top:8px;min-height:60px;transition:font-size .2s" id="mwi-sticker-big"></div>
</div>

<!-- PARENT -->
<div id="mwi-parent" class="mwi-screen sky" style="min-height:580px;justify-content:flex-start">
  <button class="back-btn" onclick="mwiGoHome()">← Quay lại</button>
  <div class="island-title">🔒 Góc Phụ Huynh</div>
  <div class="result-box" style="background:#EEEDFE">
    <div style="font-size:13px;color:#534AB7;margin-bottom:10px">Xác nhận bằng phép tính:</div>
    <div style="font-size:22px;font-weight:900;color:#26215C;margin-bottom:10px" id="mwi-parent-q"></div>
    <input id="mwi-parent-ans" type="number" placeholder="Đáp án..." style="padding:9px;border-radius:10px;border:2px solid #AFA9EC;font-size:17px;width:120px;text-align:center;font-family:inherit">
    <div style="margin-top:8px"><button class="btn-main" style="font-size:14px;padding:9px 22px" onclick="mwiCheckParent()">Xác nhận</button></div>
    <div id="mwi-parent-msg" style="font-size:13px;margin-top:6px;color:#A32D2D"></div>
  </div>
  <div id="mwi-parent-panel" style="display:none;width:100%">
    <div class="result-box" style="margin-top:10px">
      <div style="font-size:14px;font-weight:700;color:#26215C;margin-bottom:8px">Báo cáo tiến độ</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
        <div style="background:#E1F5EE;border-radius:12px;padding:10px;text-align:center">
          <div style="font-size:10px;color:#085041">Tổng điểm</div>
          <div style="font-size:24px;font-weight:900;color:#0F6E56" id="mwi-p-score">0</div>
        </div>
        <div style="background:#EEEDFE;border-radius:12px;padding:10px;text-align:center">
          <div style="font-size:10px;color:#3C3489">Sticker</div>
          <div style="font-size:24px;font-weight:900;color:#534AB7" id="mwi-p-stickers">0</div>
        </div>
        <div style="background:#FAEEDA;border-radius:12px;padding:10px;text-align:center">
          <div style="font-size:10px;color:#633806">Streak</div>
          <div style="font-size:24px;font-weight:900;color:#854F0B" id="mwi-p-streak">0</div>
        </div>
        <div style="background:#FAECE7;border-radius:12px;padding:10px;text-align:center">
          <div style="font-size:10px;color:#712B13">Buổi chơi</div>
          <div style="font-size:24px;font-weight:900;color:#993C1D" id="mwi-p-sessions">0</div>
        </div>
      </div>
    </div>
    <div class="result-box" style="margin-top:6px">
      <div style="font-size:12px;font-weight:700;color:#26215C;margin-bottom:6px">Giới hạn thời gian</div>
      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
        <label style="font-size:12px;color:#534AB7">Giới hạn (phút):</label>
        <input type="range" min="5" max="60" value="20" step="5" id="mwi-time-slider" oninput="mwiUpdateTimeLimit(this.value)" style="flex:1;min-width:100px">
        <span id="mwi-time-val" style="font-size:13px;font-weight:700;color:#26215C">20</span>
      </div>
      <button class="btn-main btn-green" style="font-size:12px;padding:8px 16px;margin-top:8px" onclick="mwiResetTimeGuard()">🔓 Mở khóa thêm giờ chơi hôm nay</button>
    </div>
  </div>
</div>

</div>
`;

  // ── State ──
  let ms = {score:0,streak:0,stickers:[],sessions:0,petLevel:0,topic:null,words:[],idx:0,hp:3,tab:0,pA:0,pB:0,timeLimit:20};
  let roundScore = 0; // điểm của lượt chơi hiện tại (khác với ms.score là điểm cộng dồn cả đời)
  try { const d = localStorage.getItem('mwi2'); if(d) Object.assign(ms, JSON.parse(d)); } catch(e){}
  function mwiSave(){ try{ localStorage.setItem('mwi2', JSON.stringify(ms)); }catch(e){} }

  // ── Screens ──
  function mwiShow(id){
    document.querySelectorAll('#mwi .mwi-screen').forEach(s=>s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
  }

  function mwiGoHome(){
    mwiUpdateHome();
    mwiShow('mwi-home');
  }
  window.mwiGoHome = mwiGoHome;

  function mwiUpdateHome(){
    document.getElementById('mwi-total-score').textContent = ms.score;
    document.getElementById('mwi-streak-count').textContent = ms.streak;
    document.getElementById('mwi-home-pet').textContent = MWI_PETS[Math.min(ms.petLevel, MWI_PETS.length-1)];
  }

  function mwiBuildTopics(){
    const g = document.getElementById('mwi-topic-grid');
    g.innerHTML = '';
    MWI_TOPICS.forEach(t => {
      const b = document.createElement('button');
      b.className = 'topic-btn';
      b.innerHTML = `<span class="ticon">${t.icon}</span><span class="tlabel">${t.label}</span>`;
      b.onclick = () => mwiStartTopic(t);
      g.appendChild(b);
    });
  }

  // ── Topic / round ──
  function mwiStartTopic(topic){
    if (mwiTimeIsUp) {
      mwiShow('mwi-home');
      alert('Đã hết giờ chơi hôm nay! Nhờ bố mẹ vào Góc Phụ Huynh để mở khóa thêm nhé.');
      return;
    }
    ms.topic = topic;
    // Lấy ngẫu nhiên 8 từ mỗi vòng chơi để không bị quá dài
    const shuffled = [...topic.words].sort(()=>Math.random()-.5);
    ms.words = shuffled.slice(0, Math.min(8, shuffled.length));
    ms.idx = 0; ms.hp = 3; ms.tab = 0;
    roundScore = 0;
    mwiShow('mwi-challenge');
    mwiRenderHp();
    mwiSwitchTab(0);
    mwiUpdateProgress();
  }
  window.mwiStartTopic = mwiStartTopic;

  function mwiRenderHp(){
    const bar = document.getElementById('mwi-hp-bar');
    if (!bar) return;
    bar.innerHTML = '';
    for(let i = 0; i < 3; i++){
      const h = document.createElement('span');
      h.className = 'hp-heart' + (i >= ms.hp ? ' lost' : '');
      h.textContent = '❤️';
      h.id = 'mwi-heart-' + i;
      bar.appendChild(h);
    }
  }

  function mwiLoseHp(){
    if(ms.hp <= 0) return;
    ms.hp--;
    // Animate trái tim bị mất
    const h = document.getElementById('mwi-heart-' + ms.hp);
    if(h){
      h.style.animation = 'mwiheartlost .4s ease forwards';
      setTimeout(() => { h.classList.add('lost'); h.style.animation = ''; }, 400);
    }
    // Rung màn hình challenge
    const ch = document.getElementById('mwi-challenge');
    if(ch){ ch.style.animation = 'mwishake .35s ease'; setTimeout(()=>ch.style.animation='',400); }
    if(ms.hp <= 0) setTimeout(mwiGameOver, 500);
  }

  function mwiGameOver(){
    const area = document.getElementById('mwi-ch-area');
    if(!area) return;
    const ov = document.createElement('div');
    ov.className = 'mwi-gameover';
    const score = roundScore;
    const topic = ms.topic;
    ov.innerHTML =
      '<div style="font-size:64px;margin-bottom:8px">💔</div>' +
      '<h2>Hết máu rồi!</h2>' +
      '<p>Điểm lần này: <strong style="color:#fff">' + score + '</strong> ⭐</p>' +
      '<div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center">' +
        '<button onclick="mwiStartTopic(ms.topic)" style="background:#E8584D;border:none;border-radius:99px;padding:11px 24px;color:#fff;font-size:15px;font-weight:800;cursor:pointer;font-family:inherit">🔄 Thử lại</button>' +
        '<button onclick="mwiGoHome()" style="background:#fff;border:none;border-radius:99px;padding:11px 24px;color:#333;font-size:15px;font-weight:800;cursor:pointer;font-family:inherit">🏠 Trang chủ</button>' +
      '</div>';
    area.style.position = 'relative';
    area.appendChild(ov);
    ms.streak = 0;
    mwiSave();
  }

  function mwiUpdateProgress(){
    const pct = Math.round(ms.idx / ms.words.length * 100);
    document.getElementById('mwi-ch-progress').style.width = pct + '%';
    document.getElementById('mwi-ch-counter').textContent = (ms.idx+1) + '/' + ms.words.length;
  }

  function mwiSwitchTab(n){
    ms.tab = n;
    [0,1].forEach(i => document.getElementById('mwi-tab'+i).classList.toggle('active', i===n));
    mwiRenderChallenge();
  }
  window.mwiSwitchTab = mwiSwitchTab;

  function mwiRenderChallenge(){
    const area = document.getElementById('mwi-ch-area');
    area.innerHTML = '';
    if(ms.tab === 0) mwiRenderSpell(area);
    else mwiRenderSpeak(area);
  }

  // ── TAB 2: Ghép chữ ──
  function mwiRenderSpell(area){
    const word = ms.words[ms.idx];
    const letters = [...word.w];
    const blankIdx = word.blank < letters.length ? word.blank : 0;
    const missing = letters[blankIdx];
    const decoys = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').filter(c=>c!==missing).sort(()=>Math.random()-.5).slice(0,3);
    const choices = [missing, ...decoys].sort(()=>Math.random()-.5);
    const wordHtml = letters.map((l,i) =>
      i === blankIdx
        ? `<span class="drop-zone" id="mwi-dz">_</span>`
        : `<span style="font-size:28px;font-weight:900;color:#3C3489;margin:0 2px">${l}</span>`
    ).join('');
    area.innerHTML = `
      <div class="word-pic">${word.emoji}</div>
      <div style="margin:8px 0;text-align:center">${wordHtml}</div>
      <div style="font-size:12px;color:#534AB7;margin:6px 0">Chọn chữ đúng để điền vào ô trống:</div>
      <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap" id="mwi-letter-row"></div>
      <div class="feedback" id="mwi-fb2"></div>`;
    const row = document.getElementById('mwi-letter-row');
    choices.forEach(c => {
      const b = document.createElement('button');
      b.className = 'letter-piece';
      b.textContent = c;
      b.onclick = () => mwiDropLetter(c, missing, word.w, b);
      row.appendChild(b);
    });
  }

  function mwiDropLetter(chosen, correct, word, btn){
    const dz = document.getElementById('mwi-dz');
    const fb = document.getElementById('mwi-fb2');
    if(chosen === correct){
      document.querySelectorAll('#mwi .letter-piece').forEach(b => b.style.pointerEvents = 'none');
      dz.textContent = chosen; dz.className = 'drop-zone filled';
      fb.textContent = '🌟 Đúng rồi!'; fb.className = 'feedback ok';
      mwiSpeak(word); ms.score += 10; roundScore += 10; ms.streak++;
      mwiSpawnStars(); mwiSave();
      setTimeout(() => mwiNextWord(), 1300);
    } else {
      btn.style.background = '#F09595';
      btn.style.animation = 'mwishake 0.4s ease';
      fb.textContent = '💔 Sai rồi! -1 máu'; fb.className = 'feedback wrong';
      mwiLoseHp();
      setTimeout(() => {
        btn.style.background = '#AFA9EC';
        btn.style.animation = '';
        if(fb && fb.className === 'feedback wrong') fb.textContent = '';
      }, 1200);
    }
  }

  // ── TAB 3: Nói cùng thú ──
  function mwiRenderSpeak(area){
    const word = ms.words[ms.idx];
    area.innerHTML = `
      <div style="font-size:13px;font-weight:700;color:#26215C;margin:6px 0;text-align:center">Thú cưng đói rồi! Đọc to để cho ăn 🍖</div>
      <div style="font-size:56px;text-align:center;margin:4px 0" id="mwi-speak-pet">${MWI_PETS[Math.min(ms.petLevel, MWI_PETS.length-1)]}</div>
      <div class="word-display">${word.w} ${word.emoji}</div>
      <button class="mic-btn" id="mwi-mic-btn" onclick="mwiDoSpeak('${word.w}')">🎙️</button>
      <div style="font-size:12px;color:#534AB7;margin-top:6px" id="mwi-speak-hint">Nhấn mic và đọc to!</div>
      <div class="feedback" id="mwi-fb3"></div>
      <button style="background:transparent;border:none;color:#534AB7;font-size:12px;cursor:pointer;font-family:inherit;margin-top:8px;text-decoration:underline" onclick="mwiSkipSpeak()">Bỏ qua</button>`;
  }
  window.mwiDoSpeak = function(word){
    const btn = document.getElementById('mwi-mic-btn');
    const hint = document.getElementById('mwi-speak-hint');
    const fb = document.getElementById('mwi-fb3');
    if(!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)){
      hint.textContent = 'Thiết bị không hỗ trợ mic. Dùng nút Bỏ qua!'; return;
    }
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const rec = new SR();
    rec.lang='en-US'; rec.interimResults=false; rec.maxAlternatives=3;
    btn.classList.add('recording'); hint.textContent = 'Đang nghe... Đọc to lên!';
    rec.onresult = (e) => {
      btn.classList.remove('recording');
      const results = [...e.results[0]].map(r => r.transcript.trim().toUpperCase());
      const ok = results.some(r => r.includes(word) || mwiSimilarity(r,word) > 0.5);
      if(ok){
        fb.textContent = '🌟 Phát âm hay lắm!'; fb.className = 'feedback ok';
        document.getElementById('mwi-speak-pet').textContent = '🎉';
        ms.score += 15; roundScore += 15; ms.streak++; mwiSpawnStars(); mwiSave();
        setTimeout(() => mwiNextWord(), 1400);
      } else {
        fb.textContent = 'Thử lại! Nói "' + word + '"'; fb.className = 'feedback wrong';
        hint.textContent = 'Nhấn mic và đọc lại!';
      }
    };
    rec.onerror = () => { btn.classList.remove('recording'); hint.textContent = 'Lỗi mic. Thử lại!'; };
    rec.start();
  };
  window.mwiSkipSpeak = function(){ ms.score += 5; roundScore += 5; mwiNextWord(); };

  function mwiSimilarity(a,b){
    const s = new Set(a.split(''));
    return [...b].filter(c=>s.has(c)).length / Math.max(a.length,b.length);
  }

  // ── Next word / finish ──
  function mwiNextWord(){
    ms.idx++;
    if(ms.idx >= ms.words.length) mwiFinish();
    else { mwiUpdateProgress(); mwiRenderChallenge(); }
  }

  function mwiFinish(){
    ms.sessions++;
    const sticker = MWI_STICKERS[Math.floor(Math.random()*MWI_STICKERS.length)];
    ms.stickers.push(sticker); mwiSave();
    if (typeof markStudiedToday === 'function') markStudiedToday('quiz');
    document.getElementById('mwi-res-pet').textContent = MWI_PETS[Math.min(ms.petLevel, MWI_PETS.length-1)];
    document.getElementById('mwi-res-score').textContent = roundScore;
    document.getElementById('mwi-res-sticker').textContent = sticker;
    const pct = Math.round(roundScore / (ms.words.length * 12) * 100);
    document.getElementById('mwi-res-title').textContent = pct>=80 ? 'Xuất sắc! 🌟' : pct>=50 ? 'Giỏi lắm! 👍' : 'Cố gắng hơn nhé!';
    const badges = document.getElementById('mwi-res-badges');
    badges.innerHTML = '';
    if(ms.streak >= 5) badges.innerHTML += `<span class="badge">🔥 Streak x${ms.streak}</span>`;
    if(pct >= 80) badges.innerHTML += `<span class="badge">🏆 Hoàn hảo</span>`;
    mwiShow('mwi-result');
  }

  window.mwiPlayAgain = function(){ mwiStartTopic(ms.topic); };

  // ── Stickers ──
  window.mwiOpenStickers = function(){
    mwiShow('mwi-stickers');
    const book = document.getElementById('mwi-sticker-book');
    book.innerHTML = ms.stickers.length === 0
      ? '<div style="font-size:13px;color:#888780;text-align:center;width:100%;padding:16px">Chưa có sticker. Hãy chơi để nhận!</div>'
      : ms.stickers.map(s=>`<span style="font-size:34px;cursor:pointer;transition:transform .15s" onmouseenter="this.style.transform='scale(1.3)'" onmouseleave="this.style.transform=''" onclick="document.getElementById('mwi-sticker-big').textContent='${s}'">${s}</span>`).join('');
    document.getElementById('mwi-sticker-big').textContent = '';
  };

  window.mwiUpdateTimeLimit = function(val){
    ms.timeLimit = parseInt(val, 10);
    document.getElementById('mwi-time-val').textContent = val;
    mwiSave();
  };

  // ── Parent ──
  window.mwiOpenParent = function(){
    const a = Math.floor(Math.random()*10)+1, b = Math.floor(Math.random()*10)+1;
    ms.pA=a; ms.pB=b;
    document.getElementById('mwi-parent-q').textContent = a + ' + ' + b + ' = ?';
    document.getElementById('mwi-parent-ans').value = '';
    document.getElementById('mwi-parent-msg').textContent = '';
    document.getElementById('mwi-parent-panel').style.display = 'none';
    mwiShow('mwi-parent');
  };
  window.mwiCheckParent = function(){
    const ans = parseInt(document.getElementById('mwi-parent-ans').value);
    const msg = document.getElementById('mwi-parent-msg');
    if(ans === ms.pA + ms.pB){
      document.getElementById('mwi-parent-panel').style.display = 'block';
      document.getElementById('mwi-p-score').textContent = ms.score;
      document.getElementById('mwi-p-stickers').textContent = ms.stickers.length;
      document.getElementById('mwi-p-streak').textContent = ms.streak;
      document.getElementById('mwi-p-sessions').textContent = ms.sessions;
      const slider = document.getElementById('mwi-time-slider');
      if (slider) slider.value = ms.timeLimit;
      const val = document.getElementById('mwi-time-val');
      if (val) val.textContent = ms.timeLimit;
      msg.textContent = '✓ Xác nhận thành công'; msg.style.color = '#27500A';
    } else {
      msg.textContent = 'Sai rồi! Hãy thử lại.'; msg.style.color = '#A32D2D';
    }
  };

  // ── TTS ──
  window.mwiSpeak = function(word){
    if(!window.speechSynthesis) return;
    const u = new SpeechSynthesisUtterance(word);
    u.lang='en-US'; u.rate=0.85; u.pitch=1.1;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  };

  // ── Stars ──
  function mwiSpawnStars(){
    const area = document.getElementById('mwi-ch-area');
    for(let i=0;i<5;i++){
      const s = document.createElement('div');
      s.textContent = '⭐';
      s.style.cssText = `position:absolute;font-size:${16+Math.random()*12}px;left:${15+Math.random()*70}%;top:${10+Math.random()*40}%;pointer-events:none;animation:mwistar .9s ease-out forwards;z-index:99`;
      area.appendChild(s);
      setTimeout(()=>s.remove(), 900);
    }
  }

  // add keyframe once
  if(!document.getElementById('mwi-kf')){
    const st = document.createElement('style');
    st.id='mwi-kf';
    st.textContent='@keyframes mwistar{0%{transform:translateY(0) scale(1);opacity:1}100%{transform:translateY(-55px) scale(0);opacity:0}}';
    document.head.appendChild(st);
  }

  // ── Screen time guard ──
  let mwiTimeIsUp = false;
  let mwiStart = Date.now();
  let mwiTimer = null;
  function mwiStartTimeGuard(){
    if (mwiTimer) clearInterval(mwiTimer);
    mwiTimer = setInterval(()=>{
      const mins = (Date.now()-mwiStart)/60000;
      if(mins >= ms.timeLimit){
        mwiTimeIsUp = true;
        const challengeScreen = document.getElementById('mwi-challenge');
        const area = document.getElementById('mwi-ch-area');
        if(area && challengeScreen && challengeScreen.classList.contains('active')){
          area.innerHTML=`<div style="text-align:center;padding:20px;background:#EEEDFE;border-radius:14px;margin:10px">
            <div style="font-size:44px">😴</div>
            <div style="font-size:16px;font-weight:700;color:#26215C;margin:8px 0">Nghỉ mắt một chút nhé!</div>
            <div style="font-size:13px;color:#534AB7">Bố mẹ vào Góc Phụ Huynh để mở khóa</div>
          </div>`;
        }
        clearInterval(mwiTimer);
      }
    }, 15000);
  }
  mwiStartTimeGuard();

  window.mwiResetTimeGuard = function(){
    mwiTimeIsUp = false;
    mwiStart = Date.now();
    mwiStartTimeGuard();
  };

  // ── Init ──
  mwiBuildTopics();
  mwiUpdateHome();
}
