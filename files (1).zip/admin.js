async function loadAdmin() {
  const { data: users }     = await sb.from('profiles').select('*').order('created_at', { ascending: false });
  // Tách query classes không join profiles (tránh lỗi relationship)
  const { data: rawClasses } = await sb.from('classes').select('*').order('created_at', { ascending: false });
  _admAllUsers = users || [];

  // Map tên giáo viên cho từng lớp bằng query profiles riêng
  const teacherIds = [...new Set((rawClasses || []).map(c => c.teacher_id).filter(Boolean))];
  let teacherMap = {};
  if (teacherIds.length > 0) {
    const { data: tProfs } = await sb.from('profiles').select('id,full_name').in('id', teacherIds);
    (tProfs || []).forEach(p => { teacherMap[p.id] = p; });
  }
  const classes = (rawClasses || []).map(c => ({
    ...c,
    teacherName: teacherMap[c.teacher_id]?.full_name || '—'
  }));

  // Tổng từ vựng = tổng số từ trong tất cả bài học (LESSONS)
  const students = _admAllUsers.filter(u => u.role === 'student');
  const teachers = _admAllUsers.filter(u => u.role === 'teacher');

  document.getElementById('adm-users').textContent     = _admAllUsers.length;
  document.getElementById('adm-students').textContent  = students.length;
  document.getElementById('adm-teachers').textContent  = teachers.length;
  document.getElementById('adm-classes').textContent   = classes.length;

  admRenderUsers(_admAllUsers);

  // Classes table
  window._admClasses = classes; // lưu để modal dùng
  const ct = document.getElementById('adm-classes-table');
  if (ct) ct.innerHTML = classes?.length ? `
    <table class="admin-table">
      <thead><tr><th>Tên lớp</th><th>Giáo viên</th><th>Mã lớp</th><th>Học sinh</th><th>Ngày tạo</th><th>Thao tác</th></tr></thead>
      <tbody>${classes.map(c => `
        <tr>
          <td><strong>${c.name}</strong></td>
          <td>${c.teacherName}</td>
          <td><code style="background:#fff3c4;padding:3px 8px;border-radius:8px;font-weight:700">${c.class_code}</code></td>
          <td id="adm-member-count-${c.id}">...</td>
          <td>${new Date(c.created_at).toLocaleDateString('vi-VN')}</td>
          <td style="display:flex;gap:6px">
            <button onclick="openAdminClassDetail('${c.id}')" style="background:#ede9fe;color:#7c3aed;border:2px solid #c4b5fd;border-radius:99px;padding:5px 12px;font-size:12px;font-weight:700;cursor:pointer;font-family:inherit">✏️ Chi tiết</button>
            <button onclick="admDeleteClass('${c.id}')" style="background:#ffebee;color:#e53935;border:2px solid #ef9a9a;border-radius:99px;padding:5px 12px;font-size:12px;font-weight:700;cursor:pointer;font-family:inherit">🗑️</button>
          </td>
        </tr>`).join('')}
      </tbody>
    </table>` : '<div class="empty"><p>Không có lớp học nào</p></div>';
}

function admRenderUsers(users) {
  document.getElementById('adm-users-table').innerHTML = users?.length ? `
    <table class="admin-table">
      <thead><tr><th>Họ tên</th><th>Email</th><th>Vai trò</th><th>Điểm</th><th>Trạng thái</th><th>Thao tác</th></tr></thead>
      <tbody>${users.map(u => {
        const isLocked = !!(u.is_locked || u.locked);
        return `
        <tr style="${isLocked ? 'opacity:.5;background:#fff5f5' : ''}">
          <td><strong>${u.full_name || '—'}</strong></td>
          <td style="color:#999;font-size:13px">${u.email}</td>
          <td>
            ${(() => {
              const roleInfo = {
                student: { label: '📚 Học sinh', bg: '#e8f5e9', color: '#43a047', border: '#a5d6a7' },
                teacher: { label: '🎓 Giáo viên', bg: '#ede9fe', color: '#7c3aed', border: '#c4b5fd' },
                admin:   { label: '⚙️ Admin',    bg: '#ffebee', color: '#e53935', border: '#ef9a9a' }
              }[u.role] || { label: u.role, bg: '#f3f4f6', color: '#666', border: '#e5e7eb' };
              return `<span style="display:inline-flex;align-items:center;gap:4px;border:2px solid ${roleInfo.border};border-radius:10px;padding:4px 10px;font-size:12px;font-weight:700;background:${roleInfo.bg};color:${roleInfo.color}">${roleInfo.label}</span>`;
            })()}
          </td>
          <td style="font-weight:800;color:var(--acc)">${u.quiz_score || 0}</td>
          <td>
            <span style="font-size:12px;font-weight:700;padding:4px 12px;border-radius:99px;
              background:${isLocked?'#ffebee':'#e8f5e9'};
              color:${isLocked?'#e53935':'#43a047'}">
              ${isLocked ? '🔒 Đã khoá' : '✅ Hoạt động'}
            </span>
          </td>
          <td>
            ${u.role === 'admin'
              ? '<span style="font-size:11px;color:#bbb;font-weight:600">— không áp dụng —</span>'
              : `<button onclick="admQuickLock('${u.id}',${!isLocked})"
                  style="background:${isLocked?'#e8f5e9':'#fff3e0'};
                         color:${isLocked?'#43a047':'#e65100'};
                         border:2px solid ${isLocked?'#a5d6a7':'#ffcc80'};
                         border-radius:99px;padding:6px 14px;font-size:12px;
                         cursor:pointer;font-family:inherit;font-weight:700;white-space:nowrap">
                  ${isLocked ? '🔓 Mở khoá' : '🔒 Khoá'}
                </button>`}
          </td>
        </tr>`;
      }).join('')}
      </tbody>
    </table>` : '<div class="empty"><div class="empty-icon">👥</div><p>Không có người dùng</p></div>';
}

function admSearchUsers() {
  const q    = document.getElementById('adm-search').value.toLowerCase();
  const role = document.getElementById('adm-filter-role').value;
  const filtered = _admAllUsers.filter(u =>
    (!q || (u.full_name||'').toLowerCase().includes(q) || u.email.toLowerCase().includes(q)) &&
    (!role || u.role === role)
  );
  admRenderUsers(filtered);
}

function admTab(name, el) {
  document.querySelectorAll('#adm-tabs .tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  ['users','content','stats'].forEach(n => {
    const e = document.getElementById('adm-tab-' + n);
    if (e) e.style.display = n === name ? '' : 'none';
  });
  if (name === 'stats') admLoadStats();
}

async function admQuickLock(userId, lock) {
  const target = _admAllUsers.find(u => u.id === userId);
  if (target && target.role === 'admin') return; // Không khoá được tài khoản admin
  const { error } = await sb.from('profiles').update({ is_locked: lock }).eq('id', userId);
  if (error) {
    // Thử với tên cột khác
    const { error: e2 } = await sb.from('profiles').update({ locked: lock }).eq('id', userId);
    if (e2) { alert('Lỗi khóa tài khoản: ' + e2.message); return; }
  }
  const u = _admAllUsers.find(u => u.id === userId);
  if (u) { u.locked = lock; u.is_locked = lock; admRenderUsers(_admAllUsers); }
}

async function openAdminClassDetail(classId) {
  // Tạo modal
  const ov = document.createElement('div');
  ov.className = 'acd-overlay';
  ov.id = 'acd-overlay';
  ov.onclick = (e) => { if (e.target === ov) closeAdminClassDetail(); };
  ov.innerHTML =
    '<div class="acd-modal">' +
      '<div class="acd-hdr">' +
        '<button class="acd-close" onclick="closeAdminClassDetail()">✕</button>' +
        '<h2 id="acd-title">🏫 Đang tải...</h2>' +
        '<p id="acd-sub">Thông tin chi tiết lớp học</p>' +
      '</div>' +
      '<div class="acd-body" id="acd-body"><div style="text-align:center;padding:40px;color:#aaa">⏳ Đang tải...</div></div>' +
    '</div>';
  document.body.appendChild(ov);

  try {
    // Fetch lớp
    const { data: cls } = await sb.from('classes')
      .select('id,name,description,class_code,teacher_id,created_at')
      .eq('id', classId).single();

    // Fetch thành viên + bài tập
    const [memRes, assignRes] = await Promise.all([
      sb.from('class_members').select('id,user_id,status,joined_at').eq('class_id', classId),
      sb.from('assignments').select('id,title,type,created_at').eq('class_id', classId).order('created_at',{ascending:false})
    ]);

    const allMembers = memRes.data || [];
    const approved   = allMembers.filter(m => m.status === 'approved');
    const pending    = allMembers.filter(m => m.status === 'pending');
    const assigns    = assignRes.data || [];

    // Fetch profiles
    const allUids = [...new Set([cls.teacher_id, ...allMembers.map(m=>m.user_id)].filter(Boolean))];
    let pmap = {};
    if (allUids.length > 0) {
      const { data: profs } = await sb.from('profiles').select('id,full_name,email,role').in('id', allUids);
      (profs||[]).forEach(p => { pmap[p.id] = p; });
    }

    const teacher = pmap[cls.teacher_id] || {};

    document.getElementById('acd-title').textContent = '🏫 ' + cls.name;
    document.getElementById('acd-sub').textContent = approved.length + ' học sinh · ' + assigns.length + ' bài tập · Tạo ' + new Date(cls.created_at).toLocaleDateString('vi-VN');

    // Cập nhật số học sinh trong bảng
    const cntEl = document.getElementById('adm-member-count-' + classId);
    if (cntEl) cntEl.textContent = approved.length + ' người';

    const body = document.getElementById('acd-body');
    const emojis = ['👦','👧','🧒','🧑','👨','👩'];

    body.innerHTML =
      // ── Section 1: Sửa thông tin lớp ──
      '<div class="acd-section">' +
        '<div class="acd-section-title">✏️ Thông tin lớp</div>' +
        '<div class="acd-edit-row">' +
          '<label style="font-size:12px;color:#7c3aed;font-weight:700;width:90px;flex-shrink:0">Tên lớp</label>' +
          '<input id="acd-name" value="' + escHtml(cls.name) + '">' +
          '<button class="acd-save-btn" onclick="admSaveClassName(\'' + classId + '\')">💾 Lưu</button>' +
        '</div>' +
        '<div class="acd-edit-row">' +
          '<label style="font-size:12px;color:#7c3aed;font-weight:700;width:90px;flex-shrink:0">Mô tả</label>' +
          '<input id="acd-desc" value="' + escHtml(cls.description||'') + '">' +
        '</div>' +
        '<div class="acd-edit-row">' +
          '<label style="font-size:12px;color:#7c3aed;font-weight:700;width:90px;flex-shrink:0">Mã lớp</label>' +
          '<span style="flex:1;font-size:14px;font-weight:800;letter-spacing:.05em;background:#f5f3ff;border:1.5px solid #ddd6fe;border-radius:10px;padding:8px 12px;color:#6d28d9">' + escHtml(cls.class_code||'—') + '</span>' +
        '</div>' +
        '<div style="text-align:right;margin-top:4px"><button class="acd-save-btn" onclick="admSaveClassInfo(\'' + classId + '\')">💾 Lưu tất cả thông tin</button></div>' +
        '<div id="acd-info-msg" style="font-size:12px;margin-top:6px;text-align:right"></div>' +
      '</div>' +

      // ── Section 2: Giáo viên phụ trách (chỉ xem, không đổi) ──
      '<div class="acd-section">' +
        '<div class="acd-section-title">👨‍🏫 Giáo viên phụ trách</div>' +
        '<div style="display:flex;align-items:center;gap:10px">' +
          '<div style="width:40px;height:40px;border-radius:50%;background:#ede9fe;display:flex;align-items:center;justify-content:center;font-size:20px">👨‍🏫</div>' +
          '<div><div style="font-size:14px;font-weight:700">' + escHtml(teacher.full_name||'—') + '</div><div style="font-size:12px;color:#aaa">' + escHtml(teacher.email||'') + '</div></div>' +
        '</div>' +
      '</div>' +

      // ── Section 3: Danh sách học sinh ──
      '<div class="acd-section">' +
        '<div class="acd-section-title">🎒 Học sinh đã duyệt (' + approved.length + ')</div>' +
        (approved.length === 0 ? '<div style="color:#aaa;font-size:13px;text-align:center;padding:10px">Chưa có học sinh</div>' :
          approved.map((m,i) => {
            const p = pmap[m.user_id] || {};
            return '<div class="acd-student-row">' +
              '<div style="width:34px;height:34px;border-radius:50%;background:#ede9fe;display:flex;align-items:center;justify-content:center;font-size:15px">' + emojis[i%6] + '</div>' +
              '<div style="flex:1"><div style="font-size:13px;font-weight:700">' + escHtml(p.full_name||'Học sinh') + '</div><div style="font-size:11px;color:#aaa">' + escHtml(p.email||'') + '</div></div>' +
              '<button class="acd-kick-btn" onclick="admKickStudent(\'' + m.id + '\',\'' + escHtml(p.full_name||'học sinh này') + '\')">🚫 Xóa</button>' +
            '</div>';
          }).join('')
        ) +
      '</div>' +

      // ── Section 4: Chờ duyệt ──
      (pending.length > 0 ?
        '<div class="acd-section">' +
          '<div class="acd-section-title">⏳ Chờ duyệt (' + pending.length + ')</div>' +
          pending.map((m,i) => {
            const p = pmap[m.user_id] || {};
            return '<div class="acd-student-row">' +
              '<div style="width:34px;height:34px;border-radius:50%;background:#fef3c7;display:flex;align-items:center;justify-content:center;font-size:15px">' + emojis[i%6] + '</div>' +
              '<div style="flex:1"><div style="font-size:13px;font-weight:700">' + escHtml(p.full_name||'Học sinh') + '</div><div style="font-size:11px;color:#aaa">' + escHtml(p.email||'') + '</div></div>' +
              '<div style="display:flex;gap:4px">' +
                '<button onclick="admApproveStudent(\'' + m.id + '\')" style="background:#d1fae5;color:#065f46;border:none;border-radius:8px;padding:5px 10px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit">✅ Duyệt</button>' +
                '<button onclick="admRejectStudent(\'' + m.id + '\')" style="background:#fee2e2;color:#dc2626;border:none;border-radius:8px;padding:5px 10px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit">❌ Từ chối</button>' +
              '</div>' +
            '</div>';
          }).join('') +
        '</div>' : '') +

      // ── Section 5: Bài tập ──
      '<div class="acd-section">' +
        '<div class="acd-section-title">📝 Bài tập (' + assigns.length + ')</div>' +
        (assigns.length === 0 ? '<div style="color:#aaa;font-size:13px;text-align:center;padding:10px">Chưa có bài tập</div>' :
          assigns.map(a => {
            const tl = {quiz:'🧠 Quiz',vocab:'📚 Từ vựng',fill:'✏️ Điền',match2:'🔗 Nối từ',read:'📖 Đọc'};
            return '<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f0f0f0">' +
              '<div><div style="font-size:13px;font-weight:700">' + escHtml(a.title) + '</div><div style="font-size:11px;color:#aaa">' + (tl[a.type]||a.type) + ' · ' + new Date(a.created_at).toLocaleDateString('vi-VN') + '</div></div>' +
              '<button onclick="admDeleteAssign(\'' + a.id + '\')" style="background:#fee2e2;color:#dc2626;border:none;border-radius:8px;padding:4px 10px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit">🗑️</button>' +
            '</div>';
          }).join('')
        ) +
      '</div>';

    // Lưu classId để các hàm con dùng
    ov._classId = classId;

  } catch(err) {
    document.getElementById('acd-body').innerHTML = '<div style="color:#dc2626;padding:20px;text-align:center">❌ ' + err.message + '</div>';
  }
}

function closeAdminClassDetail() { const e = document.getElementById('acd-overlay'); if(e) e.remove(); }

async function admSaveClassInfo(classId) {
  const name = document.getElementById('acd-name').value.trim();
  const desc = document.getElementById('acd-desc').value.trim();
  const msg  = document.getElementById('acd-info-msg');
  if (!name) { msg.textContent = '❌ Tên lớp không được trống'; msg.style.color='#dc2626'; return; }
  const { error } = await sb.from('classes').update({ name, description: desc }).eq('id', classId);
  if (error) { msg.textContent = '❌ ' + error.message; msg.style.color='#dc2626'; }
  else { msg.textContent = '✅ Đã lưu!'; msg.style.color='#16a34a'; document.getElementById('acd-title').textContent = '🏫 ' + name; loadAdmin(); }
}

async function admKickStudent(memberId, name) {
  if (!confirm('Xóa ' + name + ' khỏi lớp?')) return;
  const { error, data } = await sb.from('class_members').delete().eq('id', memberId).select();
  if (error) {
    alert('Lỗi xóa học sinh: ' + error.message + '\n\nHãy kiểm tra RLS policy cm_delete trong Supabase.');
    return;
  }
  // Reload lại modal
  const ov = document.getElementById('acd-overlay');
  const cid = ov?._classId;
  closeAdminClassDetail();
  if (cid) openAdminClassDetail(cid);
}

async function admApproveStudent(memberId) {
  await sb.from('class_members').update({ status: 'approved' }).eq('id', memberId);
  const ov = document.getElementById('acd-overlay'); const cid = ov?._classId;
  closeAdminClassDetail(); if(cid) openAdminClassDetail(cid);
}

async function admRejectStudent(memberId) {
  await sb.from('class_members').delete().eq('id', memberId);
  const ov = document.getElementById('acd-overlay'); const cid = ov?._classId;
  closeAdminClassDetail(); if(cid) openAdminClassDetail(cid);
}

async function admDeleteAssign(assignId) {
  if (!confirm('Xóa bài tập này?')) return;
  await sb.from('assignments').delete().eq('id', assignId);
  const ov = document.getElementById('acd-overlay'); const cid = ov?._classId;
  closeAdminClassDetail(); if(cid) openAdminClassDetail(cid);
}

async function admDeleteClass(id) {
  if (!confirm('Xoá lớp học này? Toàn bộ học sinh và bài tập trong lớp cũng sẽ bị xoá.')) return;
  // Xoá class_members trước (tránh foreign key constraint)
  await sb.from('class_members').delete().eq('class_id', id);
  await sb.from('assignments').delete().eq('class_id', id);
  const { error } = await sb.from('classes').delete().eq('id', id);
  if (error) {
    alert('Lỗi xóa lớp: ' + error.message + '\n\nKiểm tra RLS policy bảng classes trong Supabase.');
  } else {
    closeAdminClassDetail();
    loadAdmin();
  }
}

async function admLoadStats() {
  // ── Bài tập: tổng số + phân bổ loại + tỷ lệ hoàn thành ──
  const { data: allAssigns } = await sb.from('assignments').select('id,type,class_id');
  const assigns = allAssigns || [];
  const assignsEl = document.getElementById('adm-stat-assigns');
  if (assignsEl) assignsEl.textContent = assigns.length;

  const { data: allResults } = await sb.from('assignment_results').select('assignment_id,user_id');
  const { data: allMembers } = await sb.from('class_members').select('class_id,user_id,status').eq('status','approved');
  const members = allMembers || [];
  // Tổng số lượt "phải làm" = số học sinh trong lớp * số bài tập của lớp đó
  const membersByClass = {};
  members.forEach(m => { (membersByClass[m.class_id] ||= []).push(m.user_id); });
  let expected = 0;
  assigns.forEach(a => { expected += (membersByClass[a.class_id]||[]).length; });
  const done = (allResults||[]).length;
  const completionEl = document.getElementById('adm-stat-completion');
  if (completionEl) completionEl.textContent = expected > 0 ? Math.round(Math.min(done,expected)/expected*100) + '%' : '—';

  // ── Tài khoản bị khoá ──
  const lockedCount = _admAllUsers.filter(u => u.is_locked || u.locked).length;
  const lockedEl = document.getElementById('adm-stat-locked');
  if (lockedEl) lockedEl.textContent = lockedCount;

  // ── Học sinh mới trong 7 ngày ──
  const weekAgo = Date.now() - 7*86400000;
  const newUserCount = _admAllUsers.filter(u => u.role === 'student' && u.created_at && new Date(u.created_at).getTime() >= weekAgo).length;
  const newUserEl = document.getElementById('adm-stat-newusers');
  if (newUserEl) newUserEl.textContent = newUserCount;

  // ── Top lớp học đông học sinh nhất ──
  const classes = window._admClasses || [];
  const classCounts = classes.map(c => ({ ...c, memberCount: (membersByClass[c.id]||[]).length }))
    .sort((a,b) => b.memberCount - a.memberCount).slice(0,5);
  const tc = document.getElementById('adm-top-classes');
  if (tc) tc.innerHTML = classCounts.length ? `
    <table class="admin-table">
      <thead><tr><th>#</th><th>Tên lớp</th><th>Giáo viên</th><th>Học sinh</th></tr></thead>
      <tbody>${classCounts.map((c,i)=>`
        <tr>
          <td style="font-weight:900;font-size:16px">${i===0?'🥇':i===1?'🥈':i===2?'🥉':i+1}</td>
          <td><strong>${escHtml(c.name)}</strong></td>
          <td>${escHtml(c.teacherName||'—')}</td>
          <td style="font-weight:800;color:var(--acc)">${c.memberCount} học sinh</td>
        </tr>`).join('')}
      </tbody>
    </table>` : '<div class="empty"><p>Chưa có lớp học nào</p></div>';

  // ── Top học sinh ──
  const { data: top } = await sb.from('profiles')
    .select('full_name,quiz_score,words_learned,streak_count')
    .eq('role','student').order('quiz_score',{ascending:false}).limit(10);
  const ts = document.getElementById('adm-top-students');
  if (ts) ts.innerHTML = (top||[]).length ? `
    <table class="admin-table">
      <thead><tr><th>#</th><th>Học sinh</th><th>Điểm Quiz</th><th>Từ đã học</th><th>Streak</th></tr></thead>
      <tbody>${(top||[]).map((u,i)=>`
        <tr>
          <td style="font-weight:900;font-size:18px">${i===0?'🥇':i===1?'🥈':i===2?'🥉':i+1}</td>
          <td><strong>${u.full_name||'—'}</strong></td>
          <td style="font-weight:800;color:var(--acc)">${u.quiz_score||0}</td>
          <td>${u.words_learned||0}</td>
          <td>🔥 ${u.streak_count||0}</td>
        </tr>`).join('')}
      </tbody>
    </table>` : '<div class="empty"><p>Chưa có dữ liệu</p></div>';

  const { data: logs } = await sb.from('study_logs')
    .select('study_date,cards_seen,quiz_score,profiles(full_name)')
    .order('study_date',{ascending:false}).limit(20);
  const ra = document.getElementById('adm-recent-activity');
  if (ra) ra.innerHTML = (logs||[]).length ? `
    <table class="admin-table">
      <thead><tr><th>Học sinh</th><th>Ngày học</th><th>Thẻ đã xem</th><th>Quiz</th></tr></thead>
      <tbody>${(logs||[]).map(l=>`
        <tr>
          <td><strong>${l.profiles?.full_name||'—'}</strong></td>
          <td>${l.study_date}</td>
          <td>🃏 ${l.cards_seen||0}</td>
          <td>🧠 ${l.quiz_score||0}</td>
        </tr>`).join('')}
      </tbody>
    </table>` : '<div class="empty"><p>Chưa có hoạt động</p></div>';

  setTimeout(()=>{
    admDrawRoleChart();
    admDrawActivityChart(logs||[]);
    admDrawAssignTypeChart(assigns);
    admDrawSignupChart(_admAllUsers);
  },100);
}

function admDrawAssignTypeChart(assigns) {
  const canvas = document.getElementById('adm-chart-atypes');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const labels = { vocab:'📚 Từ vựng', fill:'✏️ Điền chỗ trống', match2:'🔗 Nối từ', quiz:'🧠 Quiz', announce:'📢 Thông báo' };
  const colors = { vocab:'#43a047', fill:'#1565c0', match2:'#c2185b', quiz:'#6366f1', announce:'#e65100' };
  const types = Object.keys(labels);
  const counts = types.map(t => assigns.filter(a => a.type === t).length);
  const max = Math.max(...counts, 1);
  const W = canvas.width, H = canvas.height, pad = 20, rowH = (H - pad*2) / types.length;
  ctx.clearRect(0,0,W,H);
  ctx.font = '12px Nunito,sans-serif'; ctx.textBaseline = 'middle';
  types.forEach((t,i) => {
    const y = pad + i*rowH + rowH*0.2;
    const bh = rowH*0.6;
    const bw = (counts[i]/max) * (W - 140);
    ctx.fillStyle = '#666'; ctx.textAlign = 'left';
    ctx.fillText(labels[t], 4, y + bh/2);
    ctx.fillStyle = colors[t];
    ctx.beginPath(); ctx.roundRect(120, y, Math.max(bw,2), bh, 6); ctx.fill();
    ctx.fillStyle = '#333'; ctx.font = 'bold 12px Nunito,sans-serif';
    ctx.fillText(String(counts[i]), 126 + bw, y + bh/2);
    ctx.font = '12px Nunito,sans-serif';
  });
}

function admDrawSignupChart(users) {
  const canvas = document.getElementById('adm-chart-signups');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const days = Array.from({length:14},(_,i)=>new Date(Date.now()-(13-i)*86400000).toISOString().slice(0,10));
  const counts = days.map(d => users.filter(u => u.created_at && u.created_at.slice(0,10) === d).length);
  const max = Math.max(...counts, 1);
  const W = canvas.width, H = canvas.height, pad = 26, bw = (W - pad*2) / 14;
  ctx.clearRect(0,0,W,H);
  counts.forEach((c,i) => {
    const bh = (c/max) * (H - pad*2);
    const x = pad + i*bw + bw*0.15, y = H - pad - bh;
    const g = ctx.createLinearGradient(0,y,0,H-pad);
    g.addColorStop(0,'#7c3aed'); g.addColorStop(1,'#c4b5fd');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.roundRect(x,y,bw*0.7,Math.max(bh,1),4); ctx.fill();
    if (i % 2 === 0) {
      ctx.fillStyle = '#aaa'; ctx.font = '9px Nunito,sans-serif'; ctx.textAlign = 'center';
      ctx.fillText(days[i].slice(5), pad+i*bw+bw/2, H-8);
    }
    if (c > 0) { ctx.fillStyle = '#7c3aed'; ctx.font = 'bold 11px Nunito'; ctx.textAlign = 'center'; ctx.fillText(c, pad+i*bw+bw/2, y-4); }
  });
}

function admDrawRoleChart() {
  const canvas = document.getElementById('adm-chart-roles');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const data = [
    {label:'📚 Học sinh', val:_admAllUsers.filter(u=>u.role==='student').length, color:'#ff6f00'},
    {label:'🎓 Giáo viên',val:_admAllUsers.filter(u=>u.role==='teacher').length, color:'#7c3aed'},
    {label:'⚙️ Admin',   val:_admAllUsers.filter(u=>u.role==='admin').length,   color:'#e53935'},
  ];
  const total=data.reduce((s,d)=>s+d.val,0)||1;
  const W=canvas.width, H=canvas.height;
  ctx.clearRect(0,0,W,H);
  let angle=-Math.PI/2;
  data.forEach(d=>{
    const slice=(d.val/total)*Math.PI*2;
    ctx.beginPath(); ctx.moveTo(W/2,H/2);
    ctx.arc(W/2,H/2,Math.min(W,H)/2-40,angle,angle+slice);
    ctx.closePath(); ctx.fillStyle=d.color; ctx.fill();
    angle+=slice;
  });
  let y=10;
  data.forEach(d=>{
    ctx.fillStyle=d.color; ctx.fillRect(10,y,14,14);
    ctx.fillStyle='#333'; ctx.font='13px Nunito,sans-serif';
    ctx.fillText(`${d.label}: ${d.val}`,30,y+11); y+=22;
  });
}

function admDrawActivityChart(logs) {
  const canvas = document.getElementById('adm-chart-activity');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const days = Array.from({length:7},(_,i)=>new Date(Date.now()-(6-i)*86400000).toISOString().slice(0,10));
  const counts = days.map(d=>logs.filter(l=>l.study_date===d).length);
  const max=Math.max(...counts,1);
  const W=canvas.width,H=canvas.height,pad=30,bw=(W-pad*2)/7;
  ctx.clearRect(0,0,W,H);
  const dayNames=['CN','T2','T3','T4','T5','T6','T7'];
  counts.forEach((c,i)=>{
    const bh=(c/max)*(H-pad*2);
    const x=pad+i*bw+bw*.15, y=H-pad-bh;
    const g=ctx.createLinearGradient(0,y,0,H-pad);
    g.addColorStop(0,'#ff6f00'); g.addColorStop(1,'#ffd600');
    ctx.fillStyle=g;
    ctx.beginPath(); ctx.roundRect(x,y,bw*.7,bh,6); ctx.fill();
    ctx.fillStyle='#aaa'; ctx.font='11px Nunito,sans-serif'; ctx.textAlign='center';
    ctx.fillText(dayNames[new Date(days[i]+'T12:00:00').getDay()],pad+i*bw+bw/2,H-8);
    if(c>0){ctx.fillStyle='#ff6f00';ctx.font='bold 12px Nunito';ctx.fillText(c,pad+i*bw+bw/2,y-4);}
  });
}

// ─── LEADERBOARD ──────────────────────────────────────────────────────
