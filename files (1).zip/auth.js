function liSelectRole(role) {
  liRole = role;
  const colors = { student:['#a5d6a7','#e8f5e9','#43a047'], teacher:['#ce93d8','#f3e8ff','#7c3aed'], admin:['#ef9a9a','#ffebee','#e53935'] };
  const labels = { student:'Học sinh', teacher:'Giáo viên', admin:'Admin' };
  ['student','teacher','admin'].forEach(r => {
    const el = document.getElementById('li-rb-'+r);
    if (!el) return;
    if (r === role) {
      const [border,bg,txt] = colors[r];
      el.style.border = `3px solid ${border}`;
      el.style.background = bg;
      el.querySelector('div:last-child').style.color = txt;
    } else {
      el.style.border = '3px solid #ffd54f';
      el.style.background = '#fff';
      el.querySelector('div:last-child').style.color = '#aaa';
    }
  });
}


let curLesson = null, cardIdx = 0, cardFlipped = false, correctCount = 0;
let quizWords = [], quizIdx = 0, quizScore = 0;
let typeSentence = '', typeStart = null, typeDone = false, typeTimer = null;
let localVocab = [];

// ─── UTILS ────────────────────────────────────────────────────────────
async function doForgotPassword() {
  const email = document.getElementById('fp-email').value.trim();
  const errEl = document.getElementById('fp-err');
  const okEl  = document.getElementById('fp-ok');
  const btn   = document.getElementById('fp-btn');
  errEl.textContent = ''; okEl.textContent = '';

  if (!email) { errEl.textContent = 'Vui lòng nhập email.'; return; }

  btn.textContent = '⏳ Đang gửi...'; btn.disabled = true;

  // Dùng Site URL mặc định trong Supabase — không cần redirectTo
  const { error } = await sb.auth.resetPasswordForEmail(email);

  btn.textContent = '📧 Gửi link đặt lại'; btn.disabled = false;

  if (error) {
    // Hiện lỗi chi tiết để dễ debug
    let msg = error.message || '';
    if (msg.includes('rate limit') || msg.includes('Email rate limit')) {
      errEl.innerHTML = '⏳ <strong>Gửi quá nhiều lần!</strong> Supabase giới hạn 3 email/giờ.<br><small>Chờ 1 giờ rồi thử lại, hoặc kiểm tra hộp thư xem email cũ đã đến chưa.</small>';
    } else if (msg.includes('not allowed') || msg.includes('redirect')) {
      errEl.innerHTML = '❌ <strong>URL chưa được phép:</strong> <code>' + redirectUrl + '</code><br><small>Vào Supabase → Authentication → URL Configuration → Redirect URLs → thêm URL này vào.</small>';
    } else {
      errEl.textContent = '❌ ' + msg;
    }
    console.error('resetPasswordForEmail error:', error);
  } else {
    okEl.innerHTML = '✅ <strong>Đã gửi!</strong> Kiểm tra hộp thư <strong>' + email + '</strong><br><small>Kiểm tra cả thư mục Spam nếu không thấy.</small>';
    document.getElementById('fp-email').value = '';
  }
}

// ─── ĐẶT MẬT KHẨU MỚI (từ link email) ────────────────────────────
async function doResetPassword() {
  const pw1  = document.getElementById('rp-pw1').value;
  const pw2  = document.getElementById('rp-pw2').value;
  const errEl = document.getElementById('rp-err');
  const okEl  = document.getElementById('rp-ok');
  const btn   = document.getElementById('rp-btn');
  errEl.textContent = ''; okEl.textContent = '';

  if (pw1.length < 8) { errEl.textContent = 'Mật khẩu phải có ít nhất 8 ký tự.'; return; }
  if (pw1 !== pw2)    { errEl.textContent = 'Mật khẩu xác nhận không khớp.'; return; }

  btn.textContent = '⏳ Đang cập nhật...'; btn.disabled = true;

  const { error } = await sb.auth.updateUser({ password: pw1 });

  btn.textContent = '✅ Cập nhật mật khẩu'; btn.disabled = false;

  if (error) {
    errEl.textContent = '❌ ' + error.message;
  } else {
    okEl.textContent = '✅ Mật khẩu đã được đặt lại thành công!';
    setTimeout(() => showPage('login'), 2000);
  }
}

// ─── ĐỔI HỌ VÀ TÊN ──────────────────────────────────────────────
async function doChangeName() {
  const newName = document.getElementById('cn-name').value.trim();
  const errEl   = document.getElementById('cn-err');
  const okEl    = document.getElementById('cn-ok');
  const btn     = document.getElementById('cn-btn');
  errEl.textContent = ''; okEl.textContent = '';

  if (!newName) { errEl.textContent = 'Vui lòng nhập họ và tên.'; return; }
  if (newName.length < 2) { errEl.textContent = 'Họ và tên phải có ít nhất 2 ký tự.'; return; }

  btn.textContent = '⏳ Đang lưu...'; btn.disabled = true;

  try {
    // Cập nhật bảng profiles
    const { error: profErr } = await sb.from('profiles')
      .update({ full_name: newName })
      .eq('id', currentUser.id);
    if (profErr) throw profErr;

    // Cập nhật user metadata
    await sb.auth.updateUser({ data: { full_name: newName } });

    // Cập nhật local state ngay lập tức
    currentProfile.full_name = newName;

    // Cập nhật TẤT CẢ chỗ hiển thị tên trong app không cần reload
    const updates = {
      'nav-name'  : newName,
      'st-greet'  : 'Chào ' + newName + '! 🎯',
      'tc-greet'  : 'Chào ' + newName + '! 👋',
      'ad-greet'  : 'Chào ' + newName + '!',
    };
    Object.entries(updates).forEach(([id, val]) => {
      const el = document.getElementById(id);
      if (el) el.textContent = val;
    });
    // Cập nhật ô nhập tên trong trang cài đặt
    const cnName = document.getElementById('cn-name');
    if (cnName) cnName.value = newName;
    // Cập nhật ô nhập tên trong form cài đặt khi mở lại
    document.querySelectorAll('[data-display-name]').forEach(el => {
      el.textContent = newName;
    });

    okEl.innerHTML = '✅ Đã cập nhật tên thành <strong>' + newName + '</strong>!';
    btn.textContent = '💾 Lưu tên'; btn.disabled = false;
  } catch(e) {
    errEl.textContent = '❌ ' + (e.message || e);
    btn.textContent = '💾 Lưu tên'; btn.disabled = false;
  }
}

// ─── ĐỔI MẬT KHẨU (khi đã đăng nhập) ────────────────────────────
async function doChangePassword() {
  const pw1  = document.getElementById('cp-pw1').value;
  const pw2  = document.getElementById('cp-pw2').value;
  const errEl = document.getElementById('cp-err');
  const okEl  = document.getElementById('cp-ok');
  const btn   = document.getElementById('cp-btn');
  errEl.textContent = ''; okEl.textContent = '';

  if (pw1.length < 8) { errEl.textContent = 'Mật khẩu phải có ít nhất 8 ký tự.'; return; }
  if (pw1 !== pw2)    { errEl.textContent = 'Mật khẩu xác nhận không khớp.'; return; }

  btn.textContent = '⏳ Đang cập nhật...'; btn.disabled = true;

  const { error } = await sb.auth.updateUser({ password: pw1 });

  btn.textContent = '✅ Cập nhật'; btn.disabled = false;

  if (error) {
    errEl.textContent = '❌ ' + error.message;
  } else {
    okEl.textContent = '✅ Đổi mật khẩu thành công!';
    document.getElementById('cp-pw1').value = '';
    document.getElementById('cp-pw2').value = '';
    document.getElementById('pass-bar2').style.width = '0';
    document.getElementById('pass-hint2').textContent = '';
    setTimeout(() => { okEl.textContent = ''; backToDash(); }, 2000);
  }
}

// ─── KIỂM TRA ĐỘ MẠNH MẬT KHẨU ──────────────────────────────────
function checkPassStrength(val) {
  _doCheckStrength(val, 'pass-bar', 'pass-hint');
}
function checkPassStrength2(val) {
  _doCheckStrength(val, 'pass-bar2', 'pass-hint2');
}
function _doCheckStrength(val, barId, hintId) {
  const bar  = document.getElementById(barId);
  const hint = document.getElementById(hintId);
  if (!bar || !hint) return;
  let score = 0;
  if (val.length >= 8)  score++;
  if (val.length >= 12) score++;
  if (/[A-Z]/.test(val)) score++;
  if (/[0-9]/.test(val)) score++;
  if (/[^A-Za-z0-9]/.test(val)) score++;
  const levels = [
    {w:'0%',  bg:'#eee',     txt:''},
    {w:'25%', bg:'#ef4444',  txt:'Rất yếu'},
    {w:'45%', bg:'#f97316',  txt:'Yếu'},
    {w:'65%', bg:'#eab308',  txt:'Trung bình'},
    {w:'85%', bg:'#22c55e',  txt:'Mạnh'},
    {w:'100%',bg:'#16a34a',  txt:'Rất mạnh 💪'},
  ];
  const lvl = levels[Math.min(score, 5)];
  bar.style.width = val ? lvl.w : '0';
  bar.style.background = lvl.bg;
  hint.textContent = val ? lvl.txt : '';
  hint.style.color = lvl.bg;
}

// ─── XỬ LÝ REDIRECT TỪ EMAIL RESET ──────────────────────────────
(function handleAuthRedirect() {
  const hash   = window.location.hash   || '';
  const search = window.location.search || '';
  const isRecovery = hash.includes('type=recovery')
                  || search.includes('type=recovery')
                  || search.includes('reset=1');
  if (isRecovery) {
    // Xoá hash khỏi URL cho gọn
    history.replaceState(null, '', window.location.pathname);
    // Đợi Supabase SDK xử lý token trong hash xong mới show trang
    setTimeout(() => showPage('reset'), 600);
  }
})();

function selectRole(role) {
  selectedRole = role;
  ['student','teacher','admin'].forEach(r => {
    const el = document.getElementById('rb-' + r);
    el.className = 'role-btn' + (r === role ? ` active-${r}` : '');
  });
  document.getElementById('level-fg').style.display = role === 'student' ? '' : 'none';
}

async function doLogin() {
  const email = document.getElementById('li-email').value.trim();
  const pw    = document.getElementById('li-pw').value;
  const btn   = document.getElementById('li-btn');
  hideErr('li-err');
  if (!email || !pw) { showErr('li-err', 'Vui lòng điền đầy đủ thông tin.'); return; }
  if (!liRole)       { showErr('li-err', 'Vui lòng chọn vai trò (Học sinh / Giáo viên / Admin).'); return; }

  btn.textContent = 'Đang đăng nhập...'; btn.disabled = true;

  const { data, error } = await sb.auth.signInWithPassword({ email, password: pw });
  btn.textContent = 'Đăng nhập'; btn.disabled = false;

  if (error) { showErr('li-err', viErr(error.message)); return; }

  currentUser = data.user;
  await loadProfile();

  // Kiểm tra tài khoản có bị khóa không
  if (currentProfile?.is_locked || currentProfile?.locked) {
    _suppressSignOutRedirect = true;
    await sb.auth.signOut();
    currentUser = null; currentProfile = null;
    showErr('li-err', '🔒 Tài khoản của bạn đã bị khóa. Vui lòng liên hệ quản trị viên.');
    return;
  }

  // Kiểm tra role chọn có khớp với role thực tế không
  const actualRole = currentProfile?.role || 'student';
  if (actualRole !== liRole) {
    // Đăng xuất ngay để tránh truy cập sai quyền (nhưng vẫn ở lại trang đăng nhập)
    _suppressSignOutRedirect = true;
    await sb.auth.signOut();
    currentUser = null; currentProfile = null;

    const roleLabel = { student:'Học sinh 📚', teacher:'Giáo viên 🎓', admin:'Admin ⚙️' };
    const errMsg =
      '❌ Sai vai trò! Tài khoản này là <strong>' + (roleLabel[actualRole]||actualRole) + '</strong>.<br>' +
      'Vui lòng chọn đúng vai trò rồi đăng nhập lại.';
    document.getElementById('li-err').innerHTML = errMsg;
    document.getElementById('li-err').style.display = 'block';

    // Tự động highlight đúng role
    liSelectRole(actualRole);
    return;
  }

  // Chỉ cho phép 1 phiên đăng nhập tại 1 thời điểm: tạo mã phiên mới, ghi đè
  // lên mã cũ trong DB — nếu tài khoản đang đăng nhập ở nơi khác, mã cũ sẽ bị
  // vô hiệu hoá và nơi đó sẽ tự động bị đăng xuất ở lần kiểm tra tiếp theo.
  mySessionToken = (crypto.randomUUID ? crypto.randomUUID() : (Date.now() + '-' + Math.random().toString(36).slice(2)));
  await sb.from('profiles').update({ session_token: mySessionToken }).eq('id', currentUser.id);
  startSessionGuard();

  updateNav();
  goDashboard();
}

function startSessionGuard() {
  if (sessionGuardInterval) clearInterval(sessionGuardInterval);

  async function checkSession() {
    if (!currentUser || !mySessionToken) return;
    const { data, error } = await sb.from('profiles').select('session_token').eq('id', currentUser.id).single();
    if (error || !data) return;
    if (data.session_token && data.session_token !== mySessionToken) {
      clearInterval(sessionGuardInterval);
      sessionGuardInterval = null;
      document.removeEventListener('visibilitychange', onVisible);
      _suppressSignOutRedirect = true;
      await sb.auth.signOut();
      currentUser = null; currentProfile = null; mySessionToken = null;
      updateNav();
      showPage('login');
      showModal('🔒', 'Đã đăng xuất', 'Tài khoản này vừa được đăng nhập ở một thiết bị/trình duyệt khác. Vì lý do bảo mật, mỗi tài khoản chỉ được đăng nhập ở 1 nơi tại 1 thời điểm.', 'OK', closeModal);
    }
  }

  function onVisible() {
    if (document.visibilityState === 'visible') checkSession();
  }
  document.addEventListener('visibilitychange', onVisible);

  sessionGuardInterval = setInterval(checkSession, 8000);
}

async function doSignup() {
  const name = document.getElementById('su-name').value.trim();
  const email = document.getElementById('su-email').value.trim();
  const pw = document.getElementById('su-pw').value;
  const level = document.getElementById('su-level').value;
  const btn = document.getElementById('su-btn');
  hideErr('su-err');
  document.getElementById('su-ok').classList.remove('show');

  // Validate cơ bản
  if (!name || !email || !pw) { showErr('su-err', 'Vui lòng điền đầy đủ thông tin.'); return; }
  // Kiểm tra định dạng email hợp lệ
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) { showErr('su-err', 'Địa chỉ email không hợp lệ. Vui lòng nhập đúng định dạng (vd: ten@gmail.com).'); return; }
  if (pw.length < 6) { showErr('su-err', 'Mật khẩu phải có ít nhất 6 ký tự.'); return; }

  btn.textContent = 'Đang tạo tài khoản...';
  btn.disabled = true;

  try {
    // Đăng ký tài khoản
    const { data, error } = await sb.auth.signUp({
      email, password: pw,
      options: { data: { full_name: name, role: selectedRole, level } }
    });

    if (error) {
      showErr('su-err', viErr(error.message));
      return;
    }

    const user = data?.user || data?.session?.user;

    // Supabase không báo lỗi rõ ràng khi email đã tồn tại (để tránh lộ thông tin) —
    // thay vào đó trả về user với identities rỗng và không có session.
    // Đây là cách duy nhất để phát hiện tài khoản đã tồn tại trong trường hợp này.
    if (user && Array.isArray(user.identities) && user.identities.length === 0) {
      showErr('su-err', '❌ Email này đã được đăng ký. Vui lòng đăng nhập hoặc dùng email khác.');
      return;
    }

    if (user) {
      // Tạo profile ngay
      await sb.from('profiles').upsert({
        id: user.id,
        email,
        full_name: name,
        role: selectedRole,
        level: selectedRole === 'student' ? level : null,
        quiz_score: 0,
        words_learned: 0,
        best_wpm: 0
      }, { onConflict: 'id' });

      // Nếu có session (không cần xác nhận email) → đăng nhập luôn
      if (data?.session) {
        currentUser = user;
        await loadProfile();
        updateNav();
        goDashboard();
      } else {
        // Cần xác nhận email
        showOk('su-ok', '✅ Tài khoản đã tạo! Vui lòng kiểm tra email để xác nhận trước khi đăng nhập.');
        // Reset form
        document.getElementById('su-name').value = '';
        document.getElementById('su-email').value = '';
        document.getElementById('su-pw').value = '';
      }
    } else {
      showOk('su-ok', '✅ Tài khoản đã tạo! Vui lòng kiểm tra email để xác nhận.');
    }

  } catch(err) {
    showErr('su-err', 'Lỗi không xác định: ' + (err.message || err));
  } finally {
    btn.textContent = 'Tạo tài khoản';
    btn.disabled = false;
  }
}

async function doLogout() {
  if (sessionGuardInterval) { clearInterval(sessionGuardInterval); sessionGuardInterval = null; }
  if (currentUser && mySessionToken) {
    // Chỉ xoá session_token nếu nó vẫn là của phiên này (tránh xoá nhầm phiên mới hơn)
    await sb.from('profiles').update({ session_token: null }).eq('id', currentUser.id).eq('session_token', mySessionToken);
  }
  mySessionToken = null;
  await sb.auth.signOut();
  currentUser = null; currentProfile = null;
  updateNav();
  showPage('login');
}

async function loadProfile() {
  if (!currentUser) return;
  const { data } = await sb.from('profiles').select('*').eq('id', currentUser.id).single();
  if (data) {
    currentProfile = data;
  } else {
    // Profile chưa tồn tại → tạo mới (fallback nếu trigger chưa chạy)
    const newProfile = {
      id: currentUser.id,
      email: currentUser.email,
      full_name: currentUser.user_metadata?.full_name || currentUser.email?.split('@')[0] || '',
      role: currentUser.user_metadata?.role || 'student',
      level: currentUser.user_metadata?.level || null,
      quiz_score: 0, words_learned: 0, best_wpm: 0
    };
    const { data: created } = await sb.from('profiles').upsert(newProfile, { onConflict: 'id' }).select().single();
    currentProfile = created || newProfile;
  }
}

async function goDashboard() {
  // Luôn fetch profile mới nhất từ DB để có tên cập nhật
  if (currentUser) {
    const { data: freshProfile } = await sb.from('profiles')
      .select('*')
      .eq('id', currentUser.id)
      .single();
    if (freshProfile) {
      currentProfile = freshProfile;
      // Cập nhật nav-name
      const navName = document.getElementById('nav-name');
      if (navName) navName.textContent = freshProfile.full_name || freshProfile.email?.split('@')[0] || 'Người dùng';
    }
  }
  const role = currentProfile?.role || 'student';
  if (role === 'teacher') { loadTeacherDash(); showPage('teacher'); }
  else if (role === 'admin') { loadAdmin(); showPage('admin'); }
  else { loadStudentDash(); showPage('student'); }
}

// ─── STUDENT DASH ────────────────────────────────────────────────────

(async () => {
  // persistSession=false nên không auto-login khi mở lại trang
  // Chỉ xử lý link đặc biệt từ email (xác nhận / reset password)
  const hash   = window.location.hash || '';
  const search = window.location.search || '';
  const hasAuthToken = hash.includes('access_token') || hash.includes('type=');
  if (!hasAuthToken) {
    // Mở trang bình thường → luôn về màn hình đăng nhập
    showPage('home');
  }
  sb.auth.onAuthStateChange(async (event, session) => {
    if (event === 'SIGNED_OUT') {
      currentUser = null; currentProfile = null; updateNav();
      if (_suppressSignOutRedirect) { _suppressSignOutRedirect = false; }
      else { showPage('home'); }
    }

    // Người dùng click link xác nhận email trong Gmail
    if (event === 'SIGNED_IN' && session) {
      const isConfirmation = window.location.hash.includes('type=signup')
                          || window.location.hash.includes('access_token')
                          || window.location.search.includes('type=signup');
      if (isConfirmation) {
        // Xoá hash khỏi URL
        history.replaceState(null, '', window.location.pathname);
        currentUser = session.user;
        await loadProfile();
        updateNav();
        // Hiện thông báo xác nhận thành công
        showModal('🎉', 'Xác nhận thành công!',
          'Email của bạn đã được xác nhận. Chào mừng bạn đến với ứng dụng!',
          'Vào học ngay', () => { closeModal(); goDashboard(); });
        return;
      }
    }

    // Đặt lại mật khẩu
    if (event === 'PASSWORD_RECOVERY') {
      showPage('reset');
    }
  });
})();
