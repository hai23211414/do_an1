function updateNotifBadge() {
  const btn = document.getElementById('nav-notif-btn');
  const badge = document.getElementById('nav-notif-badge');
  if (!btn || !badge) return;
  if (!currentProfile || currentProfile.role !== 'student') { btn.style.display = 'none'; return; }
  btn.style.display = 'inline-flex';
  const list = (window._myAssigns || []).filter(a => a.type === 'announce');
  const completedIds = getCompletedAssigns();
  const unread = list.filter(a => !completedIds.includes(a.id)).length;
  if (unread > 0) { badge.textContent = unread > 9 ? '9+' : String(unread); badge.style.display = 'flex'; }
  else { badge.style.display = 'none'; }
}

function openAnnouncements() {
  const list = (window._myAssigns || []).filter(a => a.type === 'announce')
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  const completedIds = getCompletedAssigns();

  document.getElementById('m-em').textContent = '📢';
  document.getElementById('m-title').textContent = 'Thông báo lớp học';
  const body = document.getElementById('m-body');

  if (list.length === 0) {
    body.innerHTML = '<div style="text-align:center;padding:30px 10px;color:#aaa"><div style="font-size:44px;margin-bottom:10px">📭</div>Chưa có thông báo nào.</div>';
  } else {
    body.innerHTML = '<div style="text-align:left;max-height:420px;overflow:auto">' + list.map(a => {
      const isRead = completedIds.includes(a.id);
      const date = a.created_at ? new Date(a.created_at).toLocaleDateString('vi-VN') : '';
      return `
        <div class="notif-item" data-aid="${a.id}"
             style="cursor:pointer;padding:12px 14px;border-radius:12px;margin-bottom:8px;background:${isRead ? '#f9fafb' : '#fff3e0'};border:1.5px solid ${isRead ? '#e5e7eb' : '#ffb74d'}">
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
            ${isRead ? '' : '<span style="width:8px;height:8px;border-radius:50%;background:#f9760a;display:inline-block;flex-shrink:0"></span>'}
            <strong style="font-size:14px">${a.title}</strong>
          </div>
          <div style="font-size:12px;color:#888">🏫 ${a.classes?.name || 'Lớp học'} · ${date}</div>
        </div>`;
    }).join('') + '</div>';
    body.querySelectorAll('.notif-item').forEach(item => {
      item.onclick = () => showAnnouncementDetail(item.getAttribute('data-aid'));
    });
  }

  const mainBtn = document.getElementById('m-btn');
  if (mainBtn) mainBtn.style.display = 'none';
  document.getElementById('modal-ov').classList.add('open');
}

function showAnnouncementDetail(id) {
  const a = (window._myAssigns || []).find(x => x.id === id);
  if (!a) return;
  document.getElementById('m-em').textContent = '📢';
  document.getElementById('m-title').textContent = a.title;
  const body = document.getElementById('m-body');
  const imgs = (a.images || []).map(u => `<img src="${u}" style="max-width:100%;border-radius:10px;margin-bottom:10px">`).join('');
  const dateTxt = a.created_at ? new Date(a.created_at).toLocaleString('vi-VN') : '';
  body.innerHTML = `
    <div style="text-align:left">
      <div style="font-size:12px;color:#aaa;margin-bottom:10px">🏫 ${a.classes?.name || 'Lớp học'} · ${dateTxt}</div>
      ${imgs}
      <div style="font-size:14px;color:#444;white-space:pre-wrap;line-height:1.7">${(a.description || '').replace(/</g, '&lt;')}</div>
    </div>`;
  const mainBtn = document.getElementById('m-btn');
  if (mainBtn) {
    mainBtn.style.display = '';
    mainBtn.textContent = '← Quay lại danh sách';
    mainBtn.onclick = () => openAnnouncements();
  }
  document.getElementById('modal-ov').classList.add('open');
  markAssignDone(id, 0, { type: 'announce' }).then(updateNotifBadge);
}

// ─── AUTH ─────────────────────────────────────────────────────────────
function loadStudentDash() {
  const p = currentProfile;
  document.getElementById('st-greet').textContent = `Chào ${p?.full_name || 'bạn'}! 🎯`;
  document.getElementById('st-words').textContent = p?.words_learned || 0;
  document.getElementById('st-score').textContent = p?.quiz_score || 0;
  renderLessons();
  loadMyClasses();
  loadMyAssignments();
  loadMyPending();
}

function stTab(name, el) {
  document.querySelectorAll('#st-tabs .tab').forEach(t => t.classList.remove('active'));
  el?.classList.add('active');
  ['learn','class','assign'].forEach(n => document.getElementById('st-tab-' + n).style.display = n === name ? '' : 'none');
  if (name === 'class') loadMyClasses();
  if (name === 'assign') loadMyAssignments();
  bgRefreshStudentMusic();
}

function learnTab(name, el) {
  el.closest('.tabs').querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  ['flash','quiz','minigame'].forEach(n => {
    const el = document.getElementById('lt-' + n);
    if (el) el.style.display = n === name ? '' : 'none';
  });
  if (name === 'quiz') initQuiz();
  if (name === 'minigame') initMiniGame();
  bgRefreshStudentMusic();
}

function renderLessons() {
  const LESSON_EMOJI = {
    'a1-greet':'👋','a1-colors':'🌈','a1-family':'👨‍👩‍👧‍👦','a1-body':'🦷',
    'a2-food':'🍜','a2-school':'🏫','a2-weather':'⛅','a2-transport':'🚌',
    'b1-business':'💼','b1-travel':'✈️','b1-health':'🏥','b1-technology':'💻',
    'b2-academic':'📚','b2-environment':'🌍','b2-emotions':'💛','b2-idioms':'💬',
    'b2-ielts-vocab':'🎓'
  };
  const CARD_COLORS = [
    {bg:'#fff5f0',border:'#ffb347',icon:'#ff6f00'},
    {bg:'#f5f0ff',border:'#b39ddb',icon:'#7c3aed'},
    {bg:'#f0f8ff',border:'#90caf9',icon:'#1e88e5'},
    {bg:'#f0fff4',border:'#a5d6a7',icon:'#43a047'},
    {bg:'#fff0f8',border:'#f48fb1',icon:'#e91e8c'},
    {bg:'#f0fffd',border:'#80cbc4',icon:'#00897b'},
  ];
  document.getElementById('lessons-grid').innerHTML = LESSONS.map((l, i) => {
    const c = CARD_COLORS[i % CARD_COLORS.length];
    const emoji = LESSON_EMOJI[l.id] || '📖';
    return `
    <div class="lesson-card" onclick="startLesson('${l.id}')"
      style="border-color:${c.border};background:${c.bg}">
      <div style="font-size:3rem;margin-bottom:10px;line-height:1">${emoji}</div>
      <h3 style="font-size:18px;font-weight:900;margin-bottom:6px;color:#333">${l.title}</h3>
      <p style="font-size:13px;color:#999;line-height:1.5;font-weight:600">${l.desc}</p>
      <div style="margin-top:12px;display:flex;align-items:center;justify-content:space-between">
        <span style="background:${c.border};color:${c.icon};font-size:12px;font-weight:800;padding:4px 12px;border-radius:99px">${l.words.length} từ</span>
        <span style="font-size:20px">▶️</span>
      </div>
      <div class="prog-bar" style="margin-top:12px;background:#fff"><div class="prog-fill" style="width:0%;background:${c.icon}"></div></div>
    </div>`;
  }).join('');
}

// ─── CLASSES (STUDENT) ───────────────────────────────────────────────
async function loadMyClasses() {
  if (!currentUser) return;
  const el = document.getElementById('my-classes');

  // Xoá thông báo "đã gửi yêu cầu tham gia lớp" cũ mỗi khi vào lại tab này,
  // tránh hiện thông báo cũ (không còn đúng ngữ cảnh) sau khi rời đi rồi quay lại.
  const msgEl = document.getElementById('join-msg');
  if (msgEl) { msgEl.textContent = ''; msgEl.className = 'alert alert-info'; }

  // B1: Lấy class_id mà học sinh đã tham gia
  const { data: memberRows, error: memErr } = await sb.from('class_members')
    .select('id, class_id')
    .eq('user_id', currentUser.id).eq('status', 'approved');

  if (memErr || !memberRows || memberRows.length === 0) {
    el.innerHTML = '<div class="empty"><div class="empty-icon">🏫</div><p>Chưa có lớp nào.<br>Nhập mã lớp để tham gia!</p></div>';
    return;
  }

  const classIds = memberRows.map(m => m.class_id).filter(Boolean);

  // B2: Lấy thông tin các lớp đó (query riêng, không join)
  const { data: classRows = [] } = await sb.from('classes')
    .select('id,name,description,class_code,class_link')
    .in('id', classIds);

  const classMap = {};
  (classRows || []).forEach(c => { classMap[c.id] = c; });

  el.innerHTML = memberRows.map(m => {
    const cls = classMap[m.class_id];
    if (!cls) return '';
    const safeName = (cls.name || '').replace(/"/g, '&quot;');
    return '<div class="class-card ev-student-class" style="cursor:pointer" data-id="' + cls.id + '" data-name="' + safeName + '">' +
      '<div class="class-card-hdr">' +
        '<div style="display:flex;justify-content:space-between;align-items:flex-start">' +
          '<div><h3>' + (cls.name || '') + '</h3><p>' + (cls.description || '') + '</p></div>' +
          '<span style="font-size:12px;background:#fff3e0;color:#e65100;border-radius:99px;padding:4px 12px;font-weight:700;white-space:nowrap;margin-left:8px">Xem chi tiết →</span>' +
        '</div>' +
      '</div>' +
      '<div class="class-card-body">' +
        '<div style="font-size:12px;color:#aaa">✅ Đã tham gia · Mã: <strong>' + (cls.class_code || '') + '</strong></div>' +
      '</div>' +
    '</div>';
  }).join('');
}

async function openStudentClassView(classId, className) {
  const overlay = document.createElement('div');
  overlay.className = 'cls-modal-overlay';
  overlay.id = 'cls-modal-overlay';
  overlay.onclick = (e) => { if (e.target === overlay) closeStudentClassView(); };
  overlay.innerHTML =
    '<div class="cls-modal" style="max-width:520px">' +
      '<div class="cls-modal-hdr" style="background:linear-gradient(135deg,#1d4ed8,#3b82f6)">' +
        '<button class="cls-modal-close" onclick="closeStudentClassView()">✕</button>' +
        '<h2 style="color:#fff">🏫 ' + className + '</h2>' +
        '<p id="scv-sub" style="color:rgba(255,255,255,.75)">Đang tải...</p>' +
      '</div>' +
      '<div style="display:flex;border-bottom:2px solid #f0f0f0;background:#fff">' +
        '<button id="scv-t1" onclick="scvSwitchTab(1)" style="flex:1;padding:12px;border:none;border-bottom:3px solid #1d4ed8;background:transparent;font-size:13px;font-weight:700;color:#1d4ed8;cursor:pointer;font-family:inherit">👥 Thành viên</button>' +
        '<button id="scv-t2" onclick="scvSwitchTab(2)" style="flex:1;padding:12px;border:none;border-bottom:3px solid transparent;background:transparent;font-size:13px;font-weight:700;color:#aaa;cursor:pointer;font-family:inherit">📝 Bài tập</button>' +
      '</div>' +
      '<div class="cls-modal-body" id="scv-body" style="padding:16px 20px">' +
        '<div style="text-align:center;padding:40px;color:#bbb">⏳ Đang tải...</div>' +
      '</div>' +
    '</div>';
  document.body.appendChild(overlay);

  try {
    // ── B1: Lấy thông tin lớp ──
    const { data: cls, error: clsErr } = await sb.from('classes')
      .select('id,name,description,class_code,created_at,teacher_id')
      .eq('id', classId).single();
    if (clsErr || !cls) throw new Error('Không tìm thấy lớp: ' + (clsErr?.message || ''));

    // ── B2: Lấy danh sách thành viên approved ──
    const { data: rawMembers = [], error: memErr } = await sb.from('class_members')
      .select('id,user_id,joined_at')
      .eq('class_id', classId)
      .eq('status', 'approved')
      .order('joined_at', { ascending: true });

    // ── B3: Lấy bài tập ──
    const { data: assigns = [] } = await sb.from('assignments')
      .select('id,title,type,due_date,created_at')
      .eq('class_id', classId)
      .order('created_at', { ascending: false });

    // ── B4: Lấy profiles từng người một ──
    // Lấy profile giáo viên
    let teacher = null;
    if (cls.teacher_id) {
      const { data: tp } = await sb.from('profiles')
        .select('id,full_name,email').eq('id', cls.teacher_id).single();
      teacher = tp;
    }

    // Lấy profiles học sinh - từng batch để tránh RLS giới hạn
    let profileMap = {};
    const memberIds = (rawMembers || []).map(m => m.user_id).filter(Boolean);
    if (memberIds.length > 0) {
      const { data: mProfs = [] } = await sb.from('profiles')
        .select('id,full_name,email')
        .in('id', memberIds);
      (mProfs || []).forEach(p => { if (p) profileMap[p.id] = p; });
    }

    const members = (rawMembers || []).map((m, i) => ({
      ...m,
      displayName: (profileMap[m.user_id]?.full_name) || ('Học sinh ' + (i + 1)),
      email:       profileMap[m.user_id]?.email || ''
    }));

    const myMember = members.find(m => m.user_id === currentUser?.id);

    // Cập nhật header
    const subEl = document.getElementById('scv-sub');
    if (subEl) subEl.textContent = members.length + ' học sinh · ' + assigns.length + ' bài tập';

    // ── Render thành viên ──
    function buildMembers() {
      let h = '';
      // Card giáo viên
      h += '<div style="background:#eff6ff;border:1.5px solid #bfdbfe;border-radius:14px;padding:14px 16px;display:flex;align-items:center;gap:12px;margin-bottom:16px">';
      h += '<div style="width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,#1d4ed8,#60a5fa);display:flex;align-items:center;justify-content:center;font-size:24px;flex-shrink:0">👨‍🏫</div>';
      h += '<div><div style="font-size:15px;font-weight:800;color:#1e3a5f">' +
             (teacher?.full_name || teacher?.email || 'Giáo viên') +
           '</div>';
      h += '<div style="font-size:12px;color:#3b82f6;margin-top:2px">Giáo viên phụ trách</div></div></div>';

      // Thống kê
      h += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px">';
      h += '<div style="background:#f8faff;border-radius:12px;padding:12px;text-align:center">';
      h += '<div style="font-size:28px;font-weight:900;color:#1d4ed8">' + members.length + '</div>';
      h += '<div style="font-size:11px;color:#aaa;font-weight:700;margin-top:2px">Học sinh</div></div>';
      h += '<div style="background:#f0fdf4;border-radius:12px;padding:12px;text-align:center">';
      h += '<div style="font-size:22px;font-weight:900;color:#16a34a">' + (myMember ? '✅' : '—') + '</div>';
      h += '<div style="font-size:11px;color:#aaa;font-weight:700;margin-top:2px">' + (myMember ? 'Đã tham gia' : 'Chưa vào lớp') + '</div></div></div>';

      // Danh sách học sinh
      h += '<div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:#9ca3af;margin-bottom:8px">🎒 Danh sách học sinh (' + members.length + ')</div>';
      if (members.length === 0) {
        h += '<div style="text-align:center;padding:20px;color:#bbb;font-size:13px">Chưa có học sinh nào</div>';
      } else {
        const emojis = ['🧒','👦','👧','🧑','👨','👩'];
        h += '<div style="background:#f9f9f9;border-radius:14px;padding:4px 14px">';
        members.forEach(function(m, i) {
          const isMe = m.user_id === currentUser?.id;
          const sep  = i < members.length - 1 ? '1px solid #f0f0f0' : 'none';
          h += '<div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:' + sep + '">';
          h += '<div style="width:36px;height:36px;border-radius:50%;background:' + (isMe ? '#dbeafe' : '#e9e9e9') + ';border:' + (isMe ? '2px solid #3b82f6' : 'none') + ';display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0">' + emojis[i % 6] + '</div>';
          h += '<div style="flex:1">';
          h += '<div style="font-size:14px;font-weight:' + (isMe ? '900' : '700') + ';color:' + (isMe ? '#1d4ed8' : '#333') + '">' + m.displayName;
          if (isMe) h += ' <span style="font-size:10px;background:#dbeafe;color:#1d4ed8;padding:2px 6px;border-radius:99px">Bạn</span>';
          h += '</div>';
          h += '<div style="font-size:11px;color:#9ca3af">Tham gia ' + new Date(m.joined_at).toLocaleDateString('vi-VN') + '</div>';
          h += '</div>';
          h += '<div style="font-size:11px;color:#bbb;font-weight:700">#' + (i + 1) + '</div></div>';
        });
        h += '</div>';
      }

      // Mã lớp
      const code = cls.class_code || '—';
      h += '<div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:#9ca3af;margin:14px 0 8px">🔑 Mã lớp</div>';
      h += '<div style="background:#eff6ff;border:2px dashed #93c5fd;border-radius:12px;padding:10px 16px;display:flex;justify-content:space-between;align-items:center">';
      h += '<div style="font-family:monospace;font-size:22px;font-weight:900;color:#1d4ed8;letter-spacing:.12em">' + code + '</div>';
      h += '<button id="scv-copy-btn" style="background:#1d4ed8;color:#fff;border:none;border-radius:99px;padding:7px 14px;font-size:12px;font-weight:700;cursor:pointer;font-family:inherit">📋 Copy</button>';
      h += '</div>';
      return h;
    }

    // ── Render bài tập ──
    function buildAssigns() {
      if (!assigns || assigns.length === 0)
        return '<div style="text-align:center;padding:40px;color:#bbb"><div style="font-size:36px;margin-bottom:8px">📝</div><div style="font-size:13px">Chưa có bài tập nào</div></div>';
      const tLabel = {vocab:'📚 Từ vựng', fill:'✏️ Điền chỗ trống', match2:'🔗 Nối từ', announce:'📢 Thông báo'};
      const tColor = {vocab:'#f0fdf4', fill:'#e3f2fd', match2:'#fce4ec', announce:'#fff3e0'};
      let h = '';
      assigns.forEach(function(a) {
        const due = a.due_date ? new Date(a.due_date) : null;
        const late = due && due < new Date();
        h += '<div style="background:' + (tColor[a.type] || '#f9f9f9') + ';border-radius:14px;padding:14px 16px;margin-bottom:10px">';
        h += '<div style="font-size:14px;font-weight:800;color:#111;margin-bottom:4px">' + a.title + '</div>';
        h += '<div style="font-size:12px;color:#666;display:flex;gap:8px;flex-wrap:wrap">';
        h += '<span>' + (tLabel[a.type] || a.type) + '</span>';
        if (due) h += '<span style="color:' + (late ? '#dc2626' : '#059669') + ';font-weight:700">' + (late ? '⏰ Hết hạn ' : '📅 ') + due.toLocaleDateString('vi-VN') + '</span>';
        h += '</div></div>';
      });
      return h;
    }

    // ── Hiển thị và bind events ──
    const body = document.getElementById('scv-body');
    body.innerHTML = buildMembers();

    // Bind copy button
    setTimeout(function() {
      const cb = document.getElementById('scv-copy-btn');
      if (cb) cb.onclick = function() {
        navigator.clipboard.writeText(cls.class_code || '').then(function() {
          cb.textContent = '✓ Đã copy';
          setTimeout(function() { cb.textContent = '📋 Copy'; }, 1500);
        });
      };
    }, 50);

    // Tab switching
    window.scvSwitchTab = function(tab) {
      const t1 = document.getElementById('scv-t1');
      const t2 = document.getElementById('scv-t2');
      const b  = document.getElementById('scv-body');
      if (!t1 || !t2 || !b) return;
      if (tab === 1) {
        t1.style.color = '#1d4ed8'; t1.style.borderBottomColor = '#1d4ed8';
        t2.style.color = '#aaa';    t2.style.borderBottomColor = 'transparent';
        b.innerHTML = buildMembers();
        setTimeout(function() {
          const cb = document.getElementById('scv-copy-btn');
          if (cb) cb.onclick = function() {
            navigator.clipboard.writeText(cls.class_code || '').then(function() {
              cb.textContent = '✓ Đã copy';
              setTimeout(function() { cb.textContent = '📋 Copy'; }, 1500);
            });
          };
        }, 50);
      } else {
        t2.style.color = '#1d4ed8'; t2.style.borderBottomColor = '#1d4ed8';
        t1.style.color = '#aaa';    t1.style.borderBottomColor = 'transparent';
        b.innerHTML = buildAssigns();
      }
    };

  } catch(err) {
    const b = document.getElementById('scv-body');
    if (b) b.innerHTML = '<div style="text-align:center;padding:30px;color:#dc2626;font-size:13px">❌ ' + (err.message || err) + '</div>';
    console.error('openStudentClassView error:', err);
  }
}

function closeStudentClassView() {
  const el = document.getElementById('cls-modal-overlay');
  if (el) el.remove();
}

async function loadMyPending() {
  if (!currentUser) return;
  const el = document.getElementById('my-pending');
  const { data } = await sb.from('class_members')
    .select('*, classes(name)')
    .eq('user_id', currentUser.id).in('status', ['pending', 'rejected']);
  if (!data || data.length === 0) {
    el.innerHTML = '<div class="empty" style="padding:20px"><div class="empty-icon" style="font-size:24px">✅</div><p style="font-size:12px">Không có yêu cầu chờ</p></div>';
    return;
  }
  el.innerHTML = data.map(m => {
    if (m.status === 'rejected') {
      return `
      <div style="background:#ffebee;border:1px solid #ef9a9a;border-radius:12px;padding:10px 12px;margin-bottom:8px">
        <div style="font-size:13px;font-weight:500">${m.classes?.name}</div>
        <div style="font-size:11px;color:var(--red);margin-top:3px">❌ Yêu cầu đã bị giáo viên từ chối</div>
        <button onclick="rejoinClass('${m.id}','${escHtml(m.classes?.name||'').replace(/'/g,"\\'")}',this)" style="margin-top:6px;background:#fff;border:1.5px solid #ef9a9a;color:var(--red);border-radius:99px;padding:5px 14px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit">🔄 Gửi lại yêu cầu tham gia</button>
      </div>`;
    }
    return `
    <div style="background:#fffde7;border:1px solid #fcd34d;border-radius:12px;padding:10px 12px;margin-bottom:8px">
      <div style="font-size:13px;font-weight:500">${m.classes?.name}</div>
      <div style="font-size:11px;color:var(--gold);margin-top:3px">⏳ Đang chờ giáo viên duyệt</div>
    </div>`;
  }).join('');
}

async function rejoinClass(memberId, className, btn) {
  if (btn) { btn.textContent = 'Đang gửi...'; btn.disabled = true; }
  const { error } = await sb.from('class_members').update({ status: 'pending' }).eq('id', memberId);
  if (error) {
    if (btn) { btn.textContent = '🔄 Gửi lại yêu cầu tham gia'; btn.disabled = false; }
    showModal('❌', 'Lỗi', error.message, 'OK', closeModal);
    return;
  }
  // Đọc lại để xác nhận DB đã thực sự đổi trạng thái (phát hiện RLS âm thầm chặn UPDATE)
  const { data: verify } = await sb.from('class_members').select('status').eq('id', memberId).single();
  if (verify?.status !== 'pending') {
    if (btn) { btn.textContent = '🔄 Gửi lại yêu cầu tham gia'; btn.disabled = false; }
    showModal('❌', 'Không gửi được yêu cầu', 'Hệ thống chưa cho phép gửi lại yêu cầu (có thể do thiếu quyền cập nhật - RLS). Vui lòng báo quản trị viên kiểm tra lại chính sách bảo mật (RLS) của bảng class_members.', 'OK', closeModal);
    return;
  }
  loadMyPending();
  showModal('✅', 'Đã gửi lại yêu cầu!', 'Yêu cầu tham gia lớp "' + className + '" đã được gửi lại. Chờ giáo viên duyệt nhé!', 'OK', closeModal);
}

async function joinClass() {
  const val = document.getElementById('join-inp').value.trim();
  if (!val) return;
  const msgEl = document.getElementById('join-msg');
  msgEl.textContent = ''; msgEl.classList.remove('show');

  const btn = document.querySelector('#st-tab-class .btn-primary');
  if (btn) { btn.textContent = 'Đang tìm...'; btn.disabled = true; }

  try {
    // Xác định là code hay link
    let classCode = null, classLink = null;
    if (val.includes('?join=')) classLink = val.split('?join=').pop().trim();
    else if (val.includes('/')) classLink = val.split('/').pop().trim();
    else classCode = val.toUpperCase().trim();

    // Tìm lớp — dùng maybeSingle() thay single() để không throw error
    let query = sb.from('classes').select('id,name');
    if (classCode) query = query.eq('class_code', classCode);
    else query = query.eq('class_link', classLink);
    const { data: clsList, error: clsErr } = await query;

    if (clsErr) throw new Error('Lỗi kết nối. Vui lòng thử lại.');
    if (!clsList || clsList.length === 0) {
      msgEl.textContent = '❌ Không tìm thấy lớp học với mã "' + val + '". Kiểm tra lại mã lớp.';
      msgEl.className = 'alert alert-err show';
      return;
    }
    const cls = clsList[0];

    // Kiểm tra đã gửi yêu cầu chưa — dùng array thay single()
    const { data: existList } = await sb.from('class_members')
      .select('id,status')
      .eq('user_id', currentUser.id)
      .eq('class_id', cls.id);

    if (existList && existList.length > 0) {
      const exist = existList[0];
      if (exist.status === 'approved') {
        msgEl.textContent = '✅ Bạn đã là thành viên lớp "' + cls.name + '" rồi.';
        msgEl.className = 'alert alert-info show';
        return;
      }
      if (exist.status === 'pending') {
        msgEl.textContent = '⏳ Yêu cầu tham gia lớp "' + cls.name + '" đang chờ giáo viên duyệt.';
        msgEl.className = 'alert alert-info show';
        return;
      }
      if (exist.status === 'rejected') {
        // Yêu cầu trước đó đã bị từ chối — cho phép gửi lại yêu cầu mới
        const { error: reErr } = await sb.from('class_members')
          .update({ status: 'pending' })
          .eq('id', exist.id);
        if (reErr) throw new Error(reErr.message);
        // Đọc lại để xác nhận DB đã thực sự đổi trạng thái (phát hiện RLS âm thầm chặn UPDATE)
        const { data: verify } = await sb.from('class_members').select('status').eq('id', exist.id).single();
        if (verify?.status !== 'pending') {
          msgEl.textContent = '❌ Không gửi lại được yêu cầu (có thể do thiếu quyền cập nhật - RLS). Vui lòng báo quản trị viên kiểm tra bảng class_members.';
          msgEl.className = 'alert alert-err show';
          return;
        }
        msgEl.textContent = '✅ Đã gửi lại yêu cầu tham gia lớp "' + cls.name + '". Chờ giáo viên duyệt!';
        msgEl.className = 'alert alert-ok show';
        document.getElementById('join-inp').value = '';
        loadMyPending();
        return;
      }
    }

    // Gửi yêu cầu tham gia
    const { error: insertErr } = await sb.from('class_members')
      .insert({ user_id: currentUser.id, class_id: cls.id, status: 'pending' });

    if (insertErr) throw new Error(insertErr.message);

    msgEl.textContent = '✅ Đã gửi yêu cầu tham gia lớp "' + cls.name + '". Chờ giáo viên duyệt!';
    msgEl.className = 'alert alert-ok show';
    document.getElementById('join-inp').value = '';
    loadMyPending();

  } catch(err) {
    msgEl.textContent = '❌ ' + (err.message || 'Lỗi không xác định. Vui lòng thử lại.');
    msgEl.className = 'alert alert-err show';
  } finally {
    if (btn) { btn.textContent = 'Tham gia'; btn.disabled = false; }
  }
}

// ─── ASSIGNMENTS (STUDENT) ───────────────────────────────────────────
async function loadMyAssignments() {
  if (!currentUser) return;
  const el = document.getElementById('my-assigns');
  el.innerHTML = '<div style="text-align:center;padding:20px;color:#aaa;font-size:13px">⏳ Đang tải bài tập...</div>';

  try {
    // B1: Lấy class_id đã được approved
    const { data: mems, error: memErr } = await sb
      .from('class_members')
      .select('class_id')
      .eq('user_id', currentUser.id)
      .eq('status', 'approved');

    if (memErr) throw memErr;
    if (!mems || mems.length === 0) {
      el.innerHTML = '<div class="empty"><div class="empty-icon">📝</div><p>Chưa có bài tập nào.<br>Tham gia lớp để nhận bài!</p></div>';
      return;
    }

    const classIds = mems.map(m => m.class_id);

    // B2: Lấy bài tập theo class_id
    const { data, error: aErr } = await sb
      .from('assignments')
      .select('id, title, description, type, due_date, created_at, class_id, vocab_words, fill_data, match2_data, images, classes(name)')
      .in('class_id', classIds)
      .order('created_at', { ascending: false });

    if (aErr) throw aErr;

    window._myAssigns = data || []; // lưu để doAssignment/openAnnouncements dùng
    updateNotifBadge();

    // Thông báo (announce) tách riêng khỏi danh sách "bài tập" — chỉ xem qua icon 🔔
    const assignData = (data || []).filter(a => a.type !== 'announce');
    const count = assignData.length;
    const countEl = document.getElementById('assign-count');
    if (countEl) countEl.textContent = count + ' bài';

    if (count === 0) {
      el.innerHTML = '<div class="empty"><div class="empty-icon">📝</div><p>Chưa có bài tập nào.<br>Giáo viên sẽ giao bài sớm!</p></div>';
      return;
    }

    const typeLabels = { vocab:'📚 Từ vựng', fill:'✏️ Điền chỗ trống', match2:'🔗 Nối từ', quiz:'🧠 Quiz' };
    const typeClass  = { vocab: 'type-vocab', fill: 'type-fill', match2: 'type-match2', quiz: 'type-quiz' };
    const typeColor  = { vocab: '#f0fdf4', fill: '#e3f2fd', match2: '#fce4ec', quiz: '#eef2ff' };
    const typeBorder = { vocab: '#bbf7d0', fill: '#90caf9', match2: '#f48fb1', quiz: '#c7d2fe' };

    const completedIds = getCompletedAssigns();
    const data2 = assignData;
    el.innerHTML = data2.map(a => {
      const due      = a.due_date ? new Date(a.due_date) : null;
      const overdue  = due && due < new Date();
      const isDone   = completedIds.includes(a.id);
      const dueTxt   = due
        ? `<span style="font-size:12px;color:${overdue ? '#dc2626' : '#d97706'};font-weight:700">
             ${overdue ? '⏰ Hết hạn ' : '📅 Hạn: '}${due.toLocaleDateString('vi-VN')}
           </span>`
        : '';
      const actionEl = isDone
        ? `<div class="assign-done-badge" style="margin-top:10px;width:100%;justify-content:center">✅ Đã hoàn thành</div>`
        : `<button class="btn btn-outline-green btn-sm assign-done-btn ev-do-assign"
             style="margin-top:10px;width:100%"
             data-atype="${a.type}" data-aid="${a.id}">
             ▶ Làm bài ngay
           </button>`;
      return `
      <div class="assign-card ${isDone ? 'completed' : ''}"
           style="background:${typeColor[a.type]||'#fafafa'};border:1.5px solid ${isDone ? '#6ee7b7' : (typeBorder[a.type]||'#e5e7eb')}">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;margin-bottom:6px">
          <div style="display:flex;align-items:center;gap:8px">
            ${isDone ? '<span style="font-size:18px">✅</span>' : ''}
            <h4 style="margin:0;font-size:15px">${a.title}</h4>
          </div>
          <span class="assign-type ${typeClass[a.type]||''}" style="flex-shrink:0">${typeLabels[a.type]||a.type}</span>
        </div>
        ${a.description ? `<p style="font-size:13px;color:#666;margin:0 0 8px">${a.description}</p>` : ''}
        <div class="assign-meta">
          <span style="font-size:12px;color:#888">🏫 ${a.classes?.name || 'Lớp học'}</span>
          ${dueTxt}
        </div>
        ${actionEl}
      </div>`;
    }).join('');

  } catch(err) {
    console.error('loadMyAssignments error:', err);
    el.innerHTML = `
      <div style="background:#fff0f0;border:1.5px solid #fca5a5;border-radius:14px;padding:16px;font-size:13px;color:#991b1b">
        ❌ Không tải được bài tập: <strong>${err.message || err}</strong><br><br>
        <span style="color:#666;font-size:12px">Hãy kiểm tra RLS policy bảng <code>assignments</code> trong Supabase (xem hướng dẫn SQL bên dưới).</span>
      </div>`;
  }
}

function showAssignVocab(a) {
  const words = a.vocab_words || [];
  let idx = 0;

  function updateModal() {
    const w = words[idx];
    const pct = Math.round(idx / words.length * 100);
    const body = document.getElementById('m-body');
    if (!body) return;

    // Xây dựng nội dung bằng DOM để tránh lỗi quote
    let html = '';
    html += '<div style="text-align:center;padding:4px 0">';
    // Progress bar
    html += '<div style="background:#f0f0f0;border-radius:99px;height:7px;margin-bottom:10px">';
    html += '<div style="background:#f9a825;border-radius:99px;height:7px;width:' + pct + '%;transition:width .3s"></div></div>';
    // Counter
    html += '<div style="font-size:12px;color:#aaa;margin-bottom:8px">' + (idx+1) + ' / ' + words.length + ' từ</div>';
    // Image
    if (w.image_url) html += '<img src="' + w.image_url + '" style="width:110px;height:80px;object-fit:cover;border-radius:10px;margin-bottom:8px"><br>';
    // Word
    html += '<div style="font-size:34px;font-weight:900;color:#1a1814;margin-bottom:4px">' + w.word + '</div>';
    // Phonetic
    if (w.phonetic) html += '<div style="font-size:14px;color:#888;margin-bottom:4px">/' + w.phonetic + '/</div>';
    // Meaning
    html += '<div style="font-size:19px;font-weight:700;color:#f9a825;margin-bottom:4px">' + w.meaning + '</div>';
    // Example
    if (w.example) html += '<div style="font-size:12px;color:#888;font-style:italic;margin-bottom:12px">&ldquo;' + w.example + '&rdquo;</div>';
    else html += '<div style="margin-bottom:12px"></div>';
    // Buttons
    html += '<div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap">';
    html += '<button id="av-speak" style="background:#5DCAA5;border:none;border-radius:99px;padding:8px 18px;color:#085041;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit">🔊 Nghe</button>';
    if (idx < words.length - 1) {
      html += '<button id="av-next" style="background:#f9a825;border:none;border-radius:99px;padding:8px 20px;color:#412402;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit">Tiếp →</button>';
    } else {
      html += '<button id="av-done" style="background:#27ae60;border:none;border-radius:99px;padding:8px 20px;color:#fff;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit">✅ Xong!</button>';
    }
    html += '</div></div>';

    body.innerHTML = html;

    // Gắn events SAU khi render (tránh inline onclick với quotes)
    const speakBtn = document.getElementById('av-speak');
    if (speakBtn) speakBtn.onclick = function() {
      if (!window.speechSynthesis) { alert('Trình duyệt không hỗ trợ phát âm.'); return; }
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(w.word);
      u.lang  = 'en-US';
      u.rate  = 0.8;
      u.pitch = 1;
      window.speechSynthesis.speak(u);
    };
    const nextBtn = document.getElementById('av-next');
    if (nextBtn) nextBtn.onclick = function() { idx++; updateModal(); };
    const doneBtn = document.getElementById('av-done');
    if (doneBtn) doneBtn.onclick = async function() {
      // Đánh dấu hoàn thành
      await markAssignDone(currentAssignId, words.length * 10, {type:'vocab', words:words.length});
      // Đổi nội dung modal thành màn hoàn thành
      document.getElementById('m-em').textContent = '🎉';
      document.getElementById('m-title').textContent = 'Hoàn thành bài tập!';
      const body = document.getElementById('m-body');
      body.innerHTML =
        '<div style="text-align:center">' +
          '<div style="font-size:60px;margin-bottom:10px">✅</div>' +
          '<div style="font-size:18px;font-weight:700;color:#065f46;margin-bottom:6px">Học từ vựng xuất sắc!</div>' +
          '<div style="font-size:14px;color:#666;margin-bottom:16px">Bạn đã học hết ' + words.length + ' từ trong bài này</div>' +
          '<div class="assign-done-badge" style="justify-content:center;font-size:14px;padding:8px 20px;margin:0 auto">✅ Bài tập đã hoàn thành</div>' +
        '</div>';
      const mainBtn = document.getElementById('m-btn');
      mainBtn.textContent = 'Về danh sách bài tập';
      mainBtn.style.display = '';
      mainBtn.onclick = function() {
        closeModal();
        const assignTab = document.querySelector('#st-tabs .tab[onclick*="assign"]');
        if (assignTab) stTab('assign', assignTab);
      };
    };
  }

  // Mở modal
  document.getElementById('m-em').textContent = '📚';
  document.getElementById('m-title').textContent = a.title;
  const mainBtn = document.getElementById('m-btn');
  if (mainBtn) mainBtn.style.display = 'none';
  document.getElementById('modal-ov').classList.add('open');
  updateModal();
}

// ID bài tập đang làm — để markAssignDone biết cái nào xong
let currentAssignId = null;

function doAssignment(type, id) {
  stopBgMusic(); // học sinh bắt đầu làm bài tập → tắt nhạc nền ngay
  const assigns = window._myAssigns || [];
  const a = assigns.find(x => x.id === id);
  currentAssignId = id;

  if (type === 'vocab' && a?.vocab_words?.length > 0) {
    showAssignVocab(a);
  } else if (type === 'fill' && a?.fill_data?.length > 0) {
    showAssignFill(a);
  } else if (type === 'match2' && a?.match2_data?.length > 0) {
    showAssignMatch2(a);
  } else if (type === 'quiz' && a?.fill_data?.length > 0) {
    showAssignQuiz(a);
  } else if (type === 'announce') {
    showAnnouncementDetail(id);
  } else {
    showModal('⚠️', 'Không có nội dung', 'Bài tập này chưa có nội dung để làm.', 'OK', closeModal);
  }
}

async function markAssignDone(id, score, detail) {
  if (!id || !currentUser) { console.warn('markAssignDone: missing id or user'); return; }
  const uid = currentUser.id;

  // 1. Lưu localStorage (hiển thị badge ngay lập tức)
  const key = 'done_assigns_' + uid;
  let done = [];
  try { done = JSON.parse(localStorage.getItem(key) || '[]'); } catch(e) {}
  if (!done.includes(id)) { done.push(id); localStorage.setItem(key, JSON.stringify(done)); }

  // 2. Lưu lên Supabase — log lỗi đầy đủ nếu thất bại
  const { data, error } = await sb.from('assignment_results').upsert({
    assignment_id: id,
    user_id: uid,
    score: score != null ? score : 0,
    detail: detail ? JSON.stringify(detail) : null,
    completed_at: new Date().toISOString()
  }, { onConflict: 'assignment_id,user_id' });

  if (error) {
    console.error('❌ assignment_results upsert failed:', error);
    // Hiện cảnh báo nhỏ — không block UI
    const el = document.getElementById('my-assigns');
    if (el) {
      const warn = document.createElement('div');
      warn.style.cssText = 'background:#fff3cd;border:1px solid #ffc107;border-radius:8px;padding:8px 12px;font-size:12px;color:#856404;margin-bottom:8px';
      warn.textContent = '⚠️ Lưu kết quả thất bại: ' + error.message + '. Liên hệ quản trị viên.';
      el.prepend(warn);
      setTimeout(() => warn.remove(), 8000);
    }
  } else {
    console.log('✅ assignment_results saved, score=', score);
  }

  // 3. Reload danh sách bài tập
  loadMyAssignments();
}

function getCompletedAssigns() {
  const uid = currentUser?.id || 'guest';
  try { return JSON.parse(localStorage.getItem('done_assigns_' + uid) || '[]'); } catch(e) { return []; }
}


// ─── FLASHCARD ───────────────────────────────────────────────────────
// Image cache: word → url  (tránh load lại mỗi khi flip)
const imgCache = {};

function startLesson(id) {
  curLesson = LESSONS.find(l => l.id === id);
  cardIdx = 0; correctCount = 0; cardFlipped = false;
  document.getElementById('lesson-title').textContent = `${curLesson.level} — ${curLesson.title}`;
  showPage('lesson');
  showCard();
}

function showCard() {
  const w = curLesson.words[cardIdx], tot = curLesson.words.length;
  document.getElementById('lp-fill').style.width = Math.round(cardIdx / tot * 100) + '%';
  document.getElementById('lp-cnt').textContent = `${cardIdx + 1}/${tot}`;
  document.getElementById('fc-word').textContent = w.w;
  document.getElementById('fc-ph').textContent = w.p;
  document.getElementById('fc-mn').textContent = w.m;
  document.getElementById('fc-ex').textContent = `"${w.e}"`;
  document.getElementById('fc-hint').textContent = 'Nhấn để xem nghĩa';
  document.getElementById('fc-mn').style.display = 'none';
  document.getElementById('fc-ex').style.display = 'none';
  document.getElementById('card-acts').style.display = 'none';
  document.getElementById('fc-next').style.display = 'none';
  cardFlipped = false;
  // Load ảnh minh họa
  loadCardImage(w);
}

// Từ khóa tìm ảnh tốt hơn từ tên word gốc
const IMG_QUERY_MAP = {
  // A1 Greetings
  'Hello':'people waving greeting','Goodbye':'farewell wave',
  'Thank you':'gratitude hands','Please':'polite hands',
  'Sorry':'apology sorry','Good morning':'sunrise morning',
  'Good night':'night sky stars','How are you':'friends talking',
  'Fine':'happy person smile','Nice to meet you':'handshake meeting',
  'See you later':'waving goodbye','Welcome':'welcome sign door',
  // A1 Colors
  'Red':'red color vibrant','Blue':'blue ocean sky',
  'Green':'green nature leaf','Yellow':'yellow sunflower field',
  'White':'white snow clean','Black':'black night dark',
  'Orange':'orange fruit citrus','Purple':'purple lavender flower',
  'One':'single one object','Two':'pair two objects',
  'Three':'three objects','Ten':'number ten','Twenty':'twenty','Hundred':'crowd hundred',
  // A1 Family
  'Mother':'mother child love','Father':'father family',
  'Brother':'brothers siblings','Sister':'sisters siblings',
  'Grandfather':'elderly grandfather','Grandmother':'grandmother baking',
  'Son':'son child boy','Daughter':'daughter girl child',
  'Uncle':'uncle family man','Aunt':'aunt family woman',
  'Cousin':'cousins playing','Husband':'husband wife couple','Wife':'wife couple love',
  // A1 Body
  'Head':'human head face','Eye':'human eye close up',
  'Nose':'human nose face','Mouth':'human mouth smile',
  'Ear':'human ear','Hand':'human hands',
  'Foot':'human foot feet','Arm':'human arm',
  'Leg':'human legs walking','Shoulder':'shoulder back',
  'Back':'person back posture','Stomach':'stomach abdomen',
  // A2 Food
  'Breakfast':'breakfast meal morning','Lunch':'lunch meal plate',
  'Dinner':'dinner table candle','Delicious':'delicious food plate',
  'Hungry':'hungry person food','Thirsty':'thirsty drinking water',
  'Rice':'rice bowl asian food','Noodles':'noodle bowl soup',
  'Vegetable':'fresh vegetables market','Fruit':'fresh fruit colorful',
  'Chicken':'grilled chicken dish','Seafood':'seafood platter fresh',
  'Coffee':'coffee cup cafe','Cake':'birthday cake slice','Restaurant':'restaurant interior',
  // A2 School
  'Classroom':'school classroom students','Teacher':'teacher classroom',
  'Student':'student studying books','Homework':'homework desk study',
  'Exam':'exam test paper','Pencil':'pencil writing',
  'Notebook':'notebook writing','Library':'library books shelf',
  'Subject':'school subjects','Lesson':'lesson learning','Question':'question mark think',
  'Answer':'answer solution lightbulb',
  // A2 Weather
  'Sunny':'sunny day blue sky','Rainy':'rain umbrella street',
  'Cloudy':'cloudy sky overcast','Windy':'wind leaves blowing',
  'Hot':'hot summer heat','Cold':'cold winter snow',
  'Storm':'storm lightning dark','Rainbow':'rainbow colorful sky',
  'Mountain':'mountain landscape peak','River':'river flowing nature',
  'Ocean':'ocean waves beach','Forest':'green forest trees',
  'Flower':'colorful flowers bloom','Season':'four seasons nature',
  // A2 Transport
  'Car':'red car road','Bus':'city bus street',
  'Motorbike':'motorbike riding','Bicycle':'bicycle cycling road',
  'Train':'train station travel','Airplane':'airplane sky flying',
  'Taxi':'yellow taxi city','Traffic':'city traffic road',
  'Road':'empty road highway','Station':'train station busy',
  'Ticket':'boarding ticket travel','Driver':'driver car wheel',
  // B1 Business
  'Deadline':'deadline clock work','Meeting':'business meeting office',
  'Colleague':'colleagues office work','Schedule':'planner schedule calendar',
  'Presentation':'business presentation stage','Report':'business report document',
  'Manager':'manager office professional','Budget':'budget finance money',
  'Client':'client meeting handshake','Contract':'contract signing pen',
  'Promotion':'promotion success career','Salary':'salary paycheck money',
  'Interview':'job interview professional','Resume':'resume cv paper','Feedback':'feedback review rating',
  // B1 Travel
  'Passport':'passport travel document','Boarding pass':'boarding pass airport',
  'Currency':'currency money exchange','Accommodation':'hotel room accommodation',
  'Itinerary':'travel itinerary map','Luggage':'luggage suitcase airport',
  'Check-in':'hotel checkin reception','Souvenir':'souvenir shop travel',
  'Destination':'travel destination city','Tour guide':'tour guide sightseeing',
  'Visa':'visa stamp passport','Delay':'flight delay airport','Exchange rate':'money exchange rate',
  // B1 Health
  'Headache':'headache migraine pain','Fever':'fever thermometer sick',
  'Medicine':'medicine pills capsule','Doctor':'doctor hospital white coat',
  'Hospital':'hospital building exterior','Surgery':'surgery operating room',
  'Prescription':'prescription medicine doctor','Allergy':'allergy reaction skin',
  'Symptom':'sick symptoms ill','Recovery':'recovery hospital rest',
  'Exercise':'exercise fitness gym','Nutrition':'healthy nutrition food',
  // B1 Technology
  'Software':'software code computer','Application':'mobile app smartphone',
  'Password':'password security lock','Website':'website laptop screen',
  'Download':'download internet speed','Upload':'upload cloud data',
  'Connection':'wifi internet connection','Virus':'computer virus security',
  'Keyboard':'keyboard typing computer','Screen':'computer screen monitor',
  'Notification':'notification phone alert','Artificial intelligence':'artificial intelligence robot',
  // B2 Academic
  'Phenomenon':'natural phenomenon science','Hypothesis':'science hypothesis lab',
  'Controversial':'debate controversial discussion','Subsequently':'timeline sequence steps',
  'Elaborate':'detailed plan elaborate','Implication':'consequence ripple effect',
  'Methodology':'research methodology study','Perspective':'different perspective viewpoint',
  'Significant':'significant achievement milestone','Framework':'framework structure architecture',
  'Evidence':'evidence proof investigation','Analysis':'data analysis graph',
  // B2 Environment
  'Sustainability':'sustainability green earth','Pollution':'pollution smoke factory',
  'Renewable':'solar panel renewable energy','Carbon footprint':'carbon footprint emissions',
  'Deforestation':'deforestation cut trees','Greenhouse gas':'greenhouse gas emissions',
  'Overpopulation':'crowded city overpopulation','Inequality':'inequality poverty rich',
  'Discrimination':'discrimination diversity protest','Biodiversity':'biodiversity wildlife nature',
  'Recycling':'recycling bin sorting','Conservation':'wildlife conservation nature',
  // B2 Emotions
  'Enthusiastic':'enthusiastic excited jump','Frustrated':'frustrated stressed person',
  'Anxious':'anxious worried person','Compassionate':'compassionate helping hands',
  'Optimistic':'optimistic happy sunrise','Stubborn':'stubborn crossed arms',
  'Generous':'generous donation giving','Ambitious':'ambitious success climbing',
  'Overwhelmed':'overwhelmed stressed busy','Confident':'confident posture success',
  'Empathy':'empathy support comfort','Resilient':'resilient strong overcome',
  // B2 Idioms
  'Break the ice':'ice party social','Hit the nail on the head':'nail hammer carpentry',
  'Under the weather':'sick bed rest','Piece of cake':'easy cake slice',
  'Bite the bullet':'brave determined face','Cost an arm and a leg':'expensive shopping luxury',
  'Once in a blue moon':'rare blue moon night','Spill the beans':'beans spill surprise',
  'Let the cat out of the bag':'cat bag surprise','Hit the sack':'bed sleeping night',
  'Bite off more than you can chew':'too much work overwhelmed',
  'Kill two birds with one stone':'efficiency multitasking',
  // B2 IELTS
  'Mitigate':'reduce climate action','Exacerbate':'problem worsening crisis',
  'Proliferate':'spread growth expand','Prevalent':'common widespread',
  'Advocate':'protest rights advocate','Detrimental':'harmful damage effect',
  'Inevitable':'unstoppable change flow','Scrutinize':'inspect examine detail',
  'Pragmatic':'practical solution tools','Coherent':'clear logic structure',
  'Concede':'admit agree handshake','Juxtapose':'contrast compare two sides'
};

const WORD_EMOJI_FALLBACK = {
  'Hello':'👋','Goodbye':'👋','Thank you':'🙏','Please':'🤲','Sorry':'😔',
  'Good morning':'🌅','Good night':'🌙','How are you':'😊','Fine':'😄',
  'Red':'🔴','Blue':'🔵','Green':'🟢','Yellow':'🟡','White':'⬜','Black':'⬛',
  'Orange':'🟠','Purple':'🟣','One':'1️⃣','Two':'2️⃣','Three':'3️⃣',
  'Mother':'👩','Father':'👨','Brother':'👦','Sister':'👧',
  'Grandfather':'👴','Grandmother':'👵','Son':'👦','Daughter':'👧',
  'Head':'🧠','Eye':'👁','Nose':'👃','Mouth':'👄','Ear':'👂',
  'Hand':'✋','Foot':'🦶','Arm':'💪','Leg':'🦵',
  'Breakfast':'🍳','Lunch':'🥗','Dinner':'🍽','Delicious':'😋',
  'Hungry':'😤','Thirsty':'🥤','Rice':'🍚','Noodles':'🍜',
  'Vegetable':'🥦','Fruit':'🍎','Chicken':'🍗','Seafood':'🦐',
  'Coffee':'☕','Cake':'🎂','Restaurant':'🍴',
  'Car':'🚗','Bus':'🚌','Motorbike':'🏍','Bicycle':'🚲',
  'Train':'🚆','Airplane':'✈️','Taxi':'🚕',
  'Sunny':'☀️','Rainy':'🌧','Cloudy':'☁️','Windy':'💨',
  'Hot':'🌡','Cold':'❄️','Storm':'⛈','Rainbow':'🌈',
  'Mountain':'⛰','River':'🌊','Ocean':'🌊','Forest':'🌳','Flower':'🌸',
  'Doctor':'👨‍⚕️','Hospital':'🏥','Medicine':'💊',
  'Software':'💻','Application':'📱','Password':'🔐','Website':'🌐',
  'Keyboard':'⌨️','Screen':'🖥','Pollution':'🏭','Recycling':'♻️',
};

// ── ẢNH THẬT từ Pexels API ─────────────────────────────────────────────
// Lấy key miễn phí tại: https://www.pexels.com/api/
const PEXELS_API_KEY = 'dFUWV3zo9tQHEOISbzPiilSITgyf0WYg46OOLTbfzvaUBP50Bipc9gBr';

async function loadCardImage(word) {
  const wrapEl = document.getElementById('fc-img-wrap');
  const skelEl = document.getElementById('fc-img-skeleton');
  const imgEl  = document.getElementById('fc-img');

  // Reset UI
  imgEl.style.display  = 'none';
  imgEl.classList.remove('loaded');
  skelEl.style.display = 'block';
  const oldSvg = wrapEl.querySelector('.fc-svg-art');
  if (oldSvg) oldSvg.remove();
  const oldPh = wrapEl.querySelector('.fc-img-placeholder');
  if (oldPh) oldPh.remove();

  const cacheKey = word.w;
  if (imgCache[cacheKey]) {
    _applyRealImage(imgCache[cacheKey].src, imgCache[cacheKey].author, imgEl, skelEl);
    return;
  }

  // Nếu chưa có API key → hiện hướng dẫn
  if (PEXELS_API_KEY === 'YOUR_PEXELS_API_KEY') {
    _showImgBanner(skelEl, imgEl,
      '🔑 Thêm Pexels API key vào code để xem ảnh thật.<br>' +
      '<a href="https://www.pexels.com/api/" target="_blank" style="color:var(--blue)">Đăng ký miễn phí tại pexels.com/api</a>',
      WORD_EMOJI_FALLBACK[word.w] || '🖼️');
    return;
  }

  try {
    const query = encodeURIComponent(IMG_QUERY_MAP[word.w] || word.w);
    const res   = await fetch(
      `https://api.pexels.com/v1/search?query=${query}&per_page=5&orientation=landscape`,
      { headers: { Authorization: PEXELS_API_KEY } }
    );
    const data = await res.json();
    const photos = data.photos || [];
    if (!photos.length) throw new Error('no results');

    // Chọn ngẫu nhiên 1 trong 5 ảnh đầu để đa dạng
    const pick   = photos[Math.floor(Math.random() * photos.length)];
    const src    = pick.src.large;          // ~940px wide
    const author = pick.photographer;

    imgCache[cacheKey] = { src, author };
    _applyRealImage(src, author, imgEl, skelEl);

  } catch(e) {
    // Fallback emoji nếu lỗi mạng / quota
    _showImgBanner(skelEl, imgEl,
      '⚠️ Không tải được ảnh',
      WORD_EMOJI_FALLBACK[word.w] || '🖼️');
  }
}

function _applyRealImage(src, author, imgEl, skelEl) {
  skelEl.style.display = 'none';
  imgEl.src            = src;
  imgEl.alt            = '';
  imgEl.style.display  = 'block';
  imgEl.classList.add('loaded');
  // Credit
  const credit = document.getElementById('fc-img-credit');
  if (credit) credit.textContent = `📷 ${author} · Pexels`;
}

function _showImgBanner(skelEl, imgEl, html, emoji) {
  skelEl.style.display = 'none';
  imgEl.style.display  = 'none';
  const wrapEl = document.getElementById('fc-img-wrap');
  let ph = wrapEl.querySelector('.fc-img-placeholder');
  if (!ph) {
    ph = document.createElement('div');
    ph.className = 'fc-img-placeholder';
    wrapEl.insertBefore(ph, imgEl);
  }
  ph.style.display     = 'flex';
  ph.style.flexDirection = 'column';
  ph.style.gap         = '8px';
  ph.innerHTML         = `<span style="font-size:50px">${emoji}</span>
    <span style="font-size:11px;color:#666;text-align:center;line-height:1.5">${html}</span>`;
}

function flipCard() {
  if (cardFlipped) return;
  cardFlipped = true;
  document.getElementById('fc-mn').style.display = '';
  document.getElementById('fc-ex').style.display = '';
  document.getElementById('fc-hint').textContent = 'Bạn có nhớ từ này không?';
  document.getElementById('card-acts').style.display = 'flex';
}

async function rateCard(knew) {
  if (knew) {
    correctCount++;
  } else {
    // Tự động lưu từ chưa nhớ vào user_vocab
    const w = curLesson.words[cardIdx];
    await autoSaveToVocab(w);
  }
  document.getElementById('card-acts').style.display = 'none';
  document.getElementById('fc-next').style.display = 'block';
}

async function autoSaveToVocab(w) {
  if (!currentUser) return;
  try {
    const { error } = await sb.from('user_vocab').upsert(
      { user_id: currentUser.id, word: w.w, meaning: w.m, source: 'flashcard' },
      { onConflict: 'user_id,word', ignoreDuplicates: true }
    );
    if (!error) showToast(`📝 Đã lưu "${w.w}" vào từ vựng cần ôn`);
  } catch(e) {}
}

function showToast(msg) {
  let toast = document.getElementById('fc-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'fc-toast';
    toast.style.cssText = `
      position:fixed;bottom:90px;left:50%;transform:translateX(-50%) translateY(20px);
      background:#1a1814;color:#fff;padding:10px 20px;border-radius:99px;
      font-size:13px;font-weight:600;opacity:0;transition:all .3s;z-index:9999;
      white-space:nowrap;box-shadow:0 4px 20px rgba(0,0,0,.3)`;
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.style.opacity = '1';
  toast.style.transform = 'translateX(-50%) translateY(0)';
  clearTimeout(toast._t);
  toast._t = setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(-50%) translateY(10px)';
  }, 2500);
}

async function nextCard() {
  cardIdx++;
  if (cardIdx >= curLesson.words.length) {
    const pct = Math.round(correctCount / curLesson.words.length * 100);
    if (currentUser && currentProfile) {
      const newWords = (currentProfile.words_learned || 0) + correctCount;
      await sb.from('profiles').update({ words_learned: newWords }).eq('id', currentUser.id);
      currentProfile.words_learned = newWords;
    }
    showModal(pct >= 80 ? '🌟' : pct >= 50 ? '👍' : '💪', 'Hoàn thành!',
      `Bạn nhớ ${correctCount}/${curLesson.words.length} từ (${pct}%). ${pct >= 80 ? 'Tuyệt vời!' : 'Cố gắng thêm nhé!'}`,
      'Quay lại', () => { closeModal(); backToDash(); });
  } else showCard();
}

// ─── QUIZ ─────────────────────────────────────────────────────────────
let quizMode = 'mc'; // 'mc' | 'match'

function setQuizMode(mode) {
  quizMode = mode;
  ['mc','match','fill','dragdrop'].forEach(m => {
    const b = document.getElementById('qmode-' + m);
    if (b) b.classList.toggle('active', m === mode);
  });
  initQuiz();
  bgRefreshStudentMusic();
}

// ─── MATCH QUIZ ─────────────────────────────────────────────────────
let matchPairs = [], matchSelected = null, matchDone = 0, matchScore = 0;

function initMatchQuiz() {
  const lesson = LESSONS[Math.floor(Math.random() * LESSONS.length)];
  const pool = [...lesson.words].sort(() => Math.random() - 0.5).slice(0, 6);
  matchPairs = pool.map(w => ({ w: w.w, m: w.m, wId: 'mw_' + w.w, mId: 'mm_' + w.w }));
  matchSelected = null; matchDone = 0; matchScore = 0;
  renderMatchQuiz();
}

function renderMatchQuiz() {
  const el = document.getElementById('quiz-box');
  const words  = [...matchPairs].sort(() => Math.random() - 0.5);
  const meangs = [...matchPairs].sort(() => Math.random() - 0.5);
  el.innerHTML = `
    <div class="quiz-q" style="font-size:1.1rem">🔗 Nối từ tiếng Anh với nghĩa tiếng Việt</div>
    <div style="font-size:13px;color:#aaa;margin-bottom:14px">Nhấn một từ rồi nhấn nghĩa tương ứng</div>
    <div class="match-grid">
      <div class="match-col" id="match-words">
        ${words.map(p => `<button class="match-item" id="${p.wId}" onclick="matchClick('word','${p.wId}','${p.mId}')">${p.w}</button>`).join('')}
      </div>
      <div class="match-col" id="match-meangs">
        ${meangs.map(p => `<button class="match-item" id="${p.mId}" onclick="matchClick('mean','${p.mId}','${p.wId}')">${p.m}</button>`).join('')}
      </div>
    </div>
    <div class="quiz-fb" id="qfb"></div>
    <div class="match-score-row">Đã nối: <span id="match-done">0</span>/${matchPairs.length} · Điểm: <span id="match-score">0</span></div>`;
}

function matchClick(side, selfId, partnerId) {
  const selfEl = document.getElementById(selfId);
  if (!selfEl || selfEl.classList.contains('matched')) return;

  if (!matchSelected) {
    // Chọn lần đầu
    document.querySelectorAll('.match-item:not(.matched)').forEach(b => b.classList.remove('selected'));
    selfEl.classList.add('selected');
    matchSelected = { side, selfId, partnerId };
    return;
  }

  // Đã có lựa chọn trước — kiểm tra cặp
  const prev = matchSelected;
  matchSelected = null;
  document.querySelectorAll('.match-item').forEach(b => b.classList.remove('selected'));

  // Phải là 2 phía khác nhau và đúng partner
  const isMatch = (prev.side !== side) && (prev.partnerId === selfId) && (selfId === prev.partnerId);
  const prevEl = document.getElementById(prev.selfId);

  if (isMatch) {
    // ✅ Đúng cặp
    selfEl.classList.add('matched');
    prevEl.classList.add('matched');
    selfEl.style.pointerEvents = 'none';
    prevEl.style.pointerEvents = 'none';
    matchDone++; matchScore += 15;
    document.getElementById('match-done').textContent = matchDone;
    document.getElementById('match-score').textContent = matchScore;
    const fb = document.getElementById('qfb');
    fb.textContent = '✅ Chính xác! +15 điểm'; fb.className = 'quiz-fb show ok';
    setTimeout(() => { if (fb) fb.className = 'quiz-fb'; }, 1200);
    if (matchDone >= matchPairs.length) setTimeout(finishMatchQuiz, 900);
  } else {
    // ❌ Sai cặp — rung, không mất điểm
    [selfEl, prevEl].forEach(b => {
      if (!b) return;
      b.classList.add('wrong-flash');
      setTimeout(() => b.classList.remove('wrong-flash'), 400);
    });
    const fb = document.getElementById('qfb');
    fb.textContent = '❌ Chưa đúng! Thử lại nhé'; fb.className = 'quiz-fb show fail';
    setTimeout(() => { if (fb) fb.className = 'quiz-fb'; }, 1200);
  }
}

async function finishMatchQuiz() {
  if (currentUser && currentProfile) {
    const newScore = (currentProfile.quiz_score || 0) + matchScore;
    await sb.from('profiles').update({ quiz_score: newScore }).eq('id', currentUser.id);
    currentProfile.quiz_score = newScore;
    const el = document.getElementById('st-score');
    if (el) el.textContent = newScore;
  }
  if (currentAssignId) {
    await markAssignDone(currentAssignId, matchScore, {type:'match', done:matchDone, total:matchPairs.length, score:matchScore});
    document.getElementById('m-em').textContent = '🎉';
    document.getElementById('m-title').textContent = 'Hoàn thành bài tập!';
    const body = document.getElementById('m-body');
    body.innerHTML =
      '<div style="text-align:center">' +
        '<div style="font-size:56px;margin-bottom:8px">✅</div>' +
        '<div style="font-size:18px;font-weight:700;color:#065f46;margin-bottom:4px">Nối từ xuất sắc!</div>' +
        '<div style="font-size:14px;color:#666;margin-bottom:16px">Đúng ' + matchDone + '/' + matchPairs.length + ' cặp · ' + matchScore + ' điểm</div>' +
        '<div class="assign-done-badge" style="justify-content:center;font-size:14px;padding:8px 20px;margin:0 auto">✅ Bài tập đã hoàn thành</div>' +
      '</div>';
    const btn = document.getElementById('m-btn');
    btn.textContent = 'Về danh sách bài tập';
    btn.style.display = '';
    btn.onclick = function() {
      closeModal();
      const assignTab = document.querySelector('#st-tabs .tab[onclick*="assign"]');
      if (assignTab) stTab('assign', assignTab);
    };
    document.getElementById('modal-ov').classList.add('open');
    return;
  }
  showModal('🔗', 'Nối từ hoàn thành!',
    `Bạn nối đúng ${matchDone}/${matchPairs.length} cặp, đạt ${matchScore} điểm! ${matchScore >= 60 ? '🌟 Xuất sắc!' : '💪 Cố gắng hơn nhé!'}`,
    'Chơi lại', () => { closeModal(); initMatchQuiz(); });
}

function initQuiz() {
  if (quizMode === 'match') { initMatchQuiz(); return; }
  if (quizMode === 'fill') { initFillPractice(); return; }
  if (quizMode === 'dragdrop') { initDragDropPractice(); return; }
  const lesson = LESSONS[Math.floor(Math.random() * LESSONS.length)];
  quizWords = [...lesson.words].sort(() => Math.random() - 0.5);
  quizIdx = 0; quizScore = 0;
  renderQuiz();
}

function renderQuiz() {
  const el = document.getElementById('quiz-box');
  if (quizIdx >= quizWords.length) {
    finishQuiz(); return;
  }
  const w = quizWords[quizIdx];
  const allMn = LESSONS.flatMap(l => l.words).map(x => x.m);
  const wrong = allMn.filter(m => m !== w.m).sort(() => Math.random() - 0.5).slice(0, 3);
  const opts = [...wrong, w.m].sort(() => Math.random() - 0.5);
  el.innerHTML = `
    <div class="quiz-q">Từ "<strong>${w.w}</strong>" có nghĩa là gì?</div>
    <div class="quiz-sub">${w.p}</div>
    <div class="quiz-opts">
      ${opts.map(o => `<button class="quiz-opt ev-quiz-opt" data-opt="${o.replace(/"/g,'&quot;')}" data-ans="${w.m.replace(/"/g,'&quot;')}">${o}</button>`).join('')}
    </div>
    <div class="quiz-fb" id="qfb"></div>
    <div id="qnxt" style="display:none;text-align:right;margin-top:12px">
      <button class="btn btn-primary btn-sm" onclick="quizNext()">Câu tiếp →</button>
    </div>
    <div style="margin-top:14px;font-size:12px;color:#aaa">Câu ${quizIdx+1}/${quizWords.length} · Điểm: ${quizScore}</div>`;
}

function pickOpt(btn, chosen, correct) {
  document.querySelectorAll('.quiz-opt').forEach(b => { b.classList.add('dis'); b.onclick = null; });
  const fb = document.getElementById('qfb');
  if (chosen === correct) { btn.classList.add('cor'); fb.textContent = '✅ Chính xác!'; fb.className = 'quiz-fb show ok'; quizScore += 10; }
  else { btn.classList.add('wrg'); document.querySelectorAll('.quiz-opt').forEach(b => { if (b.textContent === correct) b.classList.add('cor'); }); fb.textContent = `❌ Chưa đúng. Nghĩa đúng: "${correct}"`; fb.className = 'quiz-fb show fail'; }
  document.getElementById('qnxt').style.display = 'block';
}

function quizNext() { quizIdx++; renderQuiz(); }

async function finishQuiz() {
  if (currentUser && currentProfile) {
    const newScore = (currentProfile.quiz_score || 0) + quizScore;
    await sb.from('profiles').update({ quiz_score: newScore }).eq('id', currentUser.id);
    currentProfile.quiz_score = newScore;
    document.getElementById('st-score').textContent = newScore;
  }
  if (currentAssignId) {
    await markAssignDone(currentAssignId, quizScore, {type:'quiz', score:quizScore});
    // Hiện modal hoàn thành bài tập
    document.getElementById('m-em').textContent = '🎉';
    document.getElementById('m-title').textContent = 'Hoàn thành bài tập!';
    const body = document.getElementById('m-body');
    body.innerHTML =
      '<div style="text-align:center">' +
        '<div style="font-size:56px;margin-bottom:8px">✅</div>' +
        '<div style="font-size:18px;font-weight:700;color:#065f46;margin-bottom:4px">Làm bài xuất sắc!</div>' +
        '<div style="font-size:14px;color:#666;margin-bottom:16px">Điểm Quiz: <strong>' + quizScore + '</strong> điểm</div>' +
        '<div class="assign-done-badge" style="justify-content:center;font-size:14px;padding:8px 20px;margin:0 auto">✅ Bài tập đã hoàn thành</div>' +
      '</div>';
    const btn = document.getElementById('m-btn');
    btn.textContent = 'Về danh sách bài tập';
    btn.style.display = '';
    btn.onclick = function() {
      closeModal();
      const assignTab = document.querySelector('#st-tabs .tab[onclick*="assign"]');
      if (assignTab) stTab('assign', assignTab);
    };
    document.getElementById('modal-ov').classList.add('open');
  } else {
    showModal('🎯', 'Quiz hoàn thành!', `Bạn đạt ${quizScore} điểm! ${quizScore >= 70 ? 'Xuất sắc!' : 'Cố gắng hơn nhé!'}`, 'Chơi lại', () => { closeModal(); initQuiz(); });
  }
}

// ─── ĐIỀN TỪ (Fill in the Blank) — tự luyện, dùng câu ví dụ có sẵn ─────
function buildBlankPool(count) {
  // Gom tất cả từ có câu ví dụ chứa đúng từ đó, từ mọi bài học
  const pool = [];
  LESSONS.forEach(l => l.words.forEach(w => {
    if (!w.e) return;
    const re = new RegExp('\\b' + w.w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i');
    if (re.test(w.e)) pool.push(w);
  }));
  return pool.sort(() => Math.random() - 0.5).slice(0, count);
}

function makeBlankSentence(w) {
  const re = new RegExp('\\b' + w.w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i');
  const m = w.e.match(re);
  const matched = m ? m[0] : w.w;
  const idx = w.e.search(re);
  return { before: w.e.slice(0, idx), after: w.e.slice(idx + matched.length), answer: w.w };
}

let fillPracticeItems = [];
function initFillPractice() {
  fillPracticeItems = buildBlankPool(8).map(w => ({ ...makeBlankSentence(w), meaning: w.m }));
  renderFillPractice();
}

function renderFillPractice() {
  const el = document.getElementById('quiz-box');
  if (fillPracticeItems.length === 0) {
    el.innerHTML = '<div class="empty"><div class="empty-icon">📭</div><p>Chưa có đủ dữ liệu câu ví dụ để luyện tập.</p></div>';
    return;
  }
  let html = '<div style="text-align:left">';
  html += '<div style="font-size:12px;color:#888;margin-bottom:14px;text-align:center">' + fillPracticeItems.length + ' câu · Gõ từ tiếng Anh còn thiếu vào chỗ trống</div>';
  fillPracticeItems.forEach((it, i) => {
    html += '<div id="fillp-row-' + i + '" style="background:#f0fdf4;border:1.5px solid #bbf7d0;border-radius:14px;padding:14px 16px;margin-bottom:10px">';
    html += '<div style="font-size:11px;color:#43a047;font-weight:700;margin-bottom:6px">Câu ' + (i+1) + ' · nghĩa: ' + escHtml(it.meaning) + '</div>';
    html += '<div style="font-size:14px;line-height:1.8">' + escHtml(it.before) +
      '<input type="text" id="fillp-inp-' + i + '" autocomplete="off" style="width:110px;border:none;border-bottom:2px solid #43a047;text-align:center;font-weight:700;font-size:14px;font-family:inherit;background:transparent;outline:none">' +
      escHtml(it.after) + '</div>';
    html += '</div>';
  });
  html += '<button id="fillp-check-btn" style="background:#43a047;color:#fff;border:none;border-radius:99px;padding:12px 28px;font-size:15px;font-weight:700;cursor:pointer;font-family:inherit;width:100%;margin-top:6px">✅ Kiểm tra</button>';
  html += '</div>';
  el.innerHTML = html;
  document.getElementById('fillp-check-btn').onclick = checkFillPractice;
}

function checkFillPractice() {
  let correct = 0;
  fillPracticeItems.forEach((it, i) => {
    const inp = document.getElementById('fillp-inp-' + i);
    const row = document.getElementById('fillp-row-' + i);
    const val = (inp.value || '').trim().toLowerCase();
    const ok = val === it.answer.toLowerCase();
    if (ok) correct++;
    inp.disabled = true;
    row.style.borderColor = ok ? '#43a047' : '#e53935';
    row.style.background = ok ? '#e8f5e9' : '#ffebee';
    if (!ok) {
      const hint = document.createElement('div');
      hint.style.cssText = 'font-size:12px;color:#e53935;margin-top:6px;font-weight:700';
      hint.textContent = '❌ Đáp án đúng: ' + it.answer;
      row.appendChild(hint);
    }
  });
  const score = Math.round(correct / fillPracticeItems.length * 100);
  quizScore = score;
  markStudiedToday('quiz');
  finishFillDragScore(correct, fillPracticeItems.length, 'fill');
}

// ─── KÉO THẢ CHỮ (Drag and Drop Text) — chọn từ trong ngân hàng, thả vào chỗ trống ─
let dragItems = [], dragBank = [], dragPlacements = {};
function initDragDropPractice() {
  dragItems = buildBlankPool(6).map(w => ({ ...makeBlankSentence(w), meaning: w.m }));
  dragBank = dragItems.map(it => it.answer).sort(() => Math.random() - 0.5);
  dragPlacements = {};
  dragSlotToBi = {};
  dragBankUsedIdx = new Set();
  dragSelectedChipIdx = null;
  renderDragDropPractice();
}

function renderDragDropPractice() {
  const el = document.getElementById('quiz-box');
  if (dragItems.length === 0) {
    el.innerHTML = '<div class="empty"><div class="empty-icon">📭</div><p>Chưa có đủ dữ liệu câu ví dụ để luyện tập.</p></div>';
    return;
  }
  let html = '<div style="text-align:left">';
  html += '<div style="font-size:12px;color:#888;margin-bottom:10px;text-align:center">Chạm vào 1 từ bên dưới rồi chạm vào ô trống thích hợp để thả từ vào</div>';
  dragItems.forEach((it, i) => {
    const placed = dragPlacements[i];
    html += '<div style="background:#f5f6ff;border:1.5px solid #c7d2fe;border-radius:14px;padding:14px 16px;margin-bottom:10px">';
    html += '<div style="font-size:11px;color:#6366f1;font-weight:700;margin-bottom:6px">Câu ' + (i+1) + ' · nghĩa: ' + escHtml(it.meaning) + '</div>';
    html += '<div style="font-size:14px;line-height:2">' + escHtml(it.before) +
      '<span class="dragp-slot" data-slot="' + i + '" onclick="dragSlotClick(' + i + ')" ' +
        'style="display:inline-block;min-width:80px;padding:4px 10px;border:2px dashed #a5b4fc;border-radius:8px;text-align:center;font-weight:700;color:#4338ca;cursor:pointer;background:' + (placed?'#e0e7ff':'#fff') + '">' +
        (placed ? escHtml(placed) : '　') +
      '</span>' + escHtml(it.after) + '</div>';
    html += '</div>';
  });
  html += '<div style="font-size:11px;color:#888;font-weight:700;text-transform:uppercase;margin:14px 0 8px">Ngân hàng từ</div>';
  html += '<div id="drag-bank" style="display:flex;flex-wrap:wrap;gap:8px;min-height:40px">';
  // Render bank theo index để tránh nhầm khi có từ trùng nhau
  dragBank.forEach((word, bi) => {
    const isUsed = dragBankUsedIdx.has(bi);
    if (isUsed) return;
    html += '<div class="drag-chip" data-bi="' + bi + '" onclick="dragChipClick(' + bi + ')" ' +
      'style="padding:8px 16px;border-radius:99px;background:#eef2ff;border:2px solid #c7d2fe;font-weight:700;color:#4338ca;cursor:pointer;font-size:13px">' + escHtml(word) + '</div>';
  });
  html += '</div>';
  html += '<button id="dragp-check-btn" style="background:#6366f1;color:#fff;border:none;border-radius:99px;padding:12px 28px;font-size:15px;font-weight:700;cursor:pointer;font-family:inherit;width:100%;margin-top:16px">✅ Kiểm tra</button>';
  html += '</div>';
  el.innerHTML = html;
  document.getElementById('dragp-check-btn').onclick = checkDragDropPractice;
}

let dragSelectedChipIdx = null;
let dragBankUsedIdx = new Set();
let dragSlotToBi = {};

function dragChipClick(bi) {
  dragSelectedChipIdx = (dragSelectedChipIdx === bi) ? null : bi;
  document.querySelectorAll('.drag-chip').forEach(c => {
    c.style.outline = (parseInt(c.dataset.bi,10) === dragSelectedChipIdx) ? '3px solid #6366f1' : 'none';
  });
}

function dragSlotClick(slotIdx) {
  // Nếu ô đã có từ, chạm lại để trả từ về ngân hàng
  if (dragPlacements[slotIdx] !== undefined) {
    const prevBi = dragSlotToBi[slotIdx];
    delete dragPlacements[slotIdx];
    delete dragSlotToBi[slotIdx];
    if (prevBi !== undefined) dragBankUsedIdx.delete(prevBi);
    renderDragDropPractice();
    return;
  }
  if (dragSelectedChipIdx === null) return;
  const word = dragBank[dragSelectedChipIdx];
  dragPlacements[slotIdx] = word;
  dragSlotToBi[slotIdx] = dragSelectedChipIdx;
  dragBankUsedIdx.add(dragSelectedChipIdx);
  dragSelectedChipIdx = null;
  renderDragDropPractice();
}

function checkDragDropPractice() {
  let correct = 0;
  dragItems.forEach((it, i) => {
    const val = dragPlacements[i];
    if (val && val.toLowerCase() === it.answer.toLowerCase()) correct++;
  });
  const score = Math.round(correct / dragItems.length * 100);
  quizScore = score;
  markStudiedToday('quiz');
  finishFillDragScore(correct, dragItems.length, 'dragdrop');
}

// Hiện kết quả chung cho cả 2 chế độ Điền từ / Kéo thả
async function finishFillDragScore(correct, total, mode) {
  if (currentUser && currentProfile) {
    const newScore = (currentProfile.quiz_score || 0) + quizScore;
    await sb.from('profiles').update({ quiz_score: newScore }).eq('id', currentUser.id);
    currentProfile.quiz_score = newScore;
    const scoreEl = document.getElementById('st-score');
    if (scoreEl) scoreEl.textContent = newScore;
  }
  setTimeout(() => {
    showModal(
      correct === total ? '🌟' : correct >= total/2 ? '👍' : '💪',
      'Kết quả',
      `Đúng ${correct}/${total} câu · ${quizScore} điểm`,
      'Làm lại',
      () => { closeModal(); if (mode === 'fill') initFillPractice(); else initDragDropPractice(); }
    );
  }, 400);
}

// ─── TYPING ───────────────────────────────────────────────────────────
function initTyping() {
  newSentence();
  document.getElementById('type-inp').oninput = onType;
}

function newSentence() {
  typeSentence = SENTENCES[Math.floor(Math.random() * SENTENCES.length)];
  typeStart = null; typeDone = false; clearInterval(typeTimer);
  document.getElementById('type-inp').value = '';
  ['t-wpm','t-acc','t-time'].forEach(id => document.getElementById(id).textContent = id === 't-acc' ? '100%' : id === 't-time' ? '0s' : '0');
  renderTyping('');
}

function renderTyping(typed) {
  document.getElementById('type-disp').innerHTML = typeSentence.split('').map((ch, i) => {
    let cls = '';
    if (i < typed.length) cls = typed[i] === ch ? 'ch-ok' : 'ch-err';
    else if (i === typed.length) cls = 'ch-cur';
    return `<span class="${cls}">${ch === ' ' ? '&nbsp;' : ch}</span>`;
  }).join('');
}

function onType(e) {
  if (typeDone) return;
  const typed = e.target.value;
  if (!typeStart && typed.length > 0) { typeStart = Date.now(); typeTimer = setInterval(updateTypeStats, 200); }
  renderTyping(typed);
  if (typed === typeSentence) { typeDone = true; clearInterval(typeTimer); updateTypeStats(true); }
}

function updateTypeStats() {
  if (!typeStart) return;
  const sec = (Date.now() - typeStart) / 1000;
  const typed = document.getElementById('type-inp').value;
  const wpm = Math.round(typeSentence.split(' ').length / sec * 60);
  let ok = 0; for (let i = 0; i < typed.length; i++) if (typed[i] === typeSentence[i]) ok++;
  const acc = typed.length > 0 ? Math.round(ok / typed.length * 100) : 100;
  document.getElementById('t-wpm').textContent = isFinite(wpm) ? wpm : 0;
  document.getElementById('t-acc').textContent = acc + '%';
  document.getElementById('t-time').textContent = Math.round(sec) + 's';
}

async function saveWPM() {
  const wpm = parseInt(document.getElementById('t-wpm').textContent) || 0;
  if (wpm === 0) { showModal('⚠️', 'Chưa có điểm', 'Hãy hoàn thành một câu trước!', 'OK', closeModal); return; }
  if (currentUser && currentProfile && wpm > (currentProfile.best_wpm || 0)) {
    await sb.from('profiles').update({ best_wpm: wpm }).eq('id', currentUser.id);
    currentProfile.best_wpm = wpm;
    document.getElementById('st-wpm').textContent = wpm;
    showModal('⌨️', 'Kỷ lục mới!', `${wpm} WPM — Kỷ lục cá nhân mới!`, 'OK', closeModal);
  } else {
    showModal('✅', 'Điểm đã ghi nhận!', `${wpm} WPM. Kỷ lục: ${currentProfile?.best_wpm || 0} WPM`, 'OK', closeModal);
  }
}

// ─── TEACHER DASH ─────────────────────────────────────────────────────
function showAssignFill(a) {
  const items = a.fill_data || [];
  let correct = 0;

  // Xây dựng giao diện từng từ
  let html = '<div style="padding:4px 0">';
  html += '<div style="font-size:12px;color:#888;margin-bottom:14px;text-align:center">' + items.length + ' từ · Điền 1 ký tự còn thiếu vào ô trống</div>';

  items.forEach((item, i) => {
    // item.display = "C_T", item.answer = "A", item.word = "CAT"
    const display = item.display || '';
    const letters = display.split('');
    html += '<div style="background:#f8faff;border:1.5px solid #c7d2fe;border-radius:14px;padding:14px 16px;margin-bottom:10px;display:flex;align-items:center;gap:12px">';
    html += '<span style="font-size:11px;font-weight:700;color:#6366f1;min-width:18px">' + (i+1) + '.</span>';
    // Hiển thị từng chữ cái, ô trống thay bằng input
    html += '<div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">';
    letters.forEach((ch, ci) => {
      if (ch === '_') {
        html += '<input id="fill-inp-'+i+'" maxlength="1" autocomplete="off" spellcheck="false"' +
          ' style="width:44px;height:48px;border:2.5px solid #1565c0;border-radius:10px;text-align:center;font-size:22px;font-weight:900;font-family:monospace;color:#1565c0;background:#eff6ff;outline:none;text-transform:uppercase"' +
          ' oninput="this.value=this.value.toUpperCase().slice(-1)">';
      } else {
        html += '<div style="width:36px;height:48px;background:#e8eaf6;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:900;font-family:monospace;color:#333">' + ch + '</div>';
      }
    });
    html += '</div>';
    html += '</div>';
  });

  html += '<button id="fill-check-btn" style="background:#1565c0;color:#fff;border:none;border-radius:99px;padding:12px 28px;font-size:15px;font-weight:700;cursor:pointer;font-family:inherit;width:100%;margin-top:6px">✅ Kiểm tra đáp án</button>';
  html += '</div>';

  document.getElementById('m-em').textContent = '✏️';
  document.getElementById('m-title').textContent = a.title;
  const bodyEl = document.getElementById('m-body');
  bodyEl.innerHTML = html;
  const mainBtn = document.getElementById('m-btn');
  if (mainBtn) mainBtn.style.display = 'none';
  document.getElementById('modal-ov').classList.add('open');

  // Focus ô đầu tiên
  const first = document.getElementById('fill-inp-0');
  if (first) setTimeout(() => first.focus(), 200);

  // Kiểm tra đáp án
  document.getElementById('fill-check-btn').onclick = function() {
    correct = 0;
    const detailItems = [];
    items.forEach((item, i) => {
      const inp = document.getElementById('fill-inp-' + i);
      if (!inp) return;
      const val = inp.value.trim().toUpperCase();
      const ans = (item.answer || '').toUpperCase();
      const ok = val === ans;
      inp.style.transition = 'all .2s';
      if (ok) {
        inp.style.background = '#e8f5e9';
        inp.style.borderColor = '#43a047';
        inp.style.color = '#1b5e20';
        correct++;
      } else {
        inp.style.background = '#ffebee';
        inp.style.borderColor = '#e53935';
        inp.style.color = '#b71c1c';
        inp.style.animation = 'qshake .3s ease';
        // Hiện đáp án đúng bên cạnh nếu sai
        inp.title = 'Đáp án: ' + ans;
      }
      detailItems.push({ label: item.word || item.display, correct: ok, given: val || '(bỏ trống)', answer: ans });
    });
    const score = Math.round(correct / items.length * 100);
    setTimeout(() => {
      document.getElementById('m-em').textContent = correct === items.length ? '🎉' : '📝';
      document.getElementById('m-title').textContent = 'Kết quả';
      bodyEl.innerHTML =
        '<div style="text-align:center">' +
          '<div style="font-size:56px;margin-bottom:10px">' + (correct===items.length ? '🌟' : correct >= items.length/2 ? '👍' : '💪') + '</div>' +
          '<div style="font-size:32px;font-weight:900;color:'+(score>=80?'#16a34a':score>=50?'#d97706':'#e53935')+';margin-bottom:6px">' + correct + '/' + items.length + '</div>' +
          '<div style="font-size:14px;color:#666;margin-bottom:6px">Đúng ' + correct + ' từ · ' + score + ' điểm</div>' +
          // Hiện lại từng từ với đáp án
          '<div style="margin:12px 0;text-align:left">' +
          items.map((item,i) => {
            const inp = document.getElementById('fill-inp-'+i);
            const val = inp ? inp.value.toUpperCase() : '';
            const ans = (item.answer||'').toUpperCase();
            const ok  = val === ans;
            return '<div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #f0f0f0">' +
              '<span style="font-size:18px">' + (ok?'✅':'❌') + '</span>' +
              '<span style="font-family:monospace;font-size:15px;font-weight:700;letter-spacing:3px">' + (item.word||item.display) + '</span>' +
              (ok ? '' : '<span style="font-size:12px;color:#e53935">→ Bạn nhập: <b>' + (val||'?') + '</b> · Đúng: <b>' + ans + '</b></span>') +
            '</div>';
          }).join('') +
          '</div>' +
          '<div class="assign-done-badge" style="justify-content:center;font-size:14px;padding:8px 20px;margin:0 auto">✅ Bài tập đã hoàn thành</div>' +
        '</div>';
      mainBtn.textContent = 'Về danh sách bài tập'; mainBtn.style.display = '';
      mainBtn.onclick = function() {
        closeModal();
        const t = document.querySelector('#st-tabs .tab[onclick*="assign"]');
        if (t) stTab('assign', t);
      };
      markAssignDone(currentAssignId, score, {type:'fill', correct, total:items.length, items:detailItems});
    }, 600);
  };
}

// Match2 student view
function showAssignMatch2(a) {
  const pairs  = a.match2_data || [];
  let selWord  = null;
  let selMean  = null;
  let matched  = 0;

  function renderMatch2() {
    const shuffledMeans = [...pairs].sort(() => Math.random() - 0.5);
    let html = '<div style="padding:4px 0">';
    html += '<div style="font-size:12px;color:#aaa;margin-bottom:12px;text-align:center">Nhấn 1 từ tiếng Anh rồi nhấn nghĩa tương ứng</div>';
    html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">';
    // Cột từ tiếng Anh
    html += '<div id="m2-words">';
    pairs.forEach((p,i) => {
      html += '<div class="match2-word" id="m2w-'+i+'" data-idx="'+i+'" onclick="m2ClickWord('+i+')">'+p.word+'</div>';
    });
    html += '</div>';
    // Cột nghĩa (xáo trộn)
    html += '<div id="m2-means">';
    shuffledMeans.forEach((p,i) => {
      const origIdx = pairs.findIndex(x => x.word === p.word && x.meaning === p.meaning);
      html += '<div class="match2-word" id="m2m-'+i+'" data-orig="'+origIdx+'" onclick="m2ClickMean('+i+','+origIdx+')">'+p.meaning+'</div>';
    });
    html += '</div>';
    html += '</div>';
    html += '<div id="m2-score" style="text-align:right;font-size:12px;color:#aaa;margin-top:8px">Đã nối: 0/' + pairs.length + '</div>';
    html += '</div>';
    return html;
  }

  window.m2ClickWord = function(idx) {
    if (document.getElementById('m2w-'+idx).classList.contains('matched')) return;
    document.querySelectorAll('#m2-words .match2-word').forEach(el => el.classList.remove('selected'));
    document.getElementById('m2w-'+idx).classList.add('selected');
    selWord = idx;
    if (selMean !== null) tryMatch2();
  };

  window.m2ClickMean = function(dispIdx, origIdx) {
    if (document.getElementById('m2m-'+dispIdx).classList.contains('matched')) return;
    document.querySelectorAll('#m2-means .match2-word').forEach(el => el.classList.remove('selected'));
    document.getElementById('m2m-'+dispIdx).classList.add('selected');
    selMean = { dispIdx, origIdx };
    if (selWord !== null) tryMatch2();
  };

  window.tryMatch2 = function() {
    if (selWord === null || selMean === null) return;
    const wEl = document.getElementById('m2w-'+selWord);
    const mEl = document.getElementById('m2m-'+selMean.dispIdx);
    if (selWord === selMean.origIdx) {
      // Đúng
      wEl.classList.remove('selected'); wEl.classList.add('matched');
      mEl.classList.remove('selected'); mEl.classList.add('matched');
      matched++;
      const scoreEl = document.getElementById('m2-score');
      if (scoreEl) scoreEl.textContent = 'Đã nối: ' + matched + '/' + pairs.length;
      if (matched >= pairs.length) {
        const score = 100;
        setTimeout(() => {
          document.getElementById('m-em').textContent = '🎉';
          document.getElementById('m-title').textContent = 'Hoàn thành!';
          const body = document.getElementById('m-body');
          body.innerHTML =
            '<div style="text-align:center">' +
              '<div style="font-size:56px;margin-bottom:8px">🌟</div>' +
              '<div style="font-size:22px;font-weight:900;color:#16a34a;margin-bottom:6px">Nối đúng tất cả!</div>' +
              '<div style="font-size:14px;color:#666;margin-bottom:16px">' + matched + '/' + pairs.length + ' cặp · 100 điểm</div>' +
              '<div class="assign-done-badge" style="justify-content:center;font-size:14px;padding:8px 20px;margin:0 auto">✅ Bài tập đã hoàn thành</div>' +
            '</div>';
          const btn = document.getElementById('m-btn');
          btn.textContent = 'Về danh sách bài tập'; btn.style.display = '';
          btn.onclick = function() {
            closeModal();
            const t = document.querySelector('#st-tabs .tab[onclick*="assign"]');
            if (t) stTab('assign', t);
          };
          markAssignDone(currentAssignId, score, {type:'match2', done:matched, total:pairs.length});
        }, 600);
      }
    } else {
      // Sai
      wEl.classList.add('wrong-flash'); mEl.classList.add('wrong-flash');
      setTimeout(() => {
        wEl.classList.remove('wrong-flash','selected');
        mEl.classList.remove('wrong-flash','selected');
      }, 400);
    }
    selWord = null; selMean = null;
  };

  document.getElementById('m-em').textContent = '🔗';
  document.getElementById('m-title').textContent = a.title;
  document.getElementById('m-body').innerHTML = renderMatch2();
  const btn = document.getElementById('m-btn');
  if (btn) btn.style.display = 'none';
  document.getElementById('modal-ov').classList.add('open');
}

// Quiz trắc nghiệm student view (câu hỏi được lưu ở cột fill_data)
function showAssignQuiz(a) {
  const questions = a.fill_data || [];

  let html = '<div style="padding:4px 0;text-align:left">';
  html += '<div style="font-size:12px;color:#888;margin-bottom:14px;text-align:center">' + questions.length + ' câu hỏi · Chọn đáp án đúng cho từng câu</div>';
  questions.forEach((q, qi) => {
    html += '<div style="background:#f5f6ff;border:1.5px solid #c7d2fe;border-radius:14px;padding:14px 16px;margin-bottom:10px">';
    html += '<div style="font-size:14px;font-weight:700;color:#333;margin-bottom:10px">' + (qi+1) + '. ' + escHtml(q.question) + '</div>';
    (q.options||[]).forEach((opt, oi) => {
      html += '<label id="quiz-opt-label-'+qi+'-'+oi+'" style="display:flex;align-items:center;gap:8px;padding:8px 12px;border:1.5px solid #e0e0e0;border-radius:10px;margin-bottom:6px;cursor:pointer;background:#fff">' +
        '<input type="radio" name="quiz-ans-'+qi+'" value="'+oi+'">' +
        '<span style="font-size:13px">' + escHtml(opt) + '</span>' +
      '</label>';
    });
    html += '</div>';
  });
  html += '<button id="quiz-check-btn" style="background:#6366f1;color:#fff;border:none;border-radius:99px;padding:12px 28px;font-size:15px;font-weight:700;cursor:pointer;font-family:inherit;width:100%;margin-top:6px">✅ Nộp bài</button>';
  html += '</div>';

  document.getElementById('m-em').textContent = '🧠';
  document.getElementById('m-title').textContent = a.title;
  const bodyEl = document.getElementById('m-body');
  bodyEl.innerHTML = html;
  const mainBtn = document.getElementById('m-btn');
  if (mainBtn) mainBtn.style.display = 'none';
  document.getElementById('modal-ov').classList.add('open');

  document.getElementById('quiz-check-btn').onclick = function() {
    let correct = 0;
    const detailItems = [];
    questions.forEach((q, qi) => {
      const checked = document.querySelector('input[name="quiz-ans-'+qi+'"]:checked');
      const chosen = checked ? parseInt(checked.value, 10) : -1;
      const isOk = chosen === q.correct;
      if (isOk) correct++;
      (q.options||[]).forEach((opt, oi) => {
        const lbl = document.getElementById('quiz-opt-label-'+qi+'-'+oi);
        if (!lbl) return;
        if (oi === q.correct) { lbl.style.borderColor = '#43a047'; lbl.style.background = '#e8f5e9'; }
        else if (oi === chosen) { lbl.style.borderColor = '#e53935'; lbl.style.background = '#ffebee'; }
      });
      detailItems.push({
        label: q.question,
        correct: isOk,
        given: chosen >= 0 ? (q.options[chosen] || '') : '(không chọn)',
        answer: q.options[q.correct] || ''
      });
    });
    const score = questions.length ? Math.round(correct / questions.length * 100) : 0;
    setTimeout(() => {
      document.getElementById('m-em').textContent = correct === questions.length ? '🎉' : '📝';
      document.getElementById('m-title').textContent = 'Kết quả';
      bodyEl.innerHTML =
        '<div style="text-align:center">' +
          '<div style="font-size:56px;margin-bottom:10px">' + (correct===questions.length ? '🌟' : correct >= questions.length/2 ? '👍' : '💪') + '</div>' +
          '<div style="font-size:32px;font-weight:900;color:'+(score>=80?'#16a34a':score>=50?'#d97706':'#e53935')+';margin-bottom:6px">' + correct + '/' + questions.length + '</div>' +
          '<div style="font-size:14px;color:#666;margin-bottom:6px">Đúng ' + correct + ' câu · ' + score + ' điểm</div>' +
          '<div class="assign-done-badge" style="justify-content:center;font-size:14px;padding:8px 20px;margin:0 auto">✅ Bài tập đã hoàn thành</div>' +
        '</div>';
      mainBtn.textContent = 'Về danh sách bài tập'; mainBtn.style.display = '';
      mainBtn.onclick = function() {
        closeModal();
        const t = document.querySelector('#st-tabs .tab[onclick*="assign"]');
        if (t) stTab('assign', t);
      };
      markAssignDone(currentAssignId, score, {type:'quiz', correct, total:questions.length, items:detailItems});
    }, 600);
  };
}

async function loadLeaderboard() {
  const el = document.getElementById('lb-cont');
  const { data } = await sb.from('profiles').select('full_name,quiz_score,words_learned,best_wpm,role').eq('role','student').order('quiz_score', { ascending: false }).limit(20);
  if (!data || data.length === 0) { el.innerHTML = '<div class="empty"><div class="empty-icon">🏆</div><p>Chưa có dữ liệu xếp hạng</p></div>'; return; }
  const myName = currentProfile?.full_name;
  el.innerHTML = `<div class="lb-hdr">🏆 Xếp hạng theo điểm quiz</div>` + data.map((p, i) => `
    <div class="lb-row ${p.full_name === myName ? 'mine' : ''}">
      <div class="lb-rank">${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : i + 1}</div>
      <div>
        <div style="font-weight:500">${p.full_name || 'Ẩn danh'} ${p.full_name === myName ? '(Bạn)' : ''}</div>
        <div style="font-size:11px;color:#aaa">${p.words_learned || 0} từ · ${p.best_wpm || 0} WPM</div>
      </div>
      <div class="lb-score">${p.quiz_score || 0}</div>
    </div>`).join('');
}

// ─── VOCAB ────────────────────────────────────────────────────────────
async function loadVocab() {
  if (!currentUser) return;
  const el = document.getElementById('vocab-list');
  el.innerHTML = '<div class="empty"><div class="empty-icon">⏳</div><p>Đang tải...</p></div>';
  const { data } = await sb.from('user_vocab')
    .select('*')
    .eq('user_id', currentUser.id)
    .order('created_at', { ascending: false });
  if (!data || data.length === 0) {
    el.innerHTML = '<div class="empty"><div class="empty-icon">📝</div><p>Chưa có từ nào. Học flashcard và nhấn "Chưa nhớ" để tự động lưu!</p></div>';
    return;
  }
  // Từ có source='flashcard' (chưa nhớ) hiện lên đầu với badge đặc biệt
  const review = data.filter(v => v.source === 'flashcard');
  const manual = data.filter(v => v.source !== 'flashcard');
  const sorted = [...review, ...manual];

  el.innerHTML = (review.length ? `
    <div style="font-size:12px;font-weight:700;color:var(--red);margin-bottom:8px;display:flex;align-items:center;gap:6px">
      🔁 CẦN ÔN LẠI <span style="background:var(--red);color:#fff;border-radius:99px;padding:1px 8px">${review.length}</span>
    </div>` : '') +
  sorted.map(v => `
    <div class="vocab-item" id="vi-${v.id}" style="${v.source==='flashcard'?'border-color:#fca5a5;background:#fff5f5':''}">
      <div style="display:flex;flex-direction:column;gap:2px;flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:6px">
          <div class="vocab-word">${v.word}</div>
          ${v.source==='flashcard'
            ? '<span style="font-size:10px;background:#ffebee;color:var(--red);padding:1px 7px;border-radius:99px;font-weight:700;flex-shrink:0">Cần ôn</span>'
            : ''}
        </div>
        <div class="vocab-mn">${v.meaning}</div>
      </div>
      <div style="display:flex;gap:4px;flex-shrink:0">
        ${v.source==='flashcard'
          ? `<button class="vocab-del" style="color:var(--acc)" title="Đã thuộc" onclick="markLearned('${v.id}')">✓</button>`
          : ''}
        <button class="vocab-del" onclick="delVocab('${v.id}')">✕</button>
      </div>
    </div>`).join('');
}

async function markLearned(id) {
  await sb.from('user_vocab').update({ source: 'learned' }).eq('id', id);
  const el = document.getElementById(`vi-${id}`);
  if (el) {
    el.style.transition = 'opacity .3s';
    el.style.opacity = '0';
    setTimeout(() => loadVocab(), 350);
  }
}

async function addVocab() {
  const word = document.getElementById('v-word').value.trim();
  const meaning = document.getElementById('v-mean').value.trim();
  if (!word || !meaning || !currentUser) return;
  await sb.from('user_vocab').insert({ user_id: currentUser.id, word, meaning, source: 'manual' });
  document.getElementById('v-word').value = '';
  document.getElementById('v-mean').value = '';
  loadVocab();
}

async function delVocab(id) {
  await sb.from('user_vocab').delete().eq('id', id);
  loadVocab();
}

// ══════════════════════════════════════════════════════════════════════
// ── 1. TEXT-TO-SPEECH & PRONUNCIATION ──────────────────────────────────
// ══════════════════════════════════════════════════════════════════════
let ttsUtterance = null;
let micRecog = null;
let isSpeaking = false;
let isRecording = false;

function speakWord() {
  if (!window.speechSynthesis) { alert('Trình duyệt không hỗ trợ TTS.'); return; }
  const word = document.getElementById('fc-word')?.textContent?.trim();
  if (!word || word === '—') return;
  if (isSpeaking) { window.speechSynthesis.cancel(); return; }
  ttsUtterance = new SpeechSynthesisUtterance(word);
  ttsUtterance.lang = 'en-US';
  ttsUtterance.rate = 0.85;
  ttsUtterance.pitch = 1;
  // Prefer a natural English voice
  const voices = window.speechSynthesis.getVoices();
  const en = voices.find(v => v.lang === 'en-US' && v.name.toLowerCase().includes('female'))
          || voices.find(v => v.lang === 'en-US')
          || voices.find(v => v.lang.startsWith('en'));
  if (en) ttsUtterance.voice = en;

  const btn = document.getElementById('tts-btn');
  ttsUtterance.onstart = () => { isSpeaking = true; btn.classList.add('speaking'); btn.textContent = '⏹ Dừng'; };
  ttsUtterance.onend = ttsUtterance.onerror = () => { isSpeaking = false; btn.classList.remove('speaking'); btn.innerHTML = '🔊 Nghe'; };
  window.speechSynthesis.speak(ttsUtterance);
}

// Auto-speak when card changes
function autoSpeak() {
  if (window.speechSynthesis) {
    window.speechSynthesis.cancel();
    setTimeout(speakWord, 300);
  }
}

function startPronounce() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    document.getElementById('mic-result-wrap').style.display = '';
    document.getElementById('mic-result-text').textContent = '❌ Trình duyệt không hỗ trợ nhận diện giọng nói. Thử dùng Chrome.';
    return;
  }
  if (isRecording) { micRecog?.stop(); return; }

  const word = document.getElementById('fc-word')?.textContent?.trim().toLowerCase();
  const btn = document.getElementById('mic-btn');
  const resultWrap = document.getElementById('mic-result-wrap');
  const resultText = document.getElementById('mic-result-text');
  const scoreEl = document.getElementById('mic-score-el');

  resultWrap.style.display = '';
  scoreEl.style.display = 'none';
  resultText.textContent = '🎙️ Đang nghe... Đọc to: "' + document.getElementById('fc-word').textContent + '"';

  micRecog = new SpeechRecognition();
  micRecog.lang = 'en-US';
  micRecog.interimResults = false;
  micRecog.maxAlternatives = 3;

  micRecog.onstart = () => { isRecording = true; btn.classList.add('recording'); btn.innerHTML = '⏹ Dừng'; };
  micRecog.onend = () => { isRecording = false; btn.classList.remove('recording'); btn.innerHTML = '🎙️ Luyện phát âm'; };

  micRecog.onresult = (e) => {
    const transcripts = Array.from(e.results[0]).map(r => r.transcript.toLowerCase().trim());
    resultText.textContent = '🗣 Bạn đọc: "' + transcripts[0] + '"';
    // Score: check if any alternative matches
    const matched = transcripts.some(t => t === word || t.includes(word) || word.includes(t));
    const similarity = calcSimilarity(transcripts[0], word);
    let cls, msg;
    if (similarity >= 0.85) { cls = 'great'; msg = '🌟 Xuất sắc! Phát âm chuẩn!'; }
    else if (similarity >= 0.6) { cls = 'ok'; msg = '👍 Khá tốt! Luyện thêm nhé.'; }
    else { cls = 'bad'; msg = '💪 Cần cải thiện. Nhấn 🔊 nghe lại và thử!'; }
    scoreEl.style.display = '';
    scoreEl.innerHTML = `<span class="mic-score ${cls}">${msg}</span>`;
  };

  micRecog.onerror = (e) => {
    resultText.textContent = e.error === 'not-allowed'
      ? '❌ Vui lòng cho phép truy cập microphone trong trình duyệt.'
      : '❌ Lỗi nhận dạng: ' + e.error;
  };

  micRecog.start();
}

// Simple string similarity (Levenshtein ratio)
function calcSimilarity(a, b) {
  if (!a || !b) return 0;
  a = a.toLowerCase(); b = b.toLowerCase();
  if (a === b) return 1;
  const m = a.length, n = b.length;
  const dp = Array.from({length: m+1}, (_, i) => Array.from({length: n+1}, (_, j) => i === 0 ? j : j === 0 ? i : 0));
  for (let i = 1; i <= m; i++) for (let j = 1; j <= n; j++)
    dp[i][j] = a[i-1] === b[j-1] ? dp[i-1][j-1] : 1 + Math.min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1]);
  return 1 - dp[m][n] / Math.max(m, n);
}

// Reset mic/dict state when showing new card
const _origShowCard = showCard;
showCard = function() {
  _origShowCard();
  // Reset mic
  if (micRecog) { try { micRecog.stop(); } catch(e){} }
  isRecording = false;
  const micBtn = document.getElementById('mic-btn');
  if (micBtn) { micBtn.classList.remove('recording'); micBtn.innerHTML = '🎙️ Luyện phát âm'; }
  document.getElementById('mic-result-wrap').style.display = 'none';
  // Reset dict
  document.getElementById('dict-result-wrap').style.display = 'none';
  // Reset speaking
  if (window.speechSynthesis) window.speechSynthesis.cancel();
  isSpeaking = false;
  const ttsBtn = document.getElementById('tts-btn');
  if (ttsBtn) { ttsBtn.classList.remove('speaking'); ttsBtn.innerHTML = '🔊 Nghe'; }
};

// ══════════════════════════════════════════════════════════════════════
// ── 2. DICTIONARY LOOKUP (Free Dictionary API) ─────────────────────────
// ══════════════════════════════════════════════════════════════════════
let dictCurrentWord = '';
let dictCurrentMeaning = '';

async function lookupDict() {
  const word = document.getElementById('fc-word')?.textContent?.trim();
  const meaning = document.getElementById('fc-mn')?.textContent?.trim();
  if (!word || word === '—') return;
  dictCurrentWord = word;
  dictCurrentMeaning = meaning;

  const wrap = document.getElementById('dict-result-wrap');
  const body = document.getElementById('dict-body');
  const titleEl = document.getElementById('dict-word-title');
  wrap.style.display = '';
  titleEl.textContent = word;
  body.innerHTML = '<div class="dict-loading">⏳ Đang tra từ điển...</div>';

  try {
    const res = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`);
    if (!res.ok) throw new Error('not found');
    const data = await res.json();
    const entry = data[0];
    const phonetic = entry.phonetics?.find(p => p.text)?.text || entry.phonetic || '';
    const audio = entry.phonetics?.find(p => p.audio)?.audio || '';

    let html = '';
    if (phonetic) html += `<div class="dict-phonetic">${phonetic}
      ${audio ? `<button onclick="playAudio('${audio}')" style="background:none;border:none;cursor:pointer;font-size:14px;vertical-align:middle" title="Nghe">🔊</button>` : ''}
    </div>`;

    (entry.meanings || []).slice(0, 3).forEach(m => {
      html += `<div class="dict-meaning-row">
        <span class="dict-pos">${m.partOfSpeech}</span>`;
      (m.definitions || []).slice(0, 2).forEach(d => {
        html += `<div class="dict-def">• ${d.definition}</div>`;
        if (d.example) html += `<div class="dict-ex-d">"${d.example}"</div>`;
      });
      html += '</div>';
    });

    const synonyms = (entry.meanings || []).flatMap(m => m.synonyms || []).slice(0, 5);
    if (synonyms.length) html += `<div style="margin-top:8px;font-size:12px;color:#666"><strong>Đồng nghĩa:</strong> ${synonyms.map(s=>`<span onclick="lookupDictWord('${s}')" style="color:var(--blue);cursor:pointer;text-decoration:underline">${s}</span>`).join(', ')}</div>`;

    body.innerHTML = html || '<div class="dict-err">Không tìm thấy định nghĩa.</div>';
  } catch(e) {
    body.innerHTML = `<div class="dict-err">❌ Không tìm thấy "<strong>${word}</strong>" trong từ điển.<br><span style="font-size:12px;color:#aaa">Nghĩa theo bài học: ${meaning || '—'}</span></div>`;
  }
}

function playAudio(url) {
  if (!url) return;
  try { new Audio(url).play(); } catch(e) {}
}

async function lookupDictWord(word) {
  dictCurrentWord = word;
  document.getElementById('dict-word-title').textContent = word;
  const body = document.getElementById('dict-body');
  body.innerHTML = '<div class="dict-loading">⏳ Đang tra...</div>';
  try {
    const res = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`);
    if (!res.ok) throw new Error('not found');
    const data = await res.json();
    const entry = data[0];
    const phonetic = entry.phonetics?.find(p => p.text)?.text || '';
    const audio = entry.phonetics?.find(p => p.audio)?.audio || '';
    let html = '';
    if (phonetic) html += `<div class="dict-phonetic">${phonetic} ${audio?`<button onclick="playAudio('${audio}')" style="background:none;border:none;cursor:pointer">🔊</button>`:''}</div>`;
    (entry.meanings||[]).slice(0,3).forEach(m=>{
      html+=`<div class="dict-meaning-row"><span class="dict-pos">${m.partOfSpeech}</span>`;
      (m.definitions||[]).slice(0,2).forEach(d=>{ html+=`<div class="dict-def">• ${d.definition}</div>`; if(d.example) html+=`<div class="dict-ex-d">"${d.example}"</div>`; });
      html+='</div>';
    });
    body.innerHTML = html;
  } catch(e) { body.innerHTML = `<div class="dict-err">Không tìm thấy "${word}"</div>`; }
}

async function saveDictWord() {
  if (!dictCurrentWord || !currentUser) {
    if (!currentUser) showModal('ℹ️','Cần đăng nhập','Đăng nhập để lưu từ vựng cá nhân.','OK',closeModal);
    return;
  }
  const btn = document.getElementById('dict-save-btn');
  btn.textContent = '⏳ Lưu...'; btn.disabled = true;
  await sb.from('user_vocab').upsert({
    user_id: currentUser.id,
    word: dictCurrentWord,
    meaning: dictCurrentMeaning || '—'
  }, { onConflict: 'user_id,word' });
  btn.textContent = '✅ Đã lưu';
  setTimeout(()=>{ btn.textContent = '+ Lưu từ'; btn.disabled = false; }, 2000);
}

// ══════════════════════════════════════════════════════════════════════
// ── 3. STREAK & DAILY REMINDER — Supabase-backed ──────────────────────
// ══════════════════════════════════════════════════════════════════════
// Bảng cần tạo trong Supabase (xem SQL ở cuối file hoặc README):
//   study_logs  (user_id, study_date, cards_seen, quiz_score, words_saved)
//   profiles    thêm cột: streak_count int4 default 0, last_study_date date

let streakCache = { count: 0, last: '', studiedDates: [] }; // in-memory cache

async function loadStreakFromDB() {
  if (!currentUser) return;
  try {
    // Lấy streak_count và last_study_date từ profiles
    const { data: prof } = await sb.from('profiles')
      .select('streak_count, last_study_date')
      .eq('id', currentUser.id)
      .single();

    // Lấy 7 ngày gần nhất từ study_logs
    const since = new Date(Date.now() - 6 * 86400000).toISOString().slice(0, 10);
    const { data: logs } = await sb.from('study_logs')
      .select('study_date')
      .eq('user_id', currentUser.id)
      .gte('study_date', since)
      .order('study_date', { ascending: false });

    streakCache.count = prof?.streak_count || 0;
    streakCache.last  = prof?.last_study_date || '';
    streakCache.studiedDates = (logs || []).map(l => l.study_date);
  } catch(e) {
    // Bảng chưa có → bỏ qua, hiện streak = 0
    console.warn('Streak DB not ready:', e.message);
  }
}

async function markStudiedToday(activityType = 'flashcard') {
  const today = new Date().toISOString().slice(0, 10);

  // Cập nhật cache local ngay để UI nhanh
  if (!streakCache.studiedDates.includes(today)) {
    streakCache.studiedDates.push(today);
  }

  if (!currentUser) {
    renderStreakBar();
    return;
  }

  try {
    // 1. Upsert vào study_logs (1 row / user / ngày)
    const colMap = {
      flashcard:   'cards_seen',
      quiz:        'quiz_score',
      word_saved:  'words_saved'
    };
    const col = colMap[activityType] || 'cards_seen';
    const { data: existing } = await sb.from('study_logs')
      .select('id, cards_seen, quiz_score, words_saved')
      .eq('user_id', currentUser.id)
      .eq('study_date', today)
      .maybeSingle();

    if (existing) {
      await sb.from('study_logs')
        .update({ [col]: (existing[col] || 0) + 1 })
        .eq('id', existing.id);
    } else {
      await sb.from('study_logs')
        .insert({ user_id: currentUser.id, study_date: today, [col]: 1 });
    }

    // 2. Tính lại streak và cập nhật profiles
    const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
    const last = streakCache.last;
    let newCount = streakCache.count;

    if (last !== today) {
      newCount = (last === yesterday) ? newCount + 1 : 1;
      await sb.from('profiles')
        .update({ streak_count: newCount, last_study_date: today })
        .eq('id', currentUser.id);
      streakCache.count = newCount;
      streakCache.last  = today;
      // Cập nhật profile cache
      if (currentProfile) {
        currentProfile.streak_count = newCount;
        currentProfile.last_study_date = today;
      }
    }
  } catch(e) {
    console.warn('Streak update error:', e.message);
  }

  renderStreakBar();
}

function renderStreakBar() {
  const wrap = document.getElementById('streak-bar-wrap');
  if (!wrap) return;
  const count = streakCache.count || 0;
  const today = new Date().toISOString().slice(0, 10);

  // Build lịch 7 ngày — dùng studiedDates từ DB
  const dayNames = ['CN','T2','T3','T4','T5','T6','T7'];
  const daysHtml = Array.from({length: 7}, (_, i) => {
    const d = new Date(Date.now() - (6 - i) * 86400000).toISOString().slice(0, 10);
    const name = dayNames[new Date(d + 'T12:00:00').getDay()];
    const isToday = d === today;
    const done = streakCache.studiedDates.includes(d);
    let cls = 'streak-day' + (isToday ? ' today' : done ? ' done' : '');
    return `<div class="${cls}" title="${d}">${name}</div>`;
  }).join('');

  const emoji = count >= 30 ? '🔥🔥🔥' : count >= 14 ? '🔥🔥' : '🔥';
  const msg   = count === 0 ? 'Học ngay để bắt đầu streak!'
              : count === 1 ? 'Ngày đầu tiên! Duy trì nhé!'
              : `Tuyệt vời! Duy trì ${count} ngày liên tiếp!`;

  wrap.innerHTML = `
    <div class="streak-bar">
      <div class="streak-fire">${emoji}</div>
      <div class="streak-info">
        <div class="streak-title">🗓 Streak: ${count} ngày liên tiếp</div>
        <div class="streak-sub">${msg}</div>
        <div class="streak-days">${daysHtml}</div>
      </div>
      <div style="text-align:center;flex-shrink:0">
        <div style="font-size:2rem;font-weight:800;color:var(--gold);font-family:monospace">${count}</div>
        <div style="font-size:11px;color:#92400e">ngày</div>
      </div>
    </div>`;
}

// ── Notification reminder ──────────────────────────────────────────────
async function requestDailyReminder() {
  if (!('Notification' in window)) return;
  if (Notification.permission === 'default') {
    const perm = await Notification.requestPermission();
    if (perm === 'granted') fireReminderIfNeeded();
  } else if (Notification.permission === 'granted') {
    fireReminderIfNeeded();
  }
}

function fireReminderIfNeeded() {
  const today = new Date().toISOString().slice(0, 10);
  if (streakCache.last !== today) {
    setTimeout(() => {
      try {
        new Notification('📚 EduEnglish — Học từ hôm nay!', {
          body: `Streak của bạn: ${streakCache.count} ngày. Đừng để mất streak nhé! 🔥`,
          icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="%232d6a4f"/><text x="16" y="22" text-anchor="middle" font-size="18" fill="white">E</text></svg>'
        });
      } catch(e) {}
    }, 4000);
  }
}

// ── Hook vào flashcard & quiz ──────────────────────────────────────────
const _origRateCard = rateCard;
rateCard = function(knew) {
  markStudiedToday('flashcard');
  _origRateCard(knew);
};

const _origPickOpt = pickOpt;
pickOpt = function(btn, chosen, correct) {
  markStudiedToday('quiz');
  _origPickOpt(btn, chosen, correct);
};

// ── Override loadStudentDash để load streak từ DB ─────────────────────
const _origLoadStudentDash = loadStudentDash;
loadStudentDash = async function() {
  _origLoadStudentDash();
  await loadStreakFromDB();
  renderStreakBar();
  setTimeout(requestDailyReminder, 2500);
};


